<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT c.*, u.email FROM companies c JOIN users u ON c.user_id = u.id WHERE c.id = ?');
$profile->execute([$companyId]);
$company = $profile->fetch();

$stats = $db->prepare('
    SELECT COUNT(*) AS total,
           SUM(status="pending")  AS pending,
           SUM(status="accepted") AS accepted,
           SUM(status="rejected") AS rejected
    FROM applications WHERE company_id = ?
');
$stats->execute([$companyId]);
$appStats = $stats->fetch();

$recent = $db->prepare('
    SELECT a.id, a.status, a.date_applied,
           s.first_name, s.last_name, s.student_number, s.programme, s.cv_path
    FROM applications a
    JOIN students s ON a.student_id = s.id
    WHERE a.company_id = ?
    ORDER BY a.date_applied DESC LIMIT 5
');
$recent->execute([$companyId]);
$recentApps = $recent->fetchAll();

$pageTitle = 'Company Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (!$company['is_approved']): ?>
    <div class="alert alert-info">
        ⏳ Your company account is pending admin approval. You will be able to receive applications once approved.
    </div>
<?php endif; ?>

<h1 class="page-title">
    <?= htmlspecialchars($company['company_name']) ?> &mdash; Dashboard
</h1>

<div class="stats-grid">
    <div class="stat-box"><div class="stat-num"><?= (int)$appStats['total'] ?></div><div class="stat-label">Total Applications</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$appStats['pending'] ?></div><div class="stat-label">Pending</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$appStats['accepted'] ?></div><div class="stat-label">Accepted</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$appStats['rejected'] ?></div><div class="stat-label">Rejected</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$company['capacity'] ?></div><div class="stat-label">Capacity</div></div>
</div>

<div class="card" style="background:linear-gradient(135deg,#1a2e4a 0%,#2d5080 100%);border:none;padding:20px 24px;">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <div>
            <h2 style="color:#fff;border-bottom:none;margin-bottom:4px;padding-bottom:0;">📋 Student Reports &amp; Logbooks</h2>
            <p style="color:rgba(255,255,255,.7);font-size:13px;margin:0;">
                View logbooks and final reports submitted by students placed at your company.
            </p>
        </div>
        <a href="<?= BASE_URL ?>/company/reports.php" class="btn btn-danger">View Reports →</a>
    </div>
</div>

<div class="two-col">
    <div class="card">
        <h2>Company Profile</h2>
        <table>
            <tr><th>Sector</th>         <td><?= htmlspecialchars($company['sector']) ?></td></tr>
            <tr><th>Contact Person</th> <td><?= htmlspecialchars($company['contact_person']) ?></td></tr>
            <tr><th>Email</th>          <td><?= htmlspecialchars($company['email']) ?></td></tr>
            <tr><th>Phone</th>          <td><?= htmlspecialchars($company['phone'] ?? '—') ?></td></tr>
            <tr><th>Address</th>        <td><?= htmlspecialchars($company['address'] ?? '—') ?></td></tr>
            <tr><th>Status</th>
                <td><span class="badge <?= $company['is_approved'] ? 'badge-approved' : 'badge-pending' ?>">
                    <?= $company['is_approved'] ? 'Approved' : 'Pending Approval' ?>
                </span></td>
            </tr>
        </table>
    </div>

</div>

<div class="card">
    <h2>Recent Applications</h2>
    <?php if (empty($recentApps)): ?>
        <p class="text-muted">No applications received yet.</p>
    <?php else: ?>
        <table>
            <thead><tr><th>Student</th><th>Programme</th><th>Student No.</th><th>CV</th><th>Applied</th><th>Status</th></tr></thead>
            <tbody>
                <?php foreach ($recentApps as $app): ?>
                    <tr>
                        <td><?= htmlspecialchars($app['first_name'] . ' ' . $app['last_name']) ?></td>
                        <td><?= htmlspecialchars($app['programme']) ?></td>
                        <td><?= htmlspecialchars($app['student_number']) ?></td>
                        <td>
                            <?php if ($app['cv_path']): ?>
                                <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($app['cv_path'])) ?>" target="_blank">View</a>
                            <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                        </td>
                        <td><?= date('d M Y', strtotime($app['date_applied'])) ?></td>
                        <td><span class="badge badge-<?= $app['status'] === 'offered' ? 'offered' : $app['status'] ?>"><?= $app['status'] === 'offered' ? 'Offer Sent' : ucfirst($app['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="mt-10"><a href="<?= BASE_URL ?>/company/applicants.php" class="text-muted" style="font-size:13px;">View all →</a></div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
