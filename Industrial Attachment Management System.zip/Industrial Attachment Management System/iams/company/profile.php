<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

$stmt = $db->prepare('SELECT c.*, u.email FROM companies c JOIN users u ON c.user_id = u.id WHERE c.id = ?');
$stmt->execute([$companyId]);
$company = $stmt->fetch();

$errors  = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $companyName   = trim($_POST['company_name']   ?? '');
    $sector        = trim($_POST['sector']         ?? '');
    $contactPerson = trim($_POST['contact_person'] ?? '');
    $phone         = trim($_POST['phone']          ?? '');
    $address       = trim($_POST['address']        ?? '');
    $capacity      = (int)($_POST['capacity']      ?? 1);


    if ($companyName === '')   $errors[] = 'Company name is required.';
    if ($sector === '')        $errors[] = 'Sector is required.';
    if ($contactPerson === '') $errors[] = 'Contact person name is required.';
    if ($capacity < 1)        $errors[] = 'Capacity must be at least 1.';
    if ($capacity > 500)      $errors[] = 'Capacity cannot exceed 500.';

    if (empty($errors)) {
        $upd = $db->prepare('UPDATE companies
                             SET company_name = ?, sector = ?, contact_person = ?,
                                 phone = ?, address = ?, capacity = ?
                             WHERE id = ?');
        $upd->execute([
            $companyName, $sector, $contactPerson,
            $phone ?: null, $address ?: null, $capacity,
            $companyId,
        ]);
        $success = 'Profile updated successfully.';


        $stmt->execute([$companyId]);
        $company = $stmt->fetch();
    }
}

$pageTitle = 'Edit Company Profile';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Edit Company Profile</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php foreach ($errors as $e): ?>
    <div class="alert alert-error"><?= htmlspecialchars($e) ?></div>
<?php endforeach; ?>

<?php if (!$company['is_approved']): ?>
    <div class="alert alert-info">
        ⏳ Your company account is pending admin approval. You can still update your profile.
    </div>
<?php endif; ?>

<div class="two-col">

    <!-- ── Edit form ── -->
    <div class="card">
        <h2>Company Details</h2>
        <form method="POST" action="profile.php">

            <div class="form-group">
                <label for="company_name">Company Name *</label>
                <input type="text" id="company_name" name="company_name" required
                       value="<?= htmlspecialchars($company['company_name']) ?>">
            </div>

            <div class="form-group">
                <label for="sector">Sector / Industry *</label>
                <input type="text" id="sector" name="sector" required
                       value="<?= htmlspecialchars($company['sector']) ?>"
                       placeholder="e.g. Information Technology">
            </div>

            <div class="form-group">
                <label for="contact_person">Contact Person *</label>
                <input type="text" id="contact_person" name="contact_person" required
                       value="<?= htmlspecialchars($company['contact_person']) ?>"
                       placeholder="Full name of HR / primary contact">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone"
                       value="<?= htmlspecialchars($company['phone'] ?? '') ?>"
                       placeholder="Optional">
            </div>

            <div class="form-group">
                <label for="capacity">Attachment Capacity *
                    <small style="font-weight:normal;color:#666;"> — number of students you can take</small>
                </label>
                <input type="number" id="capacity" name="capacity" min="1" max="500" required
                       value="<?= (int)$company['capacity'] ?>">
            </div>

            <div class="form-group">
                <label for="address">Physical Address</label>
                <textarea id="address" name="address" rows="3"
                          placeholder="Company physical address"><?= htmlspecialchars($company['address'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>

    <!-- ── Read-only info ── -->
    <div>
        <div class="card">
            <h2>Account Information</h2>
            <table>
                <tr><th>Email</th>
                    <td><?= htmlspecialchars($company['email']) ?></td>
                </tr>
                <tr><th>Account Status</th>
                    <td>
                        <span class="badge <?= $company['is_approved'] ? 'badge-approved' : 'badge-pending' ?>">
                            <?= $company['is_approved'] ? 'Approved' : 'Pending Approval' ?>
                        </span>
                    </td>
                </tr>
                <tr><th>Registered</th>
                    <td><?= date('d M Y', strtotime($company['created_at'])) ?></td>
                </tr>
            </table>
            <p class="text-muted" style="font-size:13px;margin-top:12px;">
                To change your email or password, please contact the administrator.
            </p>
        </div>

        <div class="card">
            <h2>Capacity Overview</h2>
            <?php
            $capStats = $db->prepare('
                SELECT
                    COUNT(*)                    AS total_apps,
                    SUM(status = "accepted")    AS accepted,
                    SUM(status = "pending")     AS pending
                FROM applications WHERE company_id = ?
            ');
            $capStats->execute([$companyId]);
            $cs = $capStats->fetch();
            $filled    = (int)$cs['accepted'];
            $available = max(0, $company['capacity'] - $filled);
            ?>
            <table>
                <tr><th>Total Capacity</th>   <td><?= (int)$company['capacity'] ?></td></tr>
                <tr><th>Accepted Students</th><td><?= $filled ?></td></tr>
                <tr><th>Available Spots</th>
                    <td>
                        <strong style="color:<?= $available > 0 ? '#166534' : '#991b1b' ?>">
                            <?= $available ?> spot<?= $available !== 1 ? 's' : '' ?>
                        </strong>
                    </td>
                </tr>
                <tr><th>Pending Applications</th><td><?= (int)$cs['pending'] ?></td></tr>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
