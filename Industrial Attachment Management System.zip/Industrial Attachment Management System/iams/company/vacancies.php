<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_vacancy'])) {
        $title    = trim($_POST['position_title'] ?? '');
        $desc     = trim($_POST['description']    ?? '');
        $reqs     = trim($_POST['requirements']   ?? '');
        $num      = max(1, (int)($_POST['num_positions'] ?? 1));
        $deadline = $_POST['deadline'] ?? '';

        if ($title === '') {
            setFlash('error', 'Position title is required.');
        } else {
            $db->prepare('INSERT INTO vacancies (company_id, position_title, description, requirements, num_positions, deadline)
                          VALUES (?, ?, ?, ?, ?, ?)')
               ->execute([$companyId, $title, $desc ?: null, $reqs ?: null, $num, $deadline ?: null]);


            $students = $db->query('SELECT u.id FROM students s JOIN users u ON s.user_id = u.id')->fetchAll();
            $coName   = $db->query("SELECT company_name FROM companies WHERE id = $companyId")->fetchColumn();
            foreach ($students as $st) {
                sendNotification($db, $st['id'],
                    "New vacancy: \"$title\" at " . htmlspecialchars($coName) . ". Check it out!",
                    BASE_URL . '/student/vacancies.php');
            }
            setFlash('success', 'Vacancy posted and students notified.');
        }
    } elseif (isset($_POST['deactivate_id'])) {
        $vid = (int)$_POST['deactivate_id'];
        $db->prepare('UPDATE vacancies SET is_active = 0 WHERE id = ? AND company_id = ?')
           ->execute([$vid, $companyId]);
        setFlash('success', 'Vacancy removed.');
    }
    header('Location: ' . BASE_URL . '/company/vacancies.php'); exit;
}

$vacancies = $db->prepare('SELECT * FROM vacancies WHERE company_id = ? ORDER BY created_at DESC');
$vacancies->execute([$companyId]);
$allVacancies = $vacancies->fetchAll();

$pageTitle = 'Manage Vacancies';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Manage Vacancies</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Add vacancy form -->
<div class="card">
    <h2>Post a New Vacancy</h2>
    <form method="POST" action="vacancies.php">
        <div class="two-col">
            <div class="form-group">
                <label>Position Title *</label>
                <input type="text" name="position_title" required placeholder="e.g. Software Developer Intern">
            </div>
            <div class="form-group">
                <label>Number of Positions *</label>
                <input type="number" name="num_positions" min="1" max="50" value="1" required>
            </div>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="3" placeholder="What will the intern be doing?"></textarea>
        </div>
        <div class="form-group">
            <label>Requirements</label>
            <textarea name="requirements" rows="2" placeholder="Skills, qualifications needed..."></textarea>
        </div>
        <div class="form-group">
            <label>Application Deadline <span style="font-weight:normal;color:#888;">(optional)</span></label>
            <input type="date" name="deadline" min="<?= date('Y-m-d') ?>">
        </div>
        <button type="submit" name="add_vacancy" class="btn btn-success">Post Vacancy</button>
        <small class="text-muted" style="margin-left:12px;">All registered students will be notified automatically.</small>
    </form>
</div>

<!-- Existing vacancies -->
<div class="card">
    <h2>Your Vacancies</h2>
    <?php if (empty($allVacancies)): ?>
        <p class="text-muted">No vacancies posted yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Position</th><th>Positions</th><th>Deadline</th><th>Status</th><th>Posted</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($allVacancies as $v): ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($v['position_title']) ?></strong>
                            <?php if ($v['description']): ?>
                                <br><small class="text-muted"><?= htmlspecialchars(mb_substr($v['description'],0,60)) ?>...</small>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$v['num_positions'] ?></td>
                        <td><?= $v['deadline'] ? date('d M Y', strtotime($v['deadline'])) : '—' ?></td>
                        <td><span class="badge <?= $v['is_active'] ? 'badge-approved' : 'badge-rejected' ?>"><?= $v['is_active'] ? 'Active' : 'Closed' ?></span></td>
                        <td><?= date('d M Y', strtotime($v['created_at'])) ?></td>
                        <td>
                            <?php if ($v['is_active']): ?>
                                <form method="POST" onsubmit="return confirm('Remove this vacancy?')">
                                    <input type="hidden" name="deactivate_id" value="<?= (int)$v['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted" style="font-size:13px;">Closed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
