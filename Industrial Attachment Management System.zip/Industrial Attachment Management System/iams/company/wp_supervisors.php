<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT company_name FROM companies WHERE id = ?');
$profile->execute([$companyId]);
$company = $profile->fetch();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';


    if ($action === 'assign') {
        $studentId = (int)($_POST['student_id'] ?? 0);
        $wpsId     = (int)($_POST['wps_id']     ?? 0);


        $chkStu = $db->prepare('
            SELECT s.id, u.id AS user_id, s.first_name, s.last_name
            FROM students s
            JOIN applications a ON a.student_id = s.id
            JOIN users u ON s.user_id = u.id
            WHERE a.company_id = ? AND a.status = "accepted" AND s.id = ?
        ');
        $chkStu->execute([$companyId, $studentId]);
        $stu = $chkStu->fetch();


        $chkWps = $db->prepare('SELECT id, first_name, last_name FROM workplace_supervisors WHERE id = ? AND company_id = ?');
        $chkWps->execute([$wpsId, $companyId]);
        $wps = $chkWps->fetch();

        if (!$stu) {
            setFlash('error', 'Student not found or not placed at your company.');
        } elseif (!$wps) {
            setFlash('error', 'Workplace supervisor not found.');
        } else {

            $upsert = $db->prepare('
                INSERT INTO workplace_assignments (student_id, workplace_supervisor_id, company_id)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE workplace_supervisor_id = VALUES(workplace_supervisor_id), assigned_at = NOW()
            ');
            $upsert->execute([$studentId, $wpsId, $companyId]);


            $wpsName = $wps['first_name'] . ' ' . $wps['last_name'];
            sendNotification($db, $stu['user_id'],
                "You have been assigned a workplace supervisor: {$wpsName} at {$company['company_name']}.",
                BASE_URL . '/student/dashboard.php'
            );


            $wpsUserRow = $db->prepare('SELECT u.id FROM users u JOIN workplace_supervisors w ON w.user_id = u.id WHERE w.id = ?');
            $wpsUserRow->execute([$wpsId]);
            $wpsUserId = $wpsUserRow->fetchColumn();
            if ($wpsUserId) {
                sendNotification($db, (int)$wpsUserId,
                    "A student has been assigned to you: {$stu['first_name']} {$stu['last_name']}.",
                    BASE_URL . '/workplace_supervisor/my_students.php'
                );
            }

            setFlash('success', "Student assigned to {$wpsName} successfully.");
        }
        header('Location: wp_supervisors.php'); exit;
    }


    if ($action === 'unassign') {
        $studentId = (int)($_POST['student_id'] ?? 0);
        $del = $db->prepare('DELETE FROM workplace_assignments WHERE student_id = ? AND company_id = ?');
        $del->execute([$studentId, $companyId]);
        setFlash('success', 'Student assignment removed.');
        header('Location: wp_supervisors.php'); exit;
    }
}

$wpsList = $db->prepare('
    SELECT w.*, u.email,
        (SELECT COUNT(*) FROM workplace_assignments wa WHERE wa.workplace_supervisor_id = w.id) AS student_count
    FROM workplace_supervisors w
    JOIN users u ON w.user_id = u.id
    WHERE w.company_id = ?
    ORDER BY w.last_name
');
$wpsList->execute([$companyId]);
$supervisors = $wpsList->fetchAll();

$placedStudents = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           wa.workplace_supervisor_id AS current_wps_id,
           CONCAT(w.first_name, " ", w.last_name) AS current_wps_name
    FROM students s
    JOIN applications a ON a.student_id = s.id
    LEFT JOIN workplace_assignments wa ON wa.student_id = s.id
    LEFT JOIN workplace_supervisors w  ON w.id = wa.workplace_supervisor_id
    WHERE a.company_id = ? AND a.status = "accepted"
    ORDER BY s.last_name
');
$placedStudents->execute([$companyId]);
$students = $placedStudents->fetchAll();

$pageTitle = 'Workplace Supervisors';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Workplace Supervisors</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- ── Supervisors list ── -->
<div class="card">
    <h2>Your Workplace Supervisors (<?= count($supervisors) ?>)</h2>
    <?php if (empty($supervisors)): ?>
        <div class="alert alert-info">
            No workplace supervisors are registered yet. Supervisors register themselves at
            <strong><?= BASE_URL ?>/register.php?role=workplace_supervisor</strong> using your company's email address.
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Job Title</th>
                    <th>Department</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Students Assigned</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($supervisors as $wps): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($wps['first_name'] . ' ' . $wps['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($wps['job_title'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($wps['department'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($wps['email']) ?></td>
                        <td><?= htmlspecialchars($wps['phone'] ?? '—') ?></td>
                        <td>
                            <span class="badge <?= $wps['student_count'] > 0 ? 'badge-accepted' : 'badge-pending' ?>">
                                <?= (int)$wps['student_count'] ?> student<?= $wps['student_count'] != 1 ? 's' : '' ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- ── Assign students ── -->
<div class="card">
    <h2>Assign Students to Workplace Supervisors</h2>

    <?php if (empty($students)): ?>
        <p class="text-muted">No students are currently placed at your company. Accepted students will appear here.</p>
    <?php elseif (empty($supervisors)): ?>
        <div class="alert alert-info">You need at least one workplace supervisor registered before you can make assignments.</div>
    <?php else: ?>
        <p class="text-muted" style="margin-bottom:16px;">
            Each placed student can be assigned to one workplace supervisor. Use the form below to set or change assignments.
        </p>
        <table>
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Programme</th>
                    <th>Student No.</th>
                    <th>Current Supervisor</th>
                    <th>Assign To</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $st): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($st['programme']) ?></td>
                        <td><?= htmlspecialchars($st['student_number']) ?></td>
                        <td>
                            <?php if ($st['current_wps_name']): ?>
                                <span class="badge badge-wp">👤 <?= htmlspecialchars($st['current_wps_name']) ?></span>
                            <?php else: ?>
                                <span class="text-muted">Not assigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" action="wp_supervisors.php" style="display:flex;gap:8px;align-items:center;">
                                <input type="hidden" name="action" value="assign">
                                <input type="hidden" name="student_id" value="<?= (int)$st['id'] ?>">
                                <select name="wps_id" required style="padding:5px 8px;border:1px solid #bbb;border-radius:4px;font-size:13px;min-width:180px;">
                                    <option value="">-- Select supervisor --</option>
                                    <?php foreach ($supervisors as $wps): ?>
                                        <option value="<?= (int)$wps['id'] ?>"
                                            <?= $st['current_wps_id'] == $wps['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($wps['first_name'] . ' ' . $wps['last_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Assign</button>
                            </form>
                        </td>
                        <td>
                            <?php if ($st['current_wps_id']): ?>
                                <form method="POST" action="wp_supervisors.php"
                                      onsubmit="return confirm('Remove this assignment?')">
                                    <input type="hidden" name="action" value="unassign">
                                    <input type="hidden" name="student_id" value="<?= (int)$st['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
