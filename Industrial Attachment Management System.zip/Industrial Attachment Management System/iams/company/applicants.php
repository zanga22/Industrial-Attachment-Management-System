<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_offer_letter'])) {
    $appId = (int)$_POST['app_id'];


    $chk = $db->prepare('
        SELECT a.id, a.student_id, s.first_name, s.last_name, u.id AS user_id
        FROM applications a
        JOIN students s ON a.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE a.id = ? AND a.company_id = ? AND a.status = "pending"
    ');
    $chk->execute([$appId, $companyId]);
    $app = $chk->fetch();

    if (!$app) {
        setFlash('error', 'Application not found or already reviewed.');
        header('Location: applicants.php');
        exit;
    }


    if (empty($_FILES['offer_letter']['name']) || $_FILES['offer_letter']['error'] !== UPLOAD_ERR_OK) {
        setFlash('error', 'Please upload a valid offer letter file.');
        header('Location: applicants.php');
        exit;
    }

    $file    = $_FILES['offer_letter'];
    $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf', 'doc', 'docx'];

    if (!in_array($ext, $allowed, true)) {
        setFlash('error', 'Only PDF, DOC, or DOCX files are accepted for offer letters.');
        header('Location: applicants.php');
        exit;
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        setFlash('error', 'Offer letter file must be under 5 MB.');
        header('Location: applicants.php');
        exit;
    }


    $uploadDir = __DIR__ . '/../uploads/offer_letters/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $safeName = 'offer_' . $appId . '_' . time() . '.' . $ext;
    $destPath = $uploadDir . $safeName;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        setFlash('error', 'File upload failed. Please try again.');
        header('Location: applicants.php');
        exit;
    }


    $db->prepare('UPDATE applications SET status = "offered", reviewed_at = NOW(), offer_letter_path = ? WHERE id = ?')
       ->execute([$safeName, $appId]);


    $coName = $db->prepare('SELECT company_name FROM companies WHERE id = ?');
    $coName->execute([$companyId]);
    $companyName = $coName->fetchColumn();


    sendNotification(
        $db,
        $app['user_id'],
        "{$companyName} has sent you a placement offer letter! Log in to read and respond to the offer.",
        BASE_URL . '/student/applications.php'
    );

    setFlash('success', 'Offer letter sent to ' . htmlspecialchars($app['first_name'] . ' ' . $app['last_name']) . '. They will be notified.');
    header('Location: applicants.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['decision']) && $_POST['decision'] === 'rejected') {
    $appId = (int)$_POST['app_id'];

    $chk = $db->prepare('
        SELECT a.id, a.student_id, s.first_name, s.last_name, u.id AS user_id
        FROM applications a
        JOIN students s ON a.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE a.id = ? AND a.company_id = ? AND a.status = "pending"
    ');
    $chk->execute([$appId, $companyId]);
    $app = $chk->fetch();

    if ($app) {
        $db->prepare('UPDATE applications SET status = "rejected", reviewed_at = NOW() WHERE id = ?')
           ->execute([$appId]);

        $coName = $db->prepare('SELECT company_name FROM companies WHERE id = ?');
        $coName->execute([$companyId]);
        $companyName = $coName->fetchColumn();

        sendNotification($db, $app['user_id'],
            "Your application to {$companyName} was not successful.",
            BASE_URL . '/student/applications.php'
        );
        setFlash('success', 'Application rejected.');
    } else {
        setFlash('error', 'Application not found or already reviewed.');
    }

    header('Location: applicants.php');
    exit;
}

$filterStatus = $_GET['status'] ?? 'all';
$validStatuses = ['all', 'pending', 'offered', 'accepted', 'rejected', 'withdrawn'];
if (!in_array($filterStatus, $validStatuses, true)) $filterStatus = 'all';

$sql = '
    SELECT a.id, a.status, a.date_applied, a.cover_note, a.reviewed_at, a.offer_letter_path,
           s.first_name, s.last_name, s.student_number, s.programme,
           s.phone, s.cv_path, s.transcript_path, u.email
    FROM applications a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE a.company_id = ?
';
$params = [$companyId];
if ($filterStatus !== 'all') {
    $sql .= ' AND a.status = ?';
    $params[] = $filterStatus;
}
$sql .= ' ORDER BY a.date_applied DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$applications = $stmt->fetchAll();

$counts = $db->prepare('
    SELECT status, COUNT(*) AS cnt FROM applications WHERE company_id = ? GROUP BY status
');
$counts->execute([$companyId]);
$statusCounts = [];
foreach ($counts->fetchAll() as $r) $statusCounts[$r['status']] = (int)$r['cnt'];

$pageTitle = 'Manage Applicants';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Student Applicants</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Status filter -->
<div class="card" style="padding:14px;">
    <span style="font-weight:bold;margin-right:10px;">Filter:</span>
    <?php
    $filterLabels = ['all'=>'All', 'pending'=>'Pending', 'offered'=>'Offer Sent',
                     'accepted'=>'Accepted', 'rejected'=>'Rejected', 'withdrawn'=>'Withdrawn'];
    foreach ($filterLabels as $val => $lbl):
        $cnt = $val === 'all' ? array_sum($statusCounts) : ($statusCounts[$val] ?? 0);
    ?>
        <a href="?status=<?= $val ?>"
           class="btn btn-sm <?= $filterStatus === $val ? 'btn-primary' : 'btn-secondary' ?>"
           style="margin-right:6px;">
            <?= $lbl ?>
            <?php if ($cnt > 0): ?>
                <span style="background:rgba(255,255,255,0.3);border-radius:10px;padding:1px 6px;font-size:11px;margin-left:4px;"><?= $cnt ?></span>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if (empty($applications)): ?>
    <div class="card"><p class="text-muted">No applications found.</p></div>
<?php else: ?>
    <?php foreach ($applications as $app): ?>
        <div class="card" style="margin-bottom:14px;border-left:4px solid <?=
            $app['status'] === 'offered'   ? '#2563eb' :
           ($app['status'] === 'accepted'  ? '#16a34a' :
           ($app['status'] === 'rejected'  ? '#dc2626' :
           ($app['status'] === 'withdrawn' ? '#94a3b8' : '#f59e0b'))) ?>">

            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                <div>
                    <strong style="font-size:16px;"><?= htmlspecialchars($app['first_name'] . ' ' . $app['last_name']) ?></strong>
                    <span class="badge badge-<?= $app['status'] === 'offered' ? 'accepted' : $app['status'] ?>" style="margin-left:10px;">
                        <?= $app['status'] === 'offered' ? 'Offer Sent' : ucfirst($app['status']) ?>
                    </span>
                    <br>
                    <span class="text-muted">
                        <?= htmlspecialchars($app['student_number']) ?> &mdash;
                        <?= htmlspecialchars($app['programme']) ?> &mdash;
                        <?= htmlspecialchars($app['email']) ?>
                        <?php if ($app['phone']): ?> &mdash; <?= htmlspecialchars($app['phone']) ?><?php endif; ?>
                    </span>
                    <br>
                    <small class="text-muted">Applied: <?= date('d M Y H:i', strtotime($app['date_applied'])) ?></small>
                    <?php if ($app['cover_note']): ?>
                        <br><em style="font-size:13px;color:#444;"><?= htmlspecialchars($app['cover_note']) ?></em>
                    <?php endif; ?>
                    <?php if ($app['status'] === 'offered' && $app['reviewed_at']): ?>
                        <br><small style="color:#2563eb;">Offer letter sent: <?= date('d M Y', strtotime($app['reviewed_at'])) ?> — awaiting student response</small>
                    <?php endif; ?>
                </div>

                <!-- Documents + Actions -->
                <div style="display:flex;flex-direction:column;gap:8px;min-width:180px;align-items:flex-end;">
                    <div>
                        <?php if ($app['cv_path']): ?>
                            <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($app['cv_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm">📄 CV</a>
                        <?php else: ?>
                            <span class="text-muted" style="font-size:12px;">No CV</span>
                        <?php endif; ?>
                        <?php if ($app['transcript_path']): ?>
                            <a href="<?= BASE_URL ?>/file.php?type=transcript&f=<?= urlencode(basename($app['transcript_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm"> Transcript</a>
                        <?php endif; ?>
                        <?php if ($app['offer_letter_path']): ?>
                            <a href="<?= BASE_URL ?>/file.php?type=offer_letter&f=<?= urlencode($app['offer_letter_path']) ?>" target="_blank" class="btn btn-secondary btn-sm">📩 Offer Letter</a>
                        <?php endif; ?>
                    </div>

                    <?php if ($app['status'] === 'pending'): ?>
                        <div style="display:flex;gap:8px;">
                            <!-- Trigger offer letter modal -->
                            <button type="button"
                                    class="btn btn-success btn-sm"
                                    onclick="openOfferModal(<?= (int)$app['id'] ?>, '<?= htmlspecialchars(addslashes($app['first_name'] . ' ' . $app['last_name'])) ?>')">
                                📩 Send Offer Letter
                            </button>
                            <form method="POST" onsubmit="return confirm('Reject this applicant?')">
                                <input type="hidden" name="app_id"   value="<?= (int)$app['id'] ?>">
                                <input type="hidden" name="decision" value="rejected">
                                <button type="submit" class="btn btn-danger btn-sm">✗ Reject</button>
                            </form>
                        </div>
                    <?php elseif ($app['reviewed_at']): ?>
                        <small class="text-muted">Reviewed: <?= date('d M Y', strtotime($app['reviewed_at'])) ?></small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- ── Offer Letter Upload Modal ──────────────────────────────────────────── -->
<div id="offerModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:#fff;border-radius:10px;padding:32px;max-width:480px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.2);position:relative;">
        <button onclick="closeOfferModal()"
                style="position:absolute;top:12px;right:16px;background:none;border:none;font-size:22px;cursor:pointer;color:#64748b;"
                title="Close">&times;</button>

        <h2 style="margin:0 0 6px;color:#1e3a5f;font-size:18px;">📩 Send Offer Letter</h2>
        <p id="offerModalSubtitle" style="margin:0 0 20px;color:#64748b;font-size:14px;"></p>

        <form id="offerLetterForm" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="send_offer_letter" value="1">
            <input type="hidden" name="app_id" id="offerModalAppId" value="">

            <div style="margin-bottom:18px;">
                <label style="display:block;font-weight:600;margin-bottom:6px;color:#374151;font-size:14px;">
                    Upload Offer Letter <span style="color:#dc2626;">*</span>
                </label>
                <input type="file"
                       name="offer_letter"
                       id="offerLetterFile"
                       accept=".pdf,.doc,.docx"
                       required
                       style="width:100%;padding:10px;border:2px dashed #cbd5e1;border-radius:6px;font-size:14px;cursor:pointer;box-sizing:border-box;">
                <p style="margin:6px 0 0;font-size:12px;color:#94a3b8;">Accepted formats: PDF, DOC, DOCX &mdash; Max 5 MB</p>
            </div>

            <div id="offerFilePreview" style="display:none;background:#f0f9ff;border:1px solid #bae6fd;border-radius:6px;padding:10px 14px;margin-bottom:16px;font-size:13px;color:#0369a1;"></div>

            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <button type="button" onclick="closeOfferModal()" class="btn btn-secondary">Cancel</button>
                <button type="submit" class="btn btn-success" id="offerSubmitBtn" disabled>
                    📩 Send Offer Letter
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openOfferModal(appId, studentName) {
    document.getElementById('offerModalAppId').value = appId;
    document.getElementById('offerModalSubtitle').textContent =
        'You are sending an offer letter to ' + studentName + '. They will be notified and can read it before deciding.';
    document.getElementById('offerLetterFile').value = '';
    document.getElementById('offerFilePreview').style.display = 'none';
    document.getElementById('offerSubmitBtn').disabled = true;

    var modal = document.getElementById('offerModal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeOfferModal() {
    document.getElementById('offerModal').style.display = 'none';
    document.body.style.overflow = '';
}

document.getElementById('offerModal').addEventListener('click', function(e) {
    if (e.target === this) closeOfferModal();
});

document.getElementById('offerLetterFile').addEventListener('change', function() {
    var preview = document.getElementById('offerFilePreview');
    var btn     = document.getElementById('offerSubmitBtn');
    if (this.files && this.files[0]) {
        var file   = this.files[0];
        var sizeMB = (file.size / (1024 * 1024)).toFixed(2);
        preview.textContent = '📎 ' + file.name + ' (' + sizeMB + ' MB)';
        preview.style.display = 'block';
        btn.disabled = false;
    } else {
        preview.style.display = 'none';
        btn.disabled = true;
    }
});

document.getElementById('offerLetterForm').addEventListener('submit', function(e) {
    if (!confirm('Send this offer letter? The student will be notified to review and respond.')) {
        e.preventDefault();
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
