<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('company');

$db        = getDB();
$companyId = (int)$_SESSION['profile_id'];

$filterType    = $_GET['type']    ?? 'all';
$filterStudent = (int)($_GET['student_id'] ?? 0);

$validTypes = ['all', 'logbook', 'progress', 'final'];
if (!in_array($filterType, $validTypes, true)) $filterType = 'all';

$sql = '
    SELECT r.id, r.file_path, r.report_type, r.feedback, r.uploaded_at,
           s.id AS student_id, s.first_name, s.last_name, s.student_number, s.programme,
           l.first_name AS lec_first, l.last_name AS lec_last
    FROM reports r
    JOIN students s ON r.student_id = s.id
    JOIN applications a ON a.student_id = s.id AND a.company_id = ? AND a.status = "accepted"
    LEFT JOIN lecturers l ON r.lecturer_id = l.id
    WHERE 1 = 1
';
$params = [$companyId];

if ($filterType !== 'all') {
    $sql .= ' AND r.report_type = ?';
    $params[] = $filterType;
}
if ($filterStudent > 0) {
    $sql .= ' AND s.id = ?';
    $params[] = $filterStudent;
}
$sql .= ' ORDER BY r.uploaded_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

$placedStudents = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number
    FROM students s
    JOIN applications a ON a.student_id = s.id
    WHERE a.company_id = ? AND a.status = "accepted"
    ORDER BY s.last_name
');
$placedStudents->execute([$companyId]);
$students = $placedStudents->fetchAll();

$summary = $db->prepare('
    SELECT r.report_type, COUNT(*) AS cnt
    FROM reports r
    JOIN applications a ON a.student_id = r.student_id
    WHERE a.company_id = ? AND a.status = "accepted"
    GROUP BY r.report_type
');
$summary->execute([$companyId]);
$sumRows = $summary->fetchAll();
$typeCounts = ['logbook' => 0, 'progress' => 0, 'final' => 0];
foreach ($sumRows as $row) $typeCounts[$row['report_type']] = (int)$row['cnt'];

$pageTitle = 'Student Reports';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Student Reports &amp; Logbooks</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Summary stats -->
<div class="stats-grid">
    <div class="stat-box">
        <div class="stat-num"><?= count($students) ?></div>
        <div class="stat-label">Placed Students</div>
    </div>
    <div class="stat-box">
        <div class="stat-num"><?= $typeCounts['logbook'] ?></div>
        <div class="stat-label">Logbooks</div>
    </div>
    <div class="stat-box">
        <div class="stat-num"><?= $typeCounts['progress'] ?></div>
        <div class="stat-label">Progress Reports</div>
    </div>
    <div class="stat-box">
        <div class="stat-num"><?= $typeCounts['final'] ?></div>
        <div class="stat-label">Final Reports</div>
    </div>
</div>

<?php if (empty($students)): ?>
    <div class="card">
        <p class="text-muted">No students have been accepted at your company yet. Reports will appear here once students are placed.</p>
    </div>
<?php else: ?>

    <!-- Filters -->
    <div class="card" style="padding:14px;">
        <form method="GET" action="reports.php"
              style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">

            <div class="form-group" style="margin:0;min-width:160px;">
                <label>Report Type</label>
                <select name="type">
                    <?php foreach (['all' => 'All Types', 'logbook' => 'Logbook',
                                    'progress' => 'Progress', 'final' => 'Final'] as $val => $lbl): ?>
                        <option value="<?= $val ?>" <?= $filterType === $val ? 'selected' : '' ?>>
                            <?= $lbl ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin:0;min-width:200px;">
                <label>Student</label>
                <select name="student_id">
                    <option value="0">All Students</option>
                    <?php foreach ($students as $st): ?>
                        <option value="<?= (int)$st['id'] ?>"
                            <?= $filterStudent === (int)$st['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($st['last_name'] . ', ' . $st['first_name'] . ' (' . $st['student_number'] . ')') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="margin-bottom:14px;">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="reports.php" class="btn btn-secondary">Clear</a>
            </div>
        </form>
    </div>

    <!-- Reports list -->
    <?php if (empty($reports)): ?>
        <div class="card">
            <p class="text-muted">No reports found for the selected filters.</p>
        </div>
    <?php else: ?>
        <p class="text-muted" style="margin-bottom:12px;"><?= count($reports) ?> report(s) found</p>

        <?php

        $byStudent = [];
        foreach ($reports as $r) {
            $byStudent[$r['student_id']][] = $r;
        }
        ?>

        <?php foreach ($byStudent as $stuId => $stuReports): ?>
            <?php $first = $stuReports[0]; ?>
            <div class="card" style="margin-bottom:16px;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:14px;">
                    <div>
                        <h3 style="margin:0;font-size:16px;color:#1e3a5f;">
                            <?= htmlspecialchars($first['first_name'] . ' ' . $first['last_name']) ?>
                        </h3>
                        <span class="text-muted">
                            <?= htmlspecialchars($first['student_number']) ?>
                            &mdash; <?= htmlspecialchars($first['programme']) ?>
                        </span>
                    </div>
                    <span class="badge badge-accepted"><?= count($stuReports) ?> report(s)</span>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Uploaded</th>
                            <th>Supervisor Feedback</th>
                            <th>File</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stuReports as $rep): ?>
                            <tr>
                                <td>
                                    <span class="badge badge-<?= $rep['report_type'] === 'final' ? 'approved' : ($rep['report_type'] === 'progress' ? 'pending' : 'accepted') ?>">
                                        <?= ucfirst($rep['report_type']) ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y H:i', strtotime($rep['uploaded_at'])) ?></td>
                                <td>
                                    <?php if ($rep['feedback']): ?>
                                        <span title="<?= htmlspecialchars($rep['feedback']) ?>" style="cursor:help;">
                                            <?= htmlspecialchars(mb_substr($rep['feedback'], 0, 60)) ?>
                                            <?= mb_strlen($rep['feedback']) > 60 ? '…' : '' ?>
                                        </span>
                                        <?php if ($rep['lec_first']): ?>
                                            <br><small class="text-muted">— <?= htmlspecialchars($rep['lec_first'] . ' ' . $rep['lec_last']) ?></small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">No feedback yet</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= BASE_URL ?>/file.php?type=report&f=<?= urlencode(basename($rep['file_path'])) ?>"
                                       target="_blank" class="btn btn-secondary btn-sm">📄 View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
