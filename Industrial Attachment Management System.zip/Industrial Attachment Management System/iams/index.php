<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header('Location: ' . dashboardUrl(currentRole()));
} else {
    header('Location: ' . BASE_URL . '/login.php');
}
exit;
