<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];

$lecProfile = $db->prepare('SELECT CONCAT(first_name," ",last_name) AS full_name FROM lecturers WHERE id = ?');
$lecProfile->execute([$lecturerId]);
$lec = $lecProfile->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = (int)($_POST['student_id'] ?? 0);
    $action    = $_POST['action'] ?? 'save_draft';
    $formType  = $_POST['form_type'] ?? 'summative';


    $chk = $db->prepare('
        SELECT sa.student_id, u.id AS user_id
        FROM supervisor_assignments sa
        JOIN students s ON sa.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE sa.student_id = ? AND sa.lecturer_id = ?
    ');
    $chk->execute([$studentId, $lecturerId]);
    $stuRow = $chk->fetch();
    if (!$stuRow) { setFlash('error','Student not found or not supervised by you.'); header('Location: summative_report.php'); exit; }

    $isDraft     = ($action === 'save_draft');
    $status      = $isDraft ? 'draft' : 'submitted';
    $submittedAt = $isDraft ? null : date('Y-m-d H:i:s');


    $si = $db->prepare('
        SELECT s.first_name, s.last_name, s.student_number, s.programme,
               c.company_name
        FROM students s
        LEFT JOIN workplace_assignments wa ON wa.student_id = s.id
        LEFT JOIN companies c ON wa.company_id = c.id
        WHERE s.id = ?
    ');
    $si->execute([$studentId]);
    $stuInfo = $si->fetch() ?: [];

    $db->beginTransaction();
    try {
        if ($formType === 'report_grade') {


            $uploadCheck = $db->prepare("SELECT id FROM reports WHERE student_id=? AND report_type='final' AND is_lecturer_report=0 LIMIT 1");
            $uploadCheck->execute([$studentId]);
            if (!$uploadCheck->fetch()) {
                throw new Exception('Cannot grade: the student has not yet uploaded their final report.');
            }
            $existing = $db->prepare('SELECT id, status FROM student_report_grades WHERE student_id = ?');
            $existing->execute([$studentId]);
            $existingRG = $existing->fetch();
            if ($existingRG && $existingRG['status'] === 'submitted' && !$isDraft) {
                throw new Exception('Report already graded and submitted.');
            }
            $maxMap = ['structure_score'=>15,'content_score'=>30,'technical_score'=>25,'analysis_score'=>20,'presentation_score'=>10];
            $scores = []; $total = 0;
            foreach ($maxMap as $field => $max) {
                $val = min(max(0,(float)($_POST[$field]??0)),(float)$max);
                $scores[$field] = $val; $total += $val;
            }
            $rgData = array_merge($scores,[
                'student_id'=>$studentId,'lecturer_id'=>$lecturerId,
                'total_score'=>$total,'feedback'=>trim($_POST['report_feedback']??''),
                'status'=>$status,'submitted_at'=>$submittedAt
            ]);
            if ($existingRG) {
                $db->prepare('UPDATE student_report_grades SET
                    structure_score=:structure_score, content_score=:content_score,
                    technical_score=:technical_score, analysis_score=:analysis_score,
                    presentation_score=:presentation_score, total_score=:total_score,
                    feedback=:feedback, status=:status, submitted_at=:submitted_at
                    WHERE student_id=:student_id'
                )->execute($rgData);
            } else {
                $db->prepare('INSERT INTO student_report_grades
                    (student_id,lecturer_id,structure_score,content_score,technical_score,
                     analysis_score,presentation_score,total_score,feedback,status,submitted_at)
                    VALUES (:student_id,:lecturer_id,:structure_score,:content_score,:technical_score,
                     :analysis_score,:presentation_score,:total_score,:feedback,:status,:submitted_at)'
                )->execute($rgData);
            }
            $db->prepare('INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)')
               ->execute([$studentId, $isDraft?'report_grade_draft':'report_grade_submitted', currentUserId(),"Score: $total/100"]);

            if (!$isDraft) {
                recomputeFinalGradeNew($db, $studentId);

                $coord = $db->query('SELECT u.id FROM coordinators c JOIN users u ON c.user_id=u.id LIMIT 1')->fetch();
                if ($coord) sendNotification($db,$coord['id'],
                    'Student final report graded for '.($stuInfo['first_name']??'').' '.($stuInfo['last_name']??'').'.',
                    BASE_URL.'/coordinator/marks_table.php');
            }
            setFlash('success', $isDraft?'Report grade draft saved.':'Report grade submitted. Coordinator notified.');

        } else {

            $existing = $db->prepare('SELECT id, status FROM academic_summative_reports WHERE student_id = ?');
            $existing->execute([$studentId]);
            $existingASR = $existing->fetch();
            if ($existingASR && $existingASR['status'] === 'submitted' && !$isDraft) {
                throw new Exception('Summative report already submitted.');
            }

            $fields = [
                'logbook_regularity'=>5,'logbook_detail'=>5,'logbook_reflection'=>5,'logbook_presentation'=>5,
                'visit_engagement'=>10,'visit_progress'=>10,
                'report_structure'=>10,'report_content'=>20,'report_technical'=>15,
                'report_analysis'=>10,'report_presentation'=>5,
            ];
            $scores = []; $total=0;
            $logbookTotal=0; $visitTotal=0; $reportTotal=0;
            foreach ($fields as $f => $max) {
                $val = min(max(0,(float)($_POST[$f]??0)),(float)$max);
                $scores[$f] = $val; $total += $val;
                if (str_starts_with($f,'logbook')) $logbookTotal += $val;
                if (str_starts_with($f,'visit'))   $visitTotal   += $val;
                if (str_starts_with($f,'report'))  $reportTotal  += $val;
            }

            $asrData = array_merge($scores,[
                'student_id'=>$studentId,'lecturer_id'=>$lecturerId,
                'student_name'=>($stuInfo['first_name']??'').' '.($stuInfo['last_name']??''),
                'student_number'=>$stuInfo['student_number']??'',
                'programme'=>$stuInfo['programme']??'',
                'company_name'=>$stuInfo['company_name']??'',
                'supervisor_name'=>$lec['full_name']??'',
                'attachment_period'=>trim($_POST['attachment_period']??''),
                'general_comments'=>trim($_POST['general_comments']??''),
                'academic_observations'=>trim($_POST['academic_observations']??''),
                'recommendation'=>$_POST['recommendation']??null,
                'logbook_total'=>$logbookTotal,'visit_total'=>$visitTotal,'report_total'=>$reportTotal,
                'total_score'=>$total,'status'=>$status,'submitted_at'=>$submittedAt,
            ]);
            if ($existingASR) {
                $db->prepare('UPDATE academic_summative_reports SET
                    student_name=:student_name, student_number=:student_number, programme=:programme,
                    company_name=:company_name, supervisor_name=:supervisor_name,
                    attachment_period=:attachment_period,
                    logbook_regularity=:logbook_regularity, logbook_detail=:logbook_detail,
                    logbook_reflection=:logbook_reflection, logbook_presentation=:logbook_presentation,
                    visit_engagement=:visit_engagement, visit_progress=:visit_progress,
                    report_structure=:report_structure, report_content=:report_content,
                    report_technical=:report_technical, report_analysis=:report_analysis,
                    report_presentation=:report_presentation,
                    general_comments=:general_comments, academic_observations=:academic_observations,
                    recommendation=:recommendation,
                    logbook_total=:logbook_total, visit_total=:visit_total, report_total=:report_total,
                    total_score=:total_score, status=:status, submitted_at=:submitted_at
                    WHERE student_id=:student_id'
                )->execute($asrData);
            } else {
                $db->prepare('INSERT INTO academic_summative_reports (
                    student_id, lecturer_id, student_name, student_number, programme,
                    company_name, supervisor_name, attachment_period,
                    logbook_regularity, logbook_detail, logbook_reflection, logbook_presentation,
                    visit_engagement, visit_progress,
                    report_structure, report_content, report_technical, report_analysis, report_presentation,
                    general_comments, academic_observations, recommendation,
                    logbook_total, visit_total, report_total, total_score, status, submitted_at
                ) VALUES (
                    :student_id, :lecturer_id, :student_name, :student_number, :programme,
                    :company_name, :supervisor_name, :attachment_period,
                    :logbook_regularity, :logbook_detail, :logbook_reflection, :logbook_presentation,
                    :visit_engagement, :visit_progress,
                    :report_structure, :report_content, :report_technical, :report_analysis, :report_presentation,
                    :general_comments, :academic_observations, :recommendation,
                    :logbook_total, :visit_total, :report_total, :total_score, :status, :submitted_at
                )')->execute($asrData);
            }
            $db->prepare('INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)')
               ->execute([$studentId,$isDraft?'acad_summative_draft':'acad_summative_submitted',currentUserId(),"Score: $total/100"]);

            if (!$isDraft) {
                recomputeFinalGradeNew($db, $studentId);

                $coord = $db->query('SELECT u.id FROM coordinators c JOIN users u ON c.user_id=u.id LIMIT 1')->fetch();
                if ($coord) sendNotification($db,$coord['id'],
                    'Academic summative report submitted for '.($stuInfo['first_name']??'').' '.($stuInfo['last_name']??'').'.',
                    BASE_URL.'/coordinator/marks_table.php');
            }
            setFlash('success',$isDraft?'Draft saved.':'Summative report submitted. Coordinator notified.');
        }
        $db->commit();
    } catch (Exception $e) { $db->rollBack(); setFlash('error','Error: '.$e->getMessage()); }
    header('Location: summative_report.php?student_id='.$studentId.'&tab='.($formType==='report_grade'?'report':'summative')); exit;
}

$students = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           asr.status AS asr_status, asr.total_score AS asr_score,
           srg.status AS srg_status, srg.total_score AS srg_score,
           wsr.status AS wsr_status, wsr.total_score AS wsr_score
    FROM supervisor_assignments sa
    JOIN students s ON sa.student_id = s.id
    LEFT JOIN academic_summative_reports asr ON asr.student_id = s.id
    LEFT JOIN student_report_grades srg ON srg.student_id = s.id
    LEFT JOIN wps_summative_reports wsr ON wsr.student_id = s.id
    WHERE sa.lecturer_id = ?
    ORDER BY s.last_name
');
$students->execute([$lecturerId]);
$myStudents = $students->fetchAll();

$selectedId = (int)($_GET['student_id'] ?? 0);
$activeTab  = $_GET['tab'] ?? 'summative';
$selStudent = null;
foreach ($myStudents as $st) { if ((int)$st['id'] === $selectedId) { $selStudent = $st; break; } }

$asrData = []; $srgData = []; $wpsSummary = [];
if ($selStudent) {
    $q = $db->prepare('SELECT * FROM academic_summative_reports WHERE student_id = ?');
    $q->execute([$selectedId]); $asrData = $q->fetch() ?: [];

    $q2 = $db->prepare('SELECT * FROM student_report_grades WHERE student_id = ?');
    $q2->execute([$selectedId]); $srgData = $q2->fetch() ?: [];


    $q3 = $db->prepare('SELECT * FROM wps_summative_reports WHERE student_id = ?');
    $q3->execute([$selectedId]); $wpsSummary = $q3->fetch() ?: [];


    $q4 = $db->prepare("SELECT file_path FROM reports WHERE student_id=? AND report_type='final' AND is_lecturer_report=0 ORDER BY uploaded_at DESC LIMIT 1");
    $q4->execute([$selectedId]); $uploadedReport = $q4->fetch();
}

$asrSubmitted = !empty($asrData['status']) && $asrData['status'] === 'submitted';
$srgSubmitted = !empty($srgData['status']) && $srgData['status'] === 'submitted';

$pageTitle = 'Academic Summative Report';
require_once __DIR__ . '/../includes/header.php';

function fv(array $data, string $key): string {
    return htmlspecialchars((string)($data[$key] ?? ''));
}
function fv_f(array $data, string $key): string {
    return isset($data[$key]) ? number_format((float)$data[$key],1) : '';
}
?>

<style>
.sr-header { background:#1e3a5f; color:#fff; padding:20px 28px; border-radius:8px 8px 0 0; }
.sr-header h1,.sr-header .page-title { color:#fff !important; }
.sr-header p { color:rgba(255,255,255,0.85); }
.sr-body   { border:1px solid #d1d5db; border-top:none; border-radius:0 0 8px 8px; padding:24px; background:#f9fafb; }
.sr-section{ margin-bottom:24px; }
.sr-section h2 { font-size:15px; color:#1e3a5f; border-bottom:2px solid #1e3a5f; padding-bottom:6px; margin-bottom:14px; }
.sr-row    { display:flex; justify-content:space-between; align-items:center; padding:10px 14px;
             border:1px solid #e5e7eb; border-radius:6px; margin-bottom:6px; }
.sr-row label { font-size:13px; color:#374151; flex:1; }
.sr-row .sr-max { font-size:11px; color:#9ca3af; margin:0 12px; }
.sr-row input { width:70px; text-align:center; padding:5px; border:1px solid #d1d5db; border-radius:4px; }
.sr-sub    { background:#eff6ff; border:1px solid #bfdbfe; padding:7px 14px; border-radius:6px;
             font-size:13px; color:#1e40af; text-align:right; margin-bottom:14px; }
.tab-btn   { padding:8px 18px; border:1px solid #d1d5db; background:#f8fafc; border-radius:6px 6px 0 0;
             cursor:pointer; font-size:13px; margin-right:4px; }
.tab-btn.active { background:#1e3a5f; color:#fff; border-color:#1e3a5f; }
.info-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
.info-item strong { display:block; font-size:11px; text-transform:uppercase; color:#9ca3af; margin-bottom:2px; }
.info-item { font-size:13px; }
</style>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Academic Supervisor — Summative &amp; Report Grading</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<div style="display:grid;grid-template-columns:260px 1fr;gap:20px;align-items:start;">

<!-- Sidebar -->
<div class="card" style="padding:16px;">
    <h2 style="font-size:15px;margin-bottom:12px;">My Students</h2>
    <?php foreach ($myStudents as $st): ?>
        <a href="summative_report.php?student_id=<?= $st['id'] ?>"
           style="display:block;padding:10px;border-radius:4px;text-decoration:none;margin-bottom:6px;
                  background:<?= $selectedId===$st['id']?'#dbeafe':'#f8fafc' ?>;
                  border:1px solid <?= $selectedId===$st['id']?'#3b82f6':'#e2e8f0' ?>;">
            <div style="font-weight:bold;font-size:13px;color:#1e3a5f;">
                <?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?>
            </div>
            <div style="font-size:11px;color:#666;"><?= htmlspecialchars($st['student_number']) ?></div>
            <div style="margin-top:4px;display:flex;flex-direction:column;gap:2px;">
                <span style="font-size:10px;background:<?= $st['asr_status']==='submitted'?'#dcfce7':'#fef3c7' ?>;
                      color:<?= $st['asr_status']==='submitted'?'#166534':'#92400e' ?>;padding:1px 6px;border-radius:8px;">
                    Summative: <?= $st['asr_status']==='submitted'?' '.number_format($st['asr_score'],1).'/100':($st['asr_status']==='draft'?'Draft':'Pending') ?>
                </span>
                <span style="font-size:10px;background:<?= $st['srg_status']==='submitted'?'#dcfce7':'#fef3c7' ?>;
                      color:<?= $st['srg_status']==='submitted'?'#166534':'#92400e' ?>;padding:1px 6px;border-radius:8px;">
                    Report Grade: <?= $st['srg_status']==='submitted'?' '.number_format($st['srg_score'],1).'/100':($st['srg_status']==='draft'?'Draft':'Pending') ?>
                </span>
            </div>
        </a>
    <?php endforeach; ?>
</div>

<!-- Main content -->
<div>
<?php if (!$selStudent): ?>
    <div class="card"><p class="text-muted">Select a student from the list.</p></div>
<?php else: ?>

    <!-- WPS Report Reference Banner -->
    <?php if (!empty($wpsSummary['status']) && $wpsSummary['status']==='submitted'): ?>
    <div class="alert alert-info" style="margin-bottom:12px;font-size:13px;">
        ️ The workplace supervisor has submitted their summative report for this student.
        Their total score: <strong><?= number_format($wpsSummary['total_score'],1) ?>/100</strong>.
        Use this as context when completing your own assessment.
    </div>
    <?php endif; ?>

    <!-- Tabs -->
    <div style="margin-bottom:0;">
        <a href="?student_id=<?= $selectedId ?>&tab=summative"
           class="tab-btn <?= $activeTab==='summative'?'active':'' ?>"> Summative Report</a>
        <a href="?student_id=<?= $selectedId ?>&tab=report"
           class="tab-btn <?= $activeTab==='report'?'active':'' ?>">📄 Grade Student Report</a>
    </div>

    <!-- ═══ TAB: SUMMATIVE REPORT ═══ -->
    <?php if ($activeTab === 'summative'): ?>

    <div class="sr-header" style="border-radius:0 8px 0 0;">
        <div style="display:flex;align-items:center;gap:16px;">
            <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="UB" style="height:48px;filter:brightness(0) invert(1);">
            <div>
                <h1 class="page-title">University of Botswana — Faculty of Science</h1>
                <p style="font-size:13px;margin:0;opacity:.8;">Department of Computer Science &amp; Information Systems</p>
                <p style="font-size:11px;margin-top:4px;opacity:.7;">SUMMATIVE REPORT — ACADEMIC SUPERVISOR — Industrial Attachment (CS)</p>
            </div>
        </div>
    </div>

    <div class="sr-body">
        <?php if ($asrSubmitted): ?>
            <div class="alert alert-success">Yes Submitted on <?= date('d M Y H:i', strtotime($asrData['submitted_at'])) ?>. Total: <strong><?= fv_f($asrData,'total_score') ?>/100</strong>.</div>
        <?php endif; ?>

        <?php if ($asrSubmitted): ?>
        <!-- Read-only view -->
        <div class="sr-section">
            <h2>A. Student &amp; Placement Information</h2>
            <div class="info-grid">
                <div class="info-item"><strong>Student Name</strong><?= fv($asrData,'student_name') ?></div>
                <div class="info-item"><strong>Student Number</strong><?= fv($asrData,'student_number') ?></div>
                <div class="info-item"><strong>Programme</strong><?= fv($asrData,'programme') ?></div>
                <div class="info-item"><strong>Company</strong><?= fv($asrData,'company_name') ?></div>
                <div class="info-item"><strong>Academic Supervisor</strong><?= fv($asrData,'supervisor_name') ?></div>
                <div class="info-item"><strong>Period</strong><?= fv($asrData,'attachment_period') ?></div>
            </div>
        </div>
        <?php
        $roSections = [
            ['B','Logbook Assessment (/20)',['logbook_regularity'=>['Regularity of Entries',5],'logbook_detail'=>['Level of Detail',5],'logbook_reflection'=>['Reflective Thinking',5],'logbook_presentation'=>['Presentation & Clarity',5]],'logbook_total'],
            ['C','Site Visit Assessment (/20)',['visit_engagement'=>['Student Engagement & Preparedness',10],'visit_progress'=>['Progress & Work Quality',10]],'visit_total'],
            ['D','Student Report Assessment (/60)',['report_structure'=>['Structure & Organisation',10],'report_content'=>['Content & Coverage',20],'report_technical'=>['Technical Depth',15],'report_analysis'=>['Analysis & Discussion',10],'report_presentation'=>['Presentation & Language',5]],'report_total'],
        ];
        foreach ($roSections as [$sec,$title,$criteria,$subKey]): ?>
        <div class="sr-section">
            <h2><?= $sec ?>. <?= $title ?></h2>
            <table><thead><tr><th>Criterion</th><th>Max</th><th>Score</th></tr></thead><tbody>
            <?php foreach ($criteria as $key => [$label,$max]): ?>
                <tr><td><?= $label ?></td><td><?= $max ?></td><td><strong><?= fv_f($asrData,$key) ?></strong></td></tr>
            <?php endforeach; ?>
            </tbody><tfoot><tr style="background:#eff6ff;"><td colspan="2"><strong>Section Total</strong></td><td><strong><?= fv_f($asrData,$subKey) ?></strong></td></tr></tfoot></table>
        </div>
        <?php endforeach; ?>
        <div class="sr-section">
            <h2>E. Comments &amp; Recommendation</h2>
            <p><strong>General Comments:</strong> <?= nl2br(fv($asrData,'general_comments')) ?></p>
            <p><strong>Academic Observations:</strong> <?= nl2br(fv($asrData,'academic_observations')) ?></p>
            <p><strong>Recommendation:</strong> <strong><?= fv($asrData,'recommendation') ?></strong></p>
        </div>
        <div style="background:#1e3a5f;color:#fff;padding:14px;border-radius:8px;text-align:center;">
            <strong>TOTAL SCORE: <?= fv_f($asrData,'total_score') ?> / 100</strong>
        </div>

        <?php else: // Editable summative form ?>
        <form method="POST">
            <input type="hidden" name="student_id" value="<?= $selectedId ?>">
            <input type="hidden" name="form_type" value="summative">

            <?php
            $sInfo = $db->prepare('SELECT s.first_name,s.last_name,s.student_number,s.programme,c.company_name FROM students s LEFT JOIN workplace_assignments wa ON wa.student_id=s.id LEFT JOIN companies c ON wa.company_id=c.id WHERE s.id=?');
            $sInfo->execute([$selectedId]); $si = $sInfo->fetch()?:[];
            ?>
            <div class="sr-section">
                <h2>A. Student &amp; Placement Information</h2>
                <div class="info-grid">
                    <div class="info-item"><strong>Student Name</strong><?= htmlspecialchars(($si['first_name']??'').' '.($si['last_name']??'')) ?></div>
                    <div class="info-item"><strong>Student Number</strong><?= htmlspecialchars($si['student_number']??'') ?></div>
                    <div class="info-item"><strong>Programme</strong><?= htmlspecialchars($si['programme']??'') ?></div>
                    <div class="info-item"><strong>Company</strong><?= htmlspecialchars($si['company_name']??'—') ?></div>
                    <div class="info-item"><strong>Academic Supervisor</strong><?= htmlspecialchars($lec['full_name']??'') ?></div>
                    <div class="info-item">
                        <strong>Attachment Period</strong>
                        <input type="text" name="attachment_period" value="<?= fv($asrData,'attachment_period') ?>"
                               placeholder="e.g. June – December 2025"
                               style="width:100%;padding:5px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;margin-top:4px;">
                    </div>
                </div>
            </div>

            <div class="sr-section">
                <h2>B. Logbook Assessment <small style="font-weight:normal;color:#6b7280;">(Max: 20)</small></h2>
                <?php foreach(['logbook_regularity'=>['Regularity of Entries',5],'logbook_detail'=>['Level of Detail & Accuracy',5],'logbook_reflection'=>['Reflective Thinking',5],'logbook_presentation'=>['Presentation & Clarity',5]] as $k=>[$lbl,$mx]): ?>
                <div class="sr-row">
                    <label><?= $lbl ?></label><span class="sr-max">Max: <?= $mx ?></span>
                    <input type="number" name="<?= $k ?>" min="0" max="<?= $mx ?>" step="0.5"
                           value="<?= fv_f($asrData,$k)?:'0' ?>" oninput="calcAsrTotal()" required>
                </div>
                <?php endforeach; ?>
                <div class="sr-sub" id="sub_logbook">Section Total: — / 20</div>
            </div>

            <div class="sr-section">
                <h2>C. Site Visit Assessment <small style="font-weight:normal;color:#6b7280;">(Max: 20)</small></h2>
                <?php foreach(['visit_engagement'=>['Student Engagement & Preparedness',10],'visit_progress'=>['Progress & Quality of Work',10]] as $k=>[$lbl,$mx]): ?>
                <div class="sr-row">
                    <label><?= $lbl ?></label><span class="sr-max">Max: <?= $mx ?></span>
                    <input type="number" name="<?= $k ?>" min="0" max="<?= $mx ?>" step="0.5"
                           value="<?= fv_f($asrData,$k)?:'0' ?>" oninput="calcAsrTotal()" required>
                </div>
                <?php endforeach; ?>
                <div class="sr-sub" id="sub_visit">Section Total: — / 20</div>
            </div>

            <div class="sr-section">
                <h2>D. Student Final Report Assessment <small style="font-weight:normal;color:#6b7280;">(Max: 60)</small></h2>
                <div class="alert alert-info" style="font-size:13px;margin-bottom:12px;">
                    📄 Grade the student's uploaded final report.
                    <?php if (!empty($uploadedReport['file_path'])): ?>
                        <a href="<?= BASE_URL ?>/<?= htmlspecialchars($uploadedReport['file_path']) ?>" target="_blank" class="btn btn-secondary btn-sm" style="margin-left:8px;">View Report</a>
                    <?php else: ?>
                        <em style="color:#92400e;">Student has not yet uploaded a final report.</em>
                    <?php endif; ?>
                </div>
                <?php foreach(['report_structure'=>['Structure & Organisation',10],'report_content'=>['Content Depth & Coverage',20],'report_technical'=>['Technical Accuracy & Depth',15],'report_analysis'=>['Analysis & Critical Discussion',10],'report_presentation'=>['Presentation, Language & Referencing',5]] as $k=>[$lbl,$mx]): ?>
                <div class="sr-row">
                    <label><?= $lbl ?></label><span class="sr-max">Max: <?= $mx ?></span>
                    <input type="number" name="<?= $k ?>" min="0" max="<?= $mx ?>" step="0.5"
                           value="<?= fv_f($asrData,$k)?:'0' ?>" oninput="calcAsrTotal()" required>
                </div>
                <?php endforeach; ?>
                <div class="sr-sub" id="sub_report">Section Total: — / 60</div>
            </div>

            <div class="sr-section">
                <h2>E. Comments &amp; Recommendation</h2>
                <div style="margin-bottom:10px;">
                    <label style="font-size:13px;font-weight:600;">General Comments</label>
                    <textarea name="general_comments" rows="3"
                              style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"><?= fv($asrData,'general_comments') ?></textarea>
                </div>
                <div style="margin-bottom:10px;">
                    <label style="font-size:13px;font-weight:600;">Academic Observations</label>
                    <textarea name="academic_observations" rows="3"
                              style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"><?= fv($asrData,'academic_observations') ?></textarea>
                </div>
                <div>
                    <label style="font-size:13px;font-weight:600;">Recommendation *</label>
                    <select name="recommendation" required style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;">
                        <option value="">— Select —</option>
                        <?php foreach(['Pass','Pass with Distinction','Fail','Deferred'] as $opt): ?>
                            <option value="<?= $opt ?>" <?= ($asrData['recommendation']??'')===$opt?'selected':'' ?>><?= $opt ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div style="background:#1e3a5f;color:#fff;padding:16px;border-radius:8px;text-align:center;margin-bottom:20px;">
                <div style="font-size:13px;opacity:.8;margin-bottom:4px;">TOTAL SCORE</div>
                <div style="font-size:36px;font-weight:bold;" id="asrGrandTotal">0.0</div>
                <div style="opacity:.7;">/ 100</div>
            </div>
            <div style="display:flex;gap:12px;align-items:center;">
                <button type="submit" name="action" value="save_draft" class="btn btn-secondary">💾 Save Draft</button>
                <button type="submit" name="action" value="submit_final" class="btn btn-success"
                        onclick="return confirm('Submit summative report? Coordinator will be notified.')"> Submit Report</button>
            </div>
        </form>
        <?php endif; ?>
    </div><!-- sr-body -->

    <!-- ═══ TAB: GRADE STUDENT REPORT ═══ -->
    <?php elseif ($activeTab === 'report'): ?>
    <div style="background:#065f46;color:#fff;padding:20px 28px;border-radius:0 8px 0 0;">
        <h1 style="font-family:var(--serif);font-size:21px;font-weight:600;color:#fff;margin-bottom:4px;">Grade Student Final Report</h1>
        <p style="font-size:13px;margin:0;opacity:.8;">
            <?= htmlspecialchars($selStudent['first_name'].' '.$selStudent['last_name']) ?>
            — <?= htmlspecialchars($selStudent['student_number']) ?>
        </p>
    </div>
    <div class="sr-body">
        <?php if ($srgSubmitted): ?>
            <div class="alert alert-success">Yes Grade submitted on <?= date('d M Y H:i',strtotime($srgData['submitted_at'])) ?>. Score: <strong><?= fv_f($srgData,'total_score') ?>/100</strong>.</div>
        <?php endif; ?>

        <?php

        $uploadQ = $db->prepare("SELECT file_path, uploaded_at FROM reports WHERE student_id=? AND report_type='final' AND is_lecturer_report=0 ORDER BY uploaded_at DESC LIMIT 1");
        $uploadQ->execute([$selectedId]); $upFile = $uploadQ->fetch();
        ?>
        <?php if ($upFile): ?>
            <div style="background:#f0fdf4;border:1px solid #bbf7d0;padding:12px 16px;border-radius:6px;margin-bottom:16px;font-size:13px;">
                📄 Student's final report uploaded on <?= date('d M Y', strtotime($upFile['uploaded_at'])) ?>.
                <a href="<?= BASE_URL ?>/file.php?f=<?= urlencode($upFile['file_path']) ?>" target="_blank" class="btn btn-primary btn-sm" style="margin-left:8px;">Open Report</a>
            </div>
        <?php else: ?>
            <div class="alert alert-warning" style="font-size:13px;"> Student has not yet uploaded their final report. Grading is locked until the student submits their report.</div>
        <?php endif; ?>

        <?php if (!$upFile): ?>
            <?php  ?>
        <?php elseif ($srgSubmitted): ?>
        <table><thead><tr><th>Criterion</th><th>Max</th><th>Score</th></tr></thead><tbody>
            <tr><td>Structure & Organisation</td><td>15</td><td><strong><?= fv_f($srgData,'structure_score') ?></strong></td></tr>
            <tr><td>Content Depth & Coverage</td><td>30</td><td><strong><?= fv_f($srgData,'content_score') ?></strong></td></tr>
            <tr><td>Technical Accuracy & Depth</td><td>25</td><td><strong><?= fv_f($srgData,'technical_score') ?></strong></td></tr>
            <tr><td>Analysis & Critical Discussion</td><td>20</td><td><strong><?= fv_f($srgData,'analysis_score') ?></strong></td></tr>
            <tr><td>Presentation & Language</td><td>10</td><td><strong><?= fv_f($srgData,'presentation_score') ?></strong></td></tr>
        </tbody><tfoot><tr style="background:#f0fdf4;"><td colspan="2"><strong>Total</strong></td><td><strong><?= fv_f($srgData,'total_score') ?>/100</strong></td></tr></tfoot></table>
        <?php if (!empty($srgData['feedback'])): ?>
            <div style="margin-top:12px;"><strong>Feedback:</strong> <p><?= nl2br(fv($srgData,'feedback')) ?></p></div>
        <?php endif; ?>
        <p class="text-muted" style="font-size:13px;margin-top:12px;">To revise, contact the coordinator.</p>

        <?php else: ?>
        <form method="POST">
            <input type="hidden" name="student_id" value="<?= $selectedId ?>">
            <input type="hidden" name="form_type" value="report_grade">
            <?php foreach([
                'structure_score'=>['Structure & Organisation',15],
                'content_score'  =>['Content Depth & Coverage',30],
                'technical_score'=>['Technical Accuracy & Depth',25],
                'analysis_score' =>['Analysis & Critical Discussion',20],
                'presentation_score'=>['Presentation, Language & Referencing',10],
            ] as $k=>[$lbl,$mx]): ?>
            <div class="sr-row">
                <label><?= $lbl ?></label><span class="sr-max">Max: <?= $mx ?></span>
                <input type="number" name="<?= $k ?>" min="0" max="<?= $mx ?>" step="0.5"
                       value="<?= fv_f($srgData,$k)?:'0' ?>" oninput="calcSrgTotal()" required>
            </div>
            <?php endforeach; ?>
            <div class="sr-sub" id="srgTotal" style="font-size:15px;font-weight:bold;padding:10px 16px;">Total: 0.0 / 100</div>
            <div style="margin-bottom:12px;">
                <label style="font-size:13px;font-weight:600;">Feedback for Student</label>
                <textarea name="report_feedback" rows="4"
                          style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"
                          placeholder="Overall feedback on the student's report..."><?= fv($srgData,'feedback') ?></textarea>
            </div>
            <div style="display:flex;gap:12px;align-items:center;">
                <button type="submit" name="action" value="save_draft" class="btn btn-secondary">💾 Save Draft</button>
                <button type="submit" name="action" value="submit_final" class="btn btn-success"
                        onclick="return confirm('Submit final report grade? Coordinator will be notified.')"> Submit Grade</button>
                <small class="text-muted">Grade is sent to coordinator upon submission.</small>
            </div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

<?php endif; // selStudent ?>
</div><!-- main -->
</div><!-- grid -->

<script>
function calcAsrTotal() {
    var groups = {
        logbook: ['logbook_regularity','logbook_detail','logbook_reflection','logbook_presentation'],
        visit:   ['visit_engagement','visit_progress'],
        report:  ['report_structure','report_content','report_technical','report_analysis','report_presentation']
    };
    var maxes = {logbook:20, visit:20, report:60};
    var grand = 0;
    for (var g in groups) {
        var sub = 0;
        groups[g].forEach(function(n){ var e=document.querySelector('[name="'+n+'"]'); if(e) sub+=parseFloat(e.value)||0; });
        grand += sub;
        var el = document.getElementById('sub_'+g);
        if (el) el.textContent = 'Section Total: '+sub.toFixed(1)+' / '+maxes[g];
    }
    var gt = document.getElementById('asrGrandTotal');
    if (gt) gt.textContent = grand.toFixed(1);
}

function calcSrgTotal() {
    var fields = ['structure_score','content_score','technical_score','analysis_score','presentation_score'];
    var total = 0;
    fields.forEach(function(n){ var e=document.querySelector('[name="'+n+'"]'); if(e) total+=parseFloat(e.value)||0; });
    var el = document.getElementById('srgTotal');
    if (el) el.textContent = 'Total: '+total.toFixed(1)+' / 100';
}
document.addEventListener('DOMContentLoaded', function(){
    if (document.getElementById('asrGrandTotal')) calcAsrTotal();
    if (document.getElementById('srgTotal')) calcSrgTotal();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
