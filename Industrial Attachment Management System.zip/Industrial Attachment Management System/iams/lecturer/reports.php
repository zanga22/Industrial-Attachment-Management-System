<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_id'])) {
    $reportId = (int)$_POST['report_id'];
    $feedback = trim($_POST['feedback'] ?? '');

    if ($feedback === '') {
        setFlash('error', 'Feedback cannot be empty.');
    } else {

        $chk = $db->prepare('
            SELECT r.id FROM reports r
            JOIN supervisor_assignments sa ON sa.student_id = r.student_id
            WHERE r.id = ? AND sa.lecturer_id = ?
        ');
        $chk->execute([$reportId, $lecturerId]);
        if ($chk->fetch()) {
            $db->prepare('UPDATE reports SET feedback = ?, lecturer_id = ? WHERE id = ?')
               ->execute([$feedback, $lecturerId, $reportId]);
            setFlash('success', 'Feedback saved successfully.');
        } else {
            setFlash('error', 'Report not found or not accessible.');
        }
    }


    $qs = http_build_query(array_filter([
        'type'       => $_POST['return_type']       ?? '',
        'student_id' => $_POST['return_student_id'] ?? '',
    ]));
    header('Location: reports.php' . ($qs ? '?' . $qs : ''));
    exit;
}

$filterType    = $_GET['type']       ?? 'all';
$filterStudent = (int)($_GET['student_id'] ?? 0);
$feedbackId    = (int)($_GET['feedback_id']  ?? 0);
$prefillStudent= (int)($_GET['student_id']   ?? 0);

$validTypes = ['all', 'logbook', 'progress', 'final'];
if (!in_array($filterType, $validTypes, true)) $filterType = 'all';

$sql = '
    SELECT r.id, r.file_path, r.report_type, r.feedback, r.uploaded_at,
           s.id AS student_id, s.first_name, s.last_name,
           s.student_number, s.programme
    FROM reports r
    JOIN students s ON r.student_id = s.id
    JOIN supervisor_assignments sa ON sa.student_id = s.id
    WHERE sa.lecturer_id = ?
';
$params = [$lecturerId];

if ($filterType !== 'all') {
    $sql .= ' AND r.report_type = ?';
    $params[] = $filterType;
}
if ($filterStudent > 0) {
    $sql .= ' AND s.id = ?';
    $params[] = $filterStudent;
}
$sql .= ' ORDER BY r.uploaded_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

$stuStmt = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number
    FROM students s
    JOIN supervisor_assignments sa ON sa.student_id = s.id
    WHERE sa.lecturer_id = ?
    ORDER BY s.last_name
');
$stuStmt->execute([$lecturerId]);
$myStudents = $stuStmt->fetchAll();

$sumStmt = $db->prepare('
    SELECT r.report_type,
           COUNT(*) AS total,
           SUM(r.feedback IS NOT NULL) AS with_feedback
    FROM reports r
    JOIN supervisor_assignments sa ON sa.student_id = r.student_id
    WHERE sa.lecturer_id = ?
    GROUP BY r.report_type
');
$sumStmt->execute([$lecturerId]);
$sumData = ['logbook' => [0,0], 'progress' => [0,0], 'final' => [0,0]];
foreach ($sumStmt->fetchAll() as $row) {
    $sumData[$row['report_type']] = [(int)$row['total'], (int)$row['with_feedback']];
}
$totalReports   = array_sum(array_column($reports, 'id') ? [count($reports)] : [0]);
$pendingFeedback = count(array_filter($reports, fn($r) => empty($r['feedback'])));

$pageTitle = 'Student Reports';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Student Reports &amp; Logbooks</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Summary stats -->
<div class="stats-grid">
    <?php foreach (['logbook' => 'Logbooks', 'progress' => 'Progress Reports', 'final' => 'Final Reports'] as $type => $label): ?>
        <div class="stat-box">
            <div class="stat-num"><?= $sumData[$type][0] ?></div>
            <div class="stat-label"><?= $label ?></div>
            <?php if ($sumData[$type][0] > 0): ?>
                <div style="font-size:11px;color:#666;margin-top:4px;">
                    <?= $sumData[$type][1] ?>/<?= $sumData[$type][0] ?> reviewed
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    <div class="stat-box">
        <div class="stat-num" style="color:<?= $pendingFeedback > 0 ? '#92400e' : '#166534' ?>">
            <?= count($reports) > 0 ? $pendingFeedback : 0 ?>
        </div>
        <div class="stat-label">Awaiting Feedback</div>
    </div>
</div>

<?php if (empty($myStudents)): ?>
    <div class="card">
        <p class="text-muted">No students have been assigned to you yet. Reports will appear here once the admin assigns students to you.</p>
    </div>
<?php else: ?>

    <!-- Filters -->
    <div class="card" style="padding:14px;">
        <form method="GET" action="reports.php"
              style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
            <div class="form-group" style="margin:0;min-width:160px;">
                <label>Report Type</label>
                <select name="type">
                    <?php foreach (['all' => 'All Types', 'logbook' => 'Logbook',
                                    'progress' => 'Progress', 'final' => 'Final'] as $val => $lbl): ?>
                        <option value="<?= $val ?>" <?= $filterType === $val ? 'selected' : '' ?>>
                            <?= $lbl ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;min-width:220px;">
                <label>Student</label>
                <select name="student_id">
                    <option value="0">All Students</option>
                    <?php foreach ($myStudents as $st): ?>
                        <option value="<?= (int)$st['id'] ?>"
                            <?= $filterStudent === (int)$st['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($st['last_name'] . ', ' . $st['first_name'] . ' (' . $st['student_number'] . ')') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="margin-bottom:14px;">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="reports.php" class="btn btn-secondary">Clear</a>
            </div>
        </form>
    </div>

    <!-- Reports -->
    <?php if (empty($reports)): ?>
        <div class="card">
            <p class="text-muted">No reports found. Students have not uploaded any reports yet.</p>
        </div>
    <?php else: ?>
        <p class="text-muted" style="margin-bottom:12px;"><?= count($reports) ?> report(s) found</p>

        <?php foreach ($reports as $rep): ?>
            <div class="card" style="margin-bottom:14px;border-left:4px solid <?= empty($rep['feedback']) ? '#f59e0b' : '#10b981' ?>;">

                <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
                    <div>
                        <strong style="font-size:15px;">
                            <a href="student_detail.php?id=<?= (int)$rep['student_id'] ?>"
                               style="color:#1e3a5f;text-decoration:none;">
                                <?= htmlspecialchars($rep['first_name'] . ' ' . $rep['last_name']) ?>
                            </a>
                        </strong>
                        <span class="text-muted" style="margin-left:8px;font-size:13px;">
                            <?= htmlspecialchars($rep['student_number']) ?> — <?= htmlspecialchars($rep['programme']) ?>
                        </span>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span class="badge badge-<?= $rep['report_type'] === 'final' ? 'approved' : ($rep['report_type'] === 'progress' ? 'pending' : 'accepted') ?>">
                            <?= ucfirst($rep['report_type']) ?>
                        </span>
                        <span class="text-muted" style="font-size:12px;">
                            <?= date('d M Y H:i', strtotime($rep['uploaded_at'])) ?>
                        </span>
                        <a href="<?= BASE_URL ?>/file.php?type=report&f=<?= urlencode(basename($rep['file_path'])) ?>"
                           target="_blank" class="btn btn-secondary btn-sm">📄 View Report</a>
                    </div>
                </div>

                <!-- Feedback section -->
                <?php if ($feedbackId === (int)$rep['id']): ?>
                    <!-- Inline feedback form (open) -->
                    <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:4px;padding:14px;">
                        <form method="POST" action="reports.php">
                            <input type="hidden" name="report_id"        value="<?= (int)$rep['id'] ?>">
                            <input type="hidden" name="return_type"      value="<?= htmlspecialchars($filterType) ?>">
                            <input type="hidden" name="return_student_id" value="<?= $filterStudent ?>">
                            <div class="form-group">
                                <label><strong>Your Feedback</strong></label>
                                <textarea name="feedback" rows="4" required
                                          placeholder="Write your feedback on this report..."
                                          style="width:100%;"><?= htmlspecialchars($rep['feedback'] ?? '') ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Save Feedback</button>
                            <a href="reports.php?type=<?= $filterType ?>&student_id=<?= $filterStudent ?>"
                               class="btn btn-secondary" style="margin-left:8px;">Cancel</a>
                        </form>
                    </div>

                <?php elseif ($rep['feedback']): ?>
                    <!-- Existing feedback display -->
                    <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:4px;padding:12px;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
                            <div>
                                <strong style="font-size:13px;color:#166534;"> Feedback given:</strong>
                                <p style="margin:4px 0 0;font-size:13px;color:#444;">
                                    <?= nl2br(htmlspecialchars($rep['feedback'])) ?>
                                </p>
                            </div>
                            <a href="?feedback_id=<?= (int)$rep['id'] ?>&type=<?= $filterType ?>&student_id=<?= $filterStudent ?>"
                               class="btn btn-secondary btn-sm" style="flex-shrink:0;">Edit</a>
                        </div>
                    </div>

                <?php else: ?>
                    <!-- No feedback yet -->
                    <div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:4px;padding:10px;
                                display:flex;justify-content:space-between;align-items:center;">
                        <span style="font-size:13px;color:#92400e;"> No feedback given yet</span>
                        <a href="?feedback_id=<?= (int)$rep['id'] ?>&type=<?= $filterType ?>&student_id=<?= $filterStudent ?>"
                           class="btn btn-primary btn-sm">+ Give Feedback</a>
                    </div>
                <?php endif; ?>

            </div>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
