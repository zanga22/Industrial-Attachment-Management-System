<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];
$studentId  = (int)($_GET['id'] ?? 0);

if ($studentId === 0) {
    setFlash('error', 'No student specified.');
    header('Location: students.php');
    exit;
}

$check = $db->prepare('
    SELECT s.id FROM students s
    JOIN supervisor_assignments sa ON sa.student_id = s.id
    WHERE s.id = ? AND sa.lecturer_id = ?
');
$check->execute([$studentId, $lecturerId]);
if (!$check->fetch()) {
    setFlash('error', 'Student not found or not assigned to you.');
    header('Location: students.php');
    exit;
}

$profile = $db->prepare('
    SELECT s.*, u.email
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
');
$profile->execute([$studentId]);
$student = $profile->fetch();

$placement = $db->prepare('
    SELECT a.id AS app_id, a.status, a.date_applied, a.reviewed_at,
           c.company_name, c.sector, c.contact_person, c.phone AS co_phone,
           c.address AS co_address
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ? AND a.status = "accepted"
    LIMIT 1
');
$placement->execute([$studentId]);
$placed = $placement->fetch();

$apps = $db->prepare('
    SELECT a.status, a.date_applied, a.reviewed_at, c.company_name, c.sector
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ?
    ORDER BY a.date_applied DESC
');
$apps->execute([$studentId]);
$allApps = $apps->fetchAll();

$reportsQ = $db->prepare('
    SELECT id, file_path, report_type, feedback, uploaded_at
    FROM reports
    WHERE student_id = ?
    ORDER BY uploaded_at DESC
');
$reportsQ->execute([$studentId]);
$reports = $reportsQ->fetchAll();

$visitsQ = $db->prepare('
    SELECT id, visit_number, visit_date, status, comments, scheduled_at, completed_at
    FROM site_visits
    WHERE student_id = ? AND lecturer_id = ?
    ORDER BY visit_number ASC
');
$visitsQ->execute([$studentId, $lecturerId]);
$siteVisits = $visitsQ->fetchAll();

$pageTitle = 'Student Detail — ' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']);
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">
        <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
    </h1>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a href="schedule_visit.php?id=<?= $studentId ?>" class="btn btn-primary btn-sm"> Schedule Site Visit</a>
        <a href="manage_visits.php?id=<?= $studentId ?>" class="btn btn-secondary btn-sm"> Visit Records</a>
        <a href="students.php" class="btn btn-secondary btn-sm">← My Students</a>
    </div>
</div>

<div class="two-col">

    <!-- ── Student profile ── -->
    <div class="card">
        <h2>Student Profile</h2>
        <table>
            <tr><th>Student Number</th><td><?= htmlspecialchars($student['student_number']) ?></td></tr>
            <tr><th>Programme</th>     <td><?= htmlspecialchars($student['programme']) ?></td></tr>
            <tr><th>Email</th>         <td><?= htmlspecialchars($student['email']) ?></td></tr>
            <tr><th>Phone</th>         <td><?= htmlspecialchars($student['phone'] ?? '—') ?></td></tr>
            <tr>
                <th>CV</th>
                <td>
                    <?php if ($student['cv_path']): ?>
                        <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($student['cv_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm">📄 View CV</a>
                    <?php else: ?>
                        <span class="text-muted">Not uploaded</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Transcript</th>
                <td>
                    <?php if ($student['transcript_path']): ?>
                        <a href="<?= BASE_URL ?>/file.php?type=transcript&f=<?= urlencode(basename($student['transcript_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm"> View Transcript</a>
                    <?php else: ?>
                        <span class="text-muted">Not uploaded</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
    </div>

    <!-- ── Placement info ── -->
    <div class="card">
        <h2>Placement Status</h2>
        <?php if ($placed): ?>
            <div class="alert alert-success" style="margin-bottom:14px;">
                Yes Student is placed at <strong><?= htmlspecialchars($placed['company_name']) ?></strong>
            </div>
            <table>
                <tr><th>Company</th>    <td><?= htmlspecialchars($placed['company_name']) ?></td></tr>
                <tr><th>Sector</th>     <td><?= htmlspecialchars($placed['sector']) ?></td></tr>
                <tr><th>Contact</th>    <td><?= htmlspecialchars($placed['contact_person']) ?></td></tr>
                <tr><th>Company Phone</th><td><?= htmlspecialchars($placed['co_phone'] ?? '—') ?></td></tr>
                <tr><th>Address</th>    <td><?= htmlspecialchars($placed['co_address'] ?? '—') ?></td></tr>
                <tr><th>Accepted On</th><td><?= date('d M Y', strtotime($placed['reviewed_at'])) ?></td></tr>
            </table>
        <?php else: ?>
            <div class="alert alert-info">
                ⏳ Student does not have an accepted placement yet.
            </div>
            <p class="text-muted" style="font-size:13px;">
                <?= count($allApps) ?> application(s) submitted.
                <?= count(array_filter($allApps, fn($a) => $a['status'] === 'pending')) ?> still pending.
            </p>
        <?php endif; ?>
    </div>

</div>

<!-- ── Reports ── -->
<div class="card">
    <h2>
        Reports &amp; Logbooks
        <span style="font-weight:normal;font-size:14px;color:#666;margin-left:8px;">
            (<?= count($reports) ?> total)
        </span>
    </h2>

    <?php if (empty($reports)): ?>
        <p class="text-muted">This student has not uploaded any reports yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Type</th><th>Uploaded</th><th>File</th><th>Your Feedback</th></tr>
            </thead>
            <tbody>
                <?php foreach ($reports as $rep): ?>
                    <tr>
                        <td>
                            <span class="badge badge-<?= $rep['report_type'] === 'final' ? 'approved' : ($rep['report_type'] === 'progress' ? 'pending' : 'accepted') ?>">
                                <?= ucfirst($rep['report_type']) ?>
                            </span>
                        </td>
                        <td><?= date('d M Y H:i', strtotime($rep['uploaded_at'])) ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>/file.php?type=report&f=<?= urlencode(basename($rep['file_path'])) ?>"
                               target="_blank" class="btn btn-secondary btn-sm">📄 View</a>
                        </td>
                        <td style="max-width:320px;">
                            <?php if ($rep['feedback']): ?>
                                <span style="font-size:13px;"><?= htmlspecialchars($rep['feedback']) ?></span>
                                <br>
                                <a href="reports.php?feedback_id=<?= (int)$rep['id'] ?>&student_id=<?= $studentId ?>"
                                   style="font-size:12px;">Edit feedback</a>
                            <?php else: ?>
                                <a href="reports.php?feedback_id=<?= (int)$rep['id'] ?>&student_id=<?= $studentId ?>"
                                   class="btn btn-primary btn-sm">+ Add Feedback</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- ── Site Visits ── -->
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <h2>
            Site Visits
            <span style="font-weight:normal;font-size:14px;color:#666;margin-left:8px;">
                (<?= count($siteVisits) ?>/2)
            </span>
        </h2>
        <div style="display:flex;gap:8px;">
            <?php if (!empty($siteVisits)): ?>
            <a href="manage_visits.php?id=<?= $studentId ?>" class="btn btn-secondary btn-sm">Manage All</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if (empty($siteVisits)): ?>
        <p class="text-muted">No site visits scheduled yet. Use the "Schedule Site Visit" button at the top right to schedule the 1st visit.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Visit</th><th>Scheduled Date</th><th>Status</th><th>Comments</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($siteVisits as $sv): ?>
                <tr>
                    <td><strong><?= $sv['visit_number'] === '1' ? '1st Visit' : '2nd Visit' ?></strong></td>
                    <td><?= date('d M Y H:i', strtotime($sv['visit_date'])) ?></td>
                    <td>
                        <span class="badge badge-<?= $sv['status'] === 'completed' ? 'accepted' : 'pending' ?>">
                            <?= ucfirst($sv['status']) ?>
                        </span>
                    </td>
                    <td style="max-width:280px;font-size:13px;">
                        <?= $sv['comments'] ? htmlspecialchars(mb_strimwidth($sv['comments'], 0, 100, '…')) : '<span class="text-muted">No comments yet</span>' ?>
                    </td>
                    <td>
                        <a href="manage_visits.php?id=<?= $studentId ?>" class="btn btn-secondary btn-sm">
                            <?= $sv['status'] === 'completed' ? 'View' : 'Add Comments' ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- ── Application history ── -->
<div class="card">
    <h2>Application History</h2>
    <?php if (empty($allApps)): ?>
        <p class="text-muted">No applications submitted.</p>
    <?php else: ?>
        <table>
            <thead><tr><th>Company</th><th>Sector</th><th>Date Applied</th><th>Status</th></tr></thead>
            <tbody>
                <?php foreach ($allApps as $app): ?>
                    <tr>
                        <td><?= htmlspecialchars($app['company_name']) ?></td>
                        <td><?= htmlspecialchars($app['sector']) ?></td>
                        <td><?= date('d M Y', strtotime($app['date_applied'])) ?></td>
                        <td>
                            <span class="badge badge-<?= $app['status'] ?>">
                                <?= ucfirst($app['status']) ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
