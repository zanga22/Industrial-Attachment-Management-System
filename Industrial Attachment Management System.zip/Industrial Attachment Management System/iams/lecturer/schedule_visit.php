<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];
$studentId  = (int)($_GET['id'] ?? $_POST['student_id'] ?? 0);

if ($studentId === 0) {
    setFlash('error', 'No student specified.');
    header('Location: students.php');
    exit;
}

$check = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, u.email AS student_email,
           u.id AS student_user_id
    FROM students s
    JOIN supervisor_assignments sa ON sa.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ? AND sa.lecturer_id = ?
');
$check->execute([$studentId, $lecturerId]);
$student = $check->fetch();

if (!$student) {
    setFlash('error', 'Student not found or not assigned to you.');
    header('Location: students.php');
    exit;
}

$existingQ = $db->prepare('
    SELECT visit_number, status, visit_date FROM site_visits
    WHERE student_id = ? AND lecturer_id = ?
');
$existingQ->execute([$studentId, $lecturerId]);
$existingVisits = [];
foreach ($existingQ->fetchAll() as $v) {
    $existingVisits[$v['visit_number']] = $v;
}

$availableVisits = [];
foreach (['1', '2'] as $vn) {
    if (!isset($existingVisits[$vn])) {
        $availableVisits[] = $vn;
    }
}

$wpQ = $db->prepare('
    SELECT ws.user_id AS wp_user_id
    FROM workplace_assignments wa
    JOIN workplace_supervisors ws ON wa.workplace_supervisor_id = ws.id
    WHERE wa.student_id = ?
    LIMIT 1
');
$wpQ->execute([$studentId]);
$wpSupervisor = $wpQ->fetch();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $visitNumber = $_POST['visit_number'] ?? '';
    $visitDate   = trim($_POST['visit_date'] ?? '');
    $visitTime   = trim($_POST['visit_time'] ?? '');


    if (!in_array($visitNumber, ['1', '2'], true)) {
        $errors[] = 'Please select a valid visit number.';
    }
    if (isset($existingVisits[$visitNumber])) {
        $errors[] = 'Visit ' . $visitNumber . ' has already been scheduled for this student.';
    }
    if (empty($visitDate) || empty($visitTime)) {
        $errors[] = 'Please provide both a date and time for the visit.';
    } else {
        $visitDateTime = $visitDate . ' ' . $visitTime . ':00';
        if (strtotime($visitDateTime) < time()) {
            $errors[] = 'The visit date and time must be in the future.';
        }
    }

    if (empty($errors)) {

        $insert = $db->prepare('
            INSERT INTO site_visits (student_id, lecturer_id, visit_number, visit_date)
            VALUES (?, ?, ?, ?)
        ');
        $insert->execute([$studentId, $lecturerId, $visitNumber, $visitDateTime]);


        $lecNameQ = $db->prepare('SELECT first_name, last_name FROM lecturers WHERE id = ?');
        $lecNameQ->execute([$lecturerId]);
        $lec = $lecNameQ->fetch();
        $lecName = $lec['first_name'] . ' ' . $lec['last_name'];

        $friendlyDate = date('d M Y \a\t H:i', strtotime($visitDateTime));
        $ordinal      = $visitNumber === '1' ? '1st' : '2nd';


        $notifStudent = $db->prepare('
            INSERT INTO notifications (user_id, message, link)
            VALUES (?, ?, ?)
        ');
        $notifStudent->execute([
            $student['student_user_id'],
            "Your {$ordinal} site visit has been scheduled for {$friendlyDate} by Dr/Mr/Ms {$lecName}.",
            BASE_URL . '/student/my_internship.php'
        ]);


        if ($wpSupervisor) {
            $notifWP = $db->prepare('
                INSERT INTO notifications (user_id, message, link)
                VALUES (?, ?, ?)
            ');
            $notifWP->execute([
                $wpSupervisor['wp_user_id'],
                "A {$ordinal} academic site visit for student {$student['first_name']} {$student['last_name']} has been scheduled for {$friendlyDate}.",
                BASE_URL . '/workplace_supervisor/dashboard.php'
            ]);
        }

        setFlash('success', "Visit {$ordinal} scheduled successfully for {$friendlyDate}.");
        header('Location: student_detail.php?id=' . $studentId);
        exit;
    }
}

$pageTitle = 'Schedule Site Visit — ' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']);
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Schedule Site Visit</h1>
    <a href="student_detail.php?id=<?= $studentId ?>" class="btn btn-secondary btn-sm">← Back to Student</a>
</div>

<!-- Student Info Banner -->
<div class="card" style="margin-bottom:20px;background:linear-gradient(135deg,#1a2e4a 0%,#2d5080 100%);color:#fff;border:none;">
    <div style="display:flex;align-items:center;gap:14px;">
        <div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:20px;"></div>
        <div>
            <div style="font-weight:600;font-size:16px;"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></div>
            <div style="opacity:.75;font-size:13px;"><?= htmlspecialchars($student['student_number']) ?> &nbsp;·&nbsp; <?= htmlspecialchars($student['student_email']) ?></div>
        </div>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error" style="margin-bottom:16px;">
        <?php foreach ($errors as $e): ?>
            <div> <?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Existing Visits Status -->
<?php if (!empty($existingVisits)): ?>
<div class="card" style="margin-bottom:20px;">
    <h2 style="margin-bottom:12px;">Existing Visits</h2>
    <table>
        <thead><tr><th>Visit</th><th>Scheduled Date</th><th>Status</th></tr></thead>
        <tbody>
            <?php foreach ($existingVisits as $vn => $v): ?>
            <tr>
                <td><?= $vn === '1' ? '1st Visit' : '2nd Visit' ?></td>
                <td><?= date('d M Y H:i', strtotime($v['visit_date'])) ?></td>
                <td>
                    <span class="badge badge-<?= $v['status'] === 'completed' ? 'accepted' : 'pending' ?>">
                        <?= ucfirst($v['status']) ?>
                    </span>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php if (empty($availableVisits)): ?>
    <div class="card">
        <div class="alert alert-info">
            Yes Both site visits (1st and 2nd) have already been scheduled for this student.
        </div>
        <p style="margin-top:10px;font-size:13px;color:#666;">
            To manage existing visits, go back to the student detail page.
        </p>
    </div>
<?php else: ?>
<div class="card" style="max-width:520px;">
    <h2 style="margin-bottom:18px;">Schedule New Visit</h2>

    <form method="post" action="schedule_visit.php">
        <input type="hidden" name="student_id" value="<?= $studentId ?>">

        <div class="form-group" style="margin-bottom:18px;">
            <label style="display:block;font-weight:600;margin-bottom:6px;">Visit Number <span style="color:var(--maroon)">*</span></label>
            <?php foreach ($availableVisits as $vn): ?>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px;cursor:pointer;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--r-sm);transition:var(--ease);"
                       onmouseover="this.style.borderColor='var(--navy-l)'" onmouseout="this.style.borderColor='var(--border)'">
                    <input type="radio" name="visit_number" value="<?= $vn ?>"
                           <?= (isset($_POST['visit_number']) && $_POST['visit_number'] === $vn) ? 'checked' : '' ?>
                           required style="accent-color:var(--navy);">
                    <span>
                        <strong><?= $vn === '1' ? '1st Visit' : '2nd Visit' ?></strong>
                        <span style="color:#666;font-size:13px;margin-left:6px;">
                            — <?= $vn === '1' ? 'Initial site observation' : 'Follow-up and final assessment' ?>
                        </span>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
            <div class="form-group">
                <label style="display:block;font-weight:600;margin-bottom:6px;">
                    Preferred Date <span style="color:var(--maroon)">*</span>
                </label>
                <input type="date" name="visit_date"
                       value="<?= htmlspecialchars($_POST['visit_date'] ?? '') ?>"
                       min="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                       required
                       style="width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:var(--r-sm);font-family:var(--font);font-size:14px;">
            </div>
            <div class="form-group">
                <label style="display:block;font-weight:600;margin-bottom:6px;">
                    Preferred Time <span style="color:var(--maroon)">*</span>
                </label>
                <input type="time" name="visit_time"
                       value="<?= htmlspecialchars($_POST['visit_time'] ?? '') ?>"
                       required
                       style="width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:var(--r-sm);font-family:var(--font);font-size:14px;">
            </div>
        </div>

        <div class="alert alert-info" style="margin-bottom:16px;font-size:13px;">
             Upon confirmation, notifications will be sent automatically to the student
            <?= $wpSupervisor ? 'and their workplace supervisor' : '' ?>.
        </div>

        <div style="display:flex;gap:10px;">
            <button type="submit" class="btn btn-primary"> Confirm &amp; Schedule Visit</button>
            <a href="student_detail.php?id=<?= $studentId ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
