<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT l.*, u.email FROM lecturers l JOIN users u ON l.user_id = u.id WHERE l.id = ?');
$profile->execute([$lecturerId]);
$lecturer = $profile->fetch();

$students = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           u.email,
           (SELECT c.company_name FROM applications a JOIN companies c ON a.company_id = c.id
            WHERE a.student_id = s.id AND a.status = "accepted" LIMIT 1) AS placed_company
    FROM supervisor_assignments sa
    JOIN students s ON sa.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE sa.lecturer_id = ?
    ORDER BY s.last_name
');
$students->execute([$lecturerId]);
$myStudents = $students->fetchAll();

$pageTitle = 'Lecturer Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (empty($_SESSION['is_approved'])): ?>
    <div class="alert alert-info" style="margin-bottom:20px;">
        ⏳ <strong>Account Pending Approval</strong> — Your lecturer account is awaiting admin approval.
        You will be able to manage students and access all features once approved.
        Please check back later or contact the administrator.
    </div>
<?php endif; ?>

<h1 class="page-title">
    Welcome, <?= htmlspecialchars($lecturer['first_name'] . ' ' . $lecturer['last_name']) ?>
</h1>

<div class="two-col">
    <div class="card">
        <h2>My Profile</h2>
        <table>
            <tr><th>Department</th><td><?= htmlspecialchars($lecturer['department']) ?></td></tr>
            <tr><th>Email</th>     <td><?= htmlspecialchars($lecturer['email']) ?></td></tr>
            <tr><th>Phone</th>     <td><?= htmlspecialchars($lecturer['phone'] ?? '—') ?></td></tr>
        </table>
    </div>
    <div class="card">
        <h2>Summary</h2>
        <div class="stats-grid" style="margin-bottom:0;">
            <div class="stat-box"><div class="stat-num"><?= count($myStudents) ?></div><div class="stat-label">Assigned Students</div></div>
            <div class="stat-box">
                <div class="stat-num"><?= count(array_filter($myStudents, fn($s) => !empty($s['placed_company']))) ?></div>
                <div class="stat-label">Placed</div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <h2>My Supervised Students</h2>
    <?php if (empty($myStudents)): ?>
        <p class="text-muted">No students assigned to you yet. The admin assigns students.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>#</th><th>Student</th><th>Student No.</th><th>Programme</th><th>Email</th><th>Placed At</th></tr>
            </thead>
            <tbody>
                <?php foreach ($myStudents as $i => $st): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($st['student_number']) ?></td>
                        <td><?= htmlspecialchars($st['programme']) ?></td>
                        <td><?= htmlspecialchars($st['email']) ?></td>
                        <td>
                            <?php if ($st['placed_company']): ?>
                                <span class="badge badge-accepted"><?= htmlspecialchars($st['placed_company']) ?></span>
                            <?php else: ?>
                                <span class="text-muted">Not yet placed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
