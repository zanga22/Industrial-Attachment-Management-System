<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];
$studentId  = (int)($_GET['id'] ?? $_POST['student_id'] ?? 0);

if ($studentId === 0) {
    setFlash('error', 'No student specified.');
    header('Location: students.php');
    exit;
}

$check = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number
    FROM students s
    JOIN supervisor_assignments sa ON sa.student_id = s.id
    WHERE s.id = ? AND sa.lecturer_id = ?
');
$check->execute([$studentId, $lecturerId]);
$student = $check->fetch();

if (!$student) {
    setFlash('error', 'Student not found or not assigned to you.');
    header('Location: students.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $visitId  = (int)($_POST['visit_id'] ?? 0);
    $action   = $_POST['action'] ?? '';
    $comments = trim($_POST['comments'] ?? '');


    $visitCheck = $db->prepare('
        SELECT id, status FROM site_visits
        WHERE id = ? AND student_id = ? AND lecturer_id = ?
    ');
    $visitCheck->execute([$visitId, $studentId, $lecturerId]);
    $visit = $visitCheck->fetch();

    if (!$visit) {
        setFlash('error', 'Visit record not found.');
    } elseif ($visit['status'] === 'completed' && $action !== 'save_comments') {
        setFlash('info', 'This visit is already marked as completed.');
    } else {
        if ($action === 'save_comments') {
            $upd = $db->prepare('UPDATE site_visits SET comments = ? WHERE id = ?');
            $upd->execute([$comments ?: null, $visitId]);
            setFlash('success', 'Comments saved successfully.');
        } elseif ($action === 'complete') {
            $upd = $db->prepare('
                UPDATE site_visits
                SET comments = ?, status = "completed", completed_at = NOW()
                WHERE id = ?
            ');
            $upd->execute([$comments ?: null, $visitId]);


            $stuUser = $db->prepare('SELECT user_id FROM students WHERE id = ?');
            $stuUser->execute([$studentId]);
            $stuUserId = $stuUser->fetchColumn();

            $visitNumQ = $db->prepare('SELECT visit_number FROM site_visits WHERE id = ?');
            $visitNumQ->execute([$visitId]);
            $vn      = $visitNumQ->fetchColumn();
            $ordinal = $vn === '1' ? '1st' : '2nd';

            $notif = $db->prepare('INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)');
            $notif->execute([
                $stuUserId,
                "Your {$ordinal} site visit has been marked as completed by your academic supervisor. Comments have been added.",
                BASE_URL . '/student/my_internship.php'
            ]);

            setFlash('success', 'Visit marked as completed and student has been notified.');
        }
    }

    header('Location: manage_visits.php?id=' . $studentId);
    exit;
}

$visitsQ = $db->prepare('
    SELECT id, visit_number, visit_date, status, comments, scheduled_at, completed_at
    FROM site_visits
    WHERE student_id = ? AND lecturer_id = ?
    ORDER BY visit_number ASC
');
$visitsQ->execute([$studentId, $lecturerId]);
$visits = $visitsQ->fetchAll();

$pageTitle = 'Site Visits — ' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']);
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Site Visit Records</h1>
    <div style="display:flex;gap:8px;">
        <a href="schedule_visit.php?id=<?= $studentId ?>" class="btn btn-primary btn-sm"> Schedule Visit</a>
        <a href="student_detail.php?id=<?= $studentId ?>" class="btn btn-secondary btn-sm">← Back to Student</a>
    </div>
</div>

<!-- Student Banner -->
<div class="card" style="margin-bottom:20px;background:linear-gradient(135deg,#1a2e4a,#2d5080);color:#fff;border:none;">
    <div style="display:flex;align-items:center;gap:14px;">
        <div style="width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:18px;"></div>
        <div>
            <div style="font-weight:600;"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></div>
            <div style="opacity:.75;font-size:13px;"><?= htmlspecialchars($student['student_number']) ?></div>
        </div>
    </div>
</div>

<?php if (empty($visits)): ?>
    <div class="card">
        <div class="alert alert-info">No site visits have been scheduled for this student yet.</div>
        <p style="margin-top:10px;">
            <a href="schedule_visit.php?id=<?= $studentId ?>" class="btn btn-primary btn-sm"> Schedule First Visit</a>
        </p>
    </div>
<?php else: ?>

    <?php foreach ($visits as $visit): ?>
    <?php
        $vn      = $visit['visit_number'];
        $ordinal = $vn === '1' ? '1st' : '2nd';
        $done    = $visit['status'] === 'completed';
    ?>
    <div class="card" style="margin-bottom:20px;border-left:4px solid <?= $done ? 'var(--maroon)' : 'var(--gold)' ?>;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
            <div>
                <h2 style="font-size:17px;margin-bottom:4px;"><?= $ordinal ?> Site Visit</h2>
                <div style="font-size:13px;color:#666;">
                    Scheduled: <strong><?= date('d M Y \a\t H:i', strtotime($visit['visit_date'])) ?></strong>
                    &nbsp;·&nbsp; Arranged on <?= date('d M Y', strtotime($visit['scheduled_at'])) ?>
                    <?php if ($done && $visit['completed_at']): ?>
                        &nbsp;·&nbsp; Completed <?= date('d M Y', strtotime($visit['completed_at'])) ?>
                    <?php endif; ?>
                </div>
            </div>
            <span class="badge badge-<?= $done ? 'accepted' : 'pending' ?>" style="flex-shrink:0;">
                <?= $done ? 'Yes Completed' : '⏳ Scheduled' ?>
            </span>
        </div>

        <form method="post" action="manage_visits.php">
            <input type="hidden" name="student_id" value="<?= $studentId ?>">
            <input type="hidden" name="visit_id" value="<?= (int)$visit['id'] ?>">

            <div class="form-group" style="margin-bottom:14px;">
                <label style="display:block;font-weight:600;margin-bottom:6px;">
                    Supervisor Comments / Observations
                </label>
                <textarea name="comments" rows="4"
                    placeholder="Summarise your observations from this visit — student's performance, workplace environment, areas of concern, commendations, etc."
                    style="width:100%;padding:10px 12px;border:1.5px solid var(--border);border-radius:var(--r-sm);font-family:var(--font);font-size:14px;resize:vertical;"
                ><?= htmlspecialchars($visit['comments'] ?? '') ?></textarea>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" name="action" value="save_comments" class="btn btn-secondary btn-sm">
                    💾 Save Comments
                </button>
                <?php if (!$done): ?>
                <button type="submit" name="action" value="complete" class="btn btn-primary btn-sm"
                    onclick="return confirm('Mark this visit as completed? This will notify the student.')">
                    Yes Mark as Completed
                </button>
                <?php else: ?>
                <span style="font-size:13px;color:var(--muted);padding:6px 0;">Visit already completed — you can still edit comments above.</span>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <?php endforeach; ?>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
