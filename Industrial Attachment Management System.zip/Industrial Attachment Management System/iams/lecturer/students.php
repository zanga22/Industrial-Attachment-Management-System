<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('lecturer');
requireApproved();

$db         = getDB();
$lecturerId = (int)$_SESSION['profile_id'];

$students = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number,
           s.programme, s.cv_path, s.transcript_path, u.email,
           (SELECT c.company_name FROM applications a
            JOIN companies c ON a.company_id = c.id
            WHERE a.student_id = s.id AND a.status = "accepted" LIMIT 1) AS placed_company,
           (SELECT COUNT(*) FROM reports r WHERE r.student_id = s.id) AS report_count
    FROM supervisor_assignments sa
    JOIN students s ON sa.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE sa.lecturer_id = ?
    ORDER BY s.last_name
');
$students->execute([$lecturerId]);
$myStudents = $students->fetchAll();

$pageTitle = 'My Students';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h1 class="page-title">My Supervised Students</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<?php if (empty($myStudents)): ?>
    <div class="card">
        <p class="text-muted">No students have been assigned to you yet. The admin will assign students.</p>
    </div>
<?php else: ?>
    <div class="card">
        <p class="text-muted" style="margin-bottom:12px;"><?= count($myStudents) ?> student(s) assigned to you.</p>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Name</th><th>Student No.</th><th>Programme</th>
                    <th>Email</th><th>Placed At</th><th>Documents</th><th>Reports</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($myStudents as $i => $st): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($st['student_number']) ?></td>
                        <td><?= htmlspecialchars($st['programme']) ?></td>
                        <td><?= htmlspecialchars($st['email']) ?></td>
                        <td>
                            <?php if ($st['placed_company']): ?>
                                <span class="badge badge-accepted"><?= htmlspecialchars($st['placed_company']) ?></span>
                            <?php else: ?>
                                <span class="text-muted">Not placed</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($st['cv_path']): ?>
                                <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($st['cv_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm">CV</a>
                            <?php endif; ?>
                            <?php if ($st['transcript_path']): ?>
                                <a href="<?= BASE_URL ?>/file.php?type=transcript&f=<?= urlencode(basename($st['transcript_path'])) ?>" target="_blank" class="btn btn-secondary btn-sm">Transcript</a>
                            <?php endif; ?>
                            <?php if (!$st['cv_path'] && !$st['transcript_path']): ?>
                                <span class="text-muted">None</span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$st['report_count'] ?> uploaded</td>
                        <td>
                            <a href="student_detail.php?id=<?= (int)$st['id'] ?>"
                               class="btn btn-primary btn-sm">View Details</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
