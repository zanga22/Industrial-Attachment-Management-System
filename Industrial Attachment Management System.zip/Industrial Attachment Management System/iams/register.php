<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) { header('Location: ' . dashboardUrl(currentRole())); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? '';
} else {
    $role = $_GET['role'] ?? '';
}
$role = in_array($role, ['student','company','lecturer','coordinator','workplace_supervisor'], true) ? $role : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $role !== '') {
    $db = getDB();
    $email    = trim($_POST['email']    ?? '');
    $password =      $_POST['password'] ?? '';
    $confirm  =      $_POST['confirm']  ?? '';

    if ($email === '') $errors[] = 'Email is required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    else {
        $chk = $db->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$email]);
        if ($chk->fetch()) $errors[] = 'That email address is already registered.';
    }
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if ($role === 'student') {
        $firstName     = trim($_POST['first_name']     ?? '');
        $lastName      = trim($_POST['last_name']      ?? '');
        $studentNumber = trim($_POST['student_number'] ?? '');
        $programme     = trim($_POST['programme']      ?? '');
        $phone         = trim($_POST['phone']          ?? '');
        if ($firstName === '')     $errors[] = 'First name is required.';
        if ($lastName === '')      $errors[] = 'Last name is required.';
        if ($studentNumber === '') $errors[] = 'Student number is required.';
        if ($programme === '')     $errors[] = 'Programme is required.';
        if (empty($errors)) {
            $chk2 = $db->prepare('SELECT id FROM students WHERE student_number = ?');
            $chk2->execute([$studentNumber]);
            if ($chk2->fetch()) $errors[] = 'That student number is already registered.';
        }
    } elseif ($role === 'company') {
        $companyName   = trim($_POST['company_name']   ?? '');
        $sector        = trim($_POST['sector']         ?? '');
        $contactPerson = trim($_POST['contact_person'] ?? '');
        $phone         = trim($_POST['phone']          ?? '');
        $address       = trim($_POST['address']        ?? '');
        if ($companyName === '')   $errors[] = 'Company name is required.';
        if ($sector === '')        $errors[] = 'Sector is required.';
        if ($contactPerson === '') $errors[] = 'Contact person name is required.';
    } elseif ($role === 'lecturer') {
        $firstName  = trim($_POST['first_name']  ?? '');
        $lastName   = trim($_POST['last_name']   ?? '');
        $department = trim($_POST['department']  ?? '');
        $phone      = trim($_POST['phone']       ?? '');
        if ($firstName === '')  $errors[] = 'First name is required.';
        if ($lastName === '')   $errors[] = 'Last name is required.';
        if ($department === '') $errors[] = 'Department is required.';
    } elseif ($role === 'coordinator') {
        $firstName  = trim($_POST['first_name']  ?? '');
        $lastName   = trim($_POST['last_name']   ?? '');
        $department = trim($_POST['department']  ?? '');
        $phone      = trim($_POST['phone']       ?? '');
        if ($firstName === '')  $errors[] = 'First name is required.';
        if ($lastName === '')   $errors[] = 'Last name is required.';
        if ($department === '') $errors[] = 'Department is required.';
    } elseif ($role === 'workplace_supervisor') {
        $firstName  = trim($_POST['first_name']  ?? '');
        $lastName   = trim($_POST['last_name']   ?? '');
        $jobTitle   = trim($_POST['job_title']   ?? '');
        $department = trim($_POST['department']  ?? '');
        $phone      = trim($_POST['phone']       ?? '');
        $companyCode = trim($_POST['company_code'] ?? '');
        if ($firstName === '')   $errors[] = 'First name is required.';
        if ($lastName === '')    $errors[] = 'Last name is required.';
        if ($companyCode === '') $errors[] = 'Company email is required to link your account.';
        else {

            $chkCo = $db->prepare('SELECT c.id FROM companies c JOIN users u ON c.user_id = u.id WHERE u.email = ? AND c.is_approved = 1');
            $chkCo->execute([$companyCode]);
            $coRow = $chkCo->fetch();
            if (!$coRow) $errors[] = 'No approved company found with that email. Contact your company admin.';
            else $linkedCompanyId = (int)$coRow['id'];
        }
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $db->prepare('INSERT INTO users (email, password, role) VALUES (?, ?, ?)')->execute([$email, $hash, $role]);
            $userId = (int)$db->lastInsertId();

            if ($role === 'student') {
                $db->prepare('INSERT INTO students (user_id, first_name, last_name, student_number, programme, phone) VALUES (?, ?, ?, ?, ?, ?)')
                   ->execute([$userId, $firstName, $lastName, $studentNumber, $programme, $phone ?: null]);
            } elseif ($role === 'company') {
                $db->prepare('INSERT INTO companies (user_id, company_name, sector, contact_person, phone, address, capacity) VALUES (?, ?, ?, ?, ?, ?, 0)')
                   ->execute([$userId, $companyName, $sector, $contactPerson, $phone ?: null, $address ?: null]);
            } elseif ($role === 'lecturer') {
                $db->prepare('INSERT INTO lecturers (user_id, first_name, last_name, department, phone) VALUES (?, ?, ?, ?, ?)')
                   ->execute([$userId, $firstName, $lastName, $department, $phone ?: null]);
            } elseif ($role === 'coordinator') {
                $db->prepare('INSERT INTO coordinators (user_id, first_name, last_name, department, phone) VALUES (?, ?, ?, ?, ?)')
                   ->execute([$userId, $firstName, $lastName, $department, $phone ?: null]);
            } elseif ($role === 'workplace_supervisor') {
                $db->prepare('INSERT INTO workplace_supervisors (user_id, company_id, first_name, last_name, job_title, department, phone) VALUES (?, ?, ?, ?, ?, ?, ?)')
                   ->execute([$userId, $linkedCompanyId, $firstName, $lastName, $jobTitle ?: null, $department ?: null, $phone ?: null]);
            }

            $db->commit();
            setFlash('success', 'Registration successful! Please log in.');
            header('Location: ' . BASE_URL . '/login.php'); exit;
        } catch (Exception $e) {
            $db->rollBack();
            $errors[] = 'Registration failed. Please try again. (' . $e->getMessage() . ')';
        }
    }
}

$pageTitle = 'Register';
require_once __DIR__ . '/includes/header.php';
function old(string $key, string $default = ''): string { return htmlspecialchars($_POST[$key] ?? $default); }
?>
<div style="max-width:540px;margin:30px auto;">
<div class="card">
<?php if ($role === ''): ?>
    <h2>Create an Account</h2>
    <p class="text-muted" style="margin-bottom:20px;">Select how you want to register. Admin accounts are created by the system administrator.</p>
    <div style="display:flex;flex-direction:column;gap:12px;">
        <a href="register.php?role=student" style="display:block;padding:16px 20px;border:2px solid #374151;border-radius:6px;text-decoration:none;color:#374151;font-size:15px;font-weight:bold;">I am a Student</a>
        <a href="register.php?role=company" style="display:block;padding:16px 20px;border:2px solid #374151;border-radius:6px;text-decoration:none;color:#374151;font-size:15px;font-weight:bold;">I represent a Company</a>
        <a href="register.php?role=lecturer" style="display:block;padding:16px 20px;border:2px solid #374151;border-radius:6px;text-decoration:none;color:#374151;font-size:15px;font-weight:bold;">I am a Lecturer</a>
        <a href="register.php?role=coordinator" style="display:block;padding:16px 20px;border:2px solid #374151;border-radius:6px;text-decoration:none;color:#374151;font-size:15px;font-weight:bold;">I am a Coordinator</a>
        <a href="register.php?role=workplace_supervisor" style="display:block;padding:16px 20px;border:2px solid #374151;border-radius:6px;text-decoration:none;color:#374151;font-size:15px;font-weight:bold;">I am a Workplace Supervisor</a>
    </div>
    <p class="text-muted text-center mt-20">Already have an account? <a href="login.php">Login here</a></p>
<?php else:
    $roleLabels = ['student'=>'Student','company'=>'Company','lecturer'=>'Lecturer','coordinator'=>'Coordinator','workplace_supervisor'=>'Workplace Supervisor'];
?>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
        <h2 style="margin:0;">Register as <?= $roleLabels[$role] ?></h2>
        <a href="register.php" style="font-size:13px;color:#666;">← Change role</a>
    </div>
    <p class="text-muted" style="margin-bottom:16px;font-size:13px;">Admin accounts are created by the system administrator.</p>
    <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
    <form method="POST" action="register.php" novalidate>
        <input type="hidden" name="role" value="<?= htmlspecialchars($role) ?>">
        <div class="form-group"><label>Email Address *</label><input type="email" name="email" required value="<?= old('email') ?>" placeholder="your@email.com" autofocus></div>
        <div class="form-group"><label>Password *</label><input type="password" name="password" required minlength="6" placeholder="Minimum 6 characters"></div>
        <div class="form-group"><label>Confirm Password *</label><input type="password" name="confirm" required placeholder="Repeat your password"></div>
        <hr style="margin:16px 0;">
        <?php if ($role === 'student'): ?>
            <p><strong>Student Details</strong></p>
            <div class="two-col">
                <div class="form-group"><label>First Name *</label><input type="text" name="first_name" required autocomplete="off" value="<?= old('first_name') ?>" placeholder="First name"></div>
                <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" required autocomplete="off" value="<?= old('last_name') ?>" placeholder="Last name"></div>
            </div>
            <div class="form-group"><label>Student Number *</label><input type="text" name="student_number" required value="<?= old('student_number') ?>" placeholder="e.g. 201912345"></div>
            <div class="form-group"><label>Programme *</label><input type="text" name="programme" required value="<?= old('programme') ?>" placeholder="e.g. BSc Computer Science"></div>
            <div class="form-group"><label>Phone <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="phone" value="<?= old('phone') ?>"></div>
        <?php elseif ($role === 'company'): ?>
            <p><strong>Company Details</strong></p>
            <div class="form-group"><label>Company Name *</label><input type="text" name="company_name" required value="<?= old('company_name') ?>" placeholder="Registered company name"></div>
            <div class="form-group"><label>Sector / Industry *</label><input type="text" name="sector" required value="<?= old('sector') ?>" placeholder="e.g. Information Technology"></div>
            <div class="form-group"><label>Contact Person *</label><input type="text" name="contact_person" required value="<?= old('contact_person') ?>" placeholder="Full name of HR/contact"></div>
            <div class="form-group"><label>Phone <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="phone" value="<?= old('phone') ?>"></div>
            <div class="form-group"><label>Address <span style="font-weight:normal;color:#888;">(optional)</span></label><textarea name="address" placeholder="Company physical address"><?= old('address') ?></textarea></div>
            <div class="alert alert-info" style="font-size:13px;">️ Company accounts require admin approval before you can receive applications.</div>
        <?php elseif ($role === 'lecturer' || $role === 'coordinator'): ?>
            <p><strong><?= $role === 'coordinator' ? 'Coordinator' : 'Lecturer' ?> Details</strong></p>
            <div class="two-col">
                <div class="form-group"><label>First Name *</label><input type="text" name="first_name" required autocomplete="off" value="<?= old('first_name') ?>" placeholder="First name"></div>
                <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" required autocomplete="off" value="<?= old('last_name') ?>" placeholder="Last name"></div>
            </div>
            <div class="form-group"><label>Department *</label><input type="text" name="department" required value="<?= old('department') ?>" placeholder="e.g. Computer Science"></div>
            <div class="form-group"><label>Phone <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="phone" value="<?= old('phone') ?>"></div>
        <?php elseif ($role === 'workplace_supervisor'): ?>
            <p><strong>Workplace Supervisor Details</strong></p>
            <div class="two-col">
                <div class="form-group"><label>First Name *</label><input type="text" name="first_name" required autocomplete="off" value="<?= old('first_name') ?>" placeholder="First name"></div>
                <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" required autocomplete="off" value="<?= old('last_name') ?>" placeholder="Last name"></div>
            </div>
            <div class="form-group"><label>Job Title <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="job_title" value="<?= old('job_title') ?>" placeholder="e.g. Senior Software Engineer"></div>
            <div class="form-group"><label>Department <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="department" value="<?= old('department') ?>" placeholder="e.g. IT Department"></div>
            <div class="form-group"><label>Phone <span style="font-weight:normal;color:#888;">(optional)</span></label><input type="text" name="phone" value="<?= old('phone') ?>"></div>
            <div class="form-group">
                <label>Company Email Address *</label>
                <input type="email" name="company_code" required value="<?= old('company_code') ?>" placeholder="The registered email of your company">
                <small>Enter the email address your company used to register in IAMS. This links your account to the correct company.</small>
            </div>
            <div class="alert alert-info" style="font-size:13px;">️ Your company must be approved in the system before you can register as a workplace supervisor.</div>
        <?php endif; ?>
        <div class="form-group mt-20"><button type="submit" class="btn btn-primary" style="width:100%">Create Account</button></div>
    </form>
    <p class="text-muted text-center mt-10">Already have an account? <a href="login.php">Login here</a></p>
<?php endif; ?>
</div>
</div>
<script>
var form = document.querySelector('form[method="POST"]');
if (form) { form.addEventListener('submit', function(e) {
    var pw = document.getElementById ? document.querySelector('[name=password]') : null;
    var cf = document.getElementById ? document.querySelector('[name=confirm]') : null;
    if (!pw || !cf) return;
    if (pw.value.length < 6) { alert('Password must be at least 6 characters.'); e.preventDefault(); return; }
    if (pw.value !== cf.value) { alert('Passwords do not match.'); e.preventDefault(); return; }
}); }
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
