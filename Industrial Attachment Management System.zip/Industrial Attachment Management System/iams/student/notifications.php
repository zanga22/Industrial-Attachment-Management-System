<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db = getDB();

$db->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')
   ->execute([$_SESSION['user_id']]);

$notifications = $db->prepare(
    'SELECT id, message, link, is_read, created_at
     FROM notifications WHERE user_id = ?
     ORDER BY created_at DESC'
);
$notifications->execute([$_SESSION['user_id']]);
$notifs = $notifications->fetchAll();

$pageTitle = 'My Notifications';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">My Notifications</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<?php if (empty($notifs)): ?>
    <div class="card">
        <p class="text-muted">No notifications yet. You will be notified about application updates, new vacancies, and company suggestions here.</p>
    </div>
<?php else: ?>
    <div class="card">
        <p class="text-muted" style="margin-bottom:14px;"><?= count($notifs) ?> notification(s)</p>
        <?php foreach ($notifs as $n): ?>
            <div style="padding:12px 0;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
                <div style="display:flex;align-items:flex-start;gap:10px;">
                    <span style="font-size:18px;margin-top:2px;">🔔</span>
                    <div>
                        <p style="margin:0;font-size:14px;"><?= htmlspecialchars($n['message']) ?></p>
                        <?php if ($n['link']): ?>
                            <a href="<?= htmlspecialchars($n['link']) ?>"
                               style="font-size:12px;color:#2563eb;">View →</a>
                        <?php endif; ?>
                    </div>
                </div>
                <small class="text-muted" style="white-space:nowrap;font-size:12px;">
                    <?= date('d M Y H:i', strtotime($n['created_at'])) ?>
                </small>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
