<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

const ALLOWED_MIME = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const ALLOWED_EXT  = ['pdf', 'doc', 'docx'];
const MAX_SIZE_MB   = 5;
const MAX_SIZE_B    = MAX_SIZE_MB * 1024 * 1024;

$errors  = [];
$success = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadType = $_POST['upload_type'] ?? '';

    if (!in_array($uploadType, ['cv', 'transcript'], true)) {
        $errors[] = 'Invalid upload type.';
    }


    if (empty($errors)) {
        $fileKey = 'document';
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] === UPLOAD_ERR_NO_FILE) {
            $errors[] = 'Please choose a file to upload.';
        } elseif ($_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'File upload error (code ' . $_FILES[$fileKey]['error'] . '). Please try again.';
        }
    }

    if (empty($errors)) {
        $file     = $_FILES[$fileKey];
        $origName = $file['name'];
        $tmpPath  = $file['tmp_name'];
        $fileSize = $file['size'];


        if ($fileSize > MAX_SIZE_B) {
            $errors[] = 'File is too large. Maximum allowed size is ' . MAX_SIZE_MB . ' MB.';
        }


        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if (!in_array($ext, ALLOWED_EXT, true)) {
            $errors[] = 'Unsupported file type ".' . htmlspecialchars($ext) . '". '
                      . 'Only PDF, DOC, and DOCX files are accepted.';
        }


        if (empty($errors)) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($tmpPath);
            if (!in_array($mime, ALLOWED_MIME, true)) {
                $errors[] = 'File content does not match an accepted document type. '
                          . 'Please upload a PDF, DOC, or DOCX file.';
            }
        }


        if (empty($errors)) {
            $destDir = __DIR__ . '/../uploads/' . $uploadType . '/';
            if (!is_dir($destDir)) {
                mkdir($destDir, 0755, true);
            }


            $newName = 'student_' . $studentId . '_' . time() . '.' . $ext;
            $destPath = $destDir . $newName;

            if (move_uploaded_file($tmpPath, $destPath)) {

                $col = ($uploadType === 'cv') ? 'cv_path' : 'transcript_path';
                $upd = $db->prepare("UPDATE students SET {$col} = ? WHERE id = ?");
                $upd->execute([$newName, $studentId]);
                $success[] = ucfirst($uploadType) . ' uploaded successfully.';
            } else {
                $errors[] = 'Could not save the file. Please check folder permissions.';
            }
        }
    }
}

$profile = $db->prepare('SELECT cv_path, transcript_path FROM students WHERE id = ?');
$profile->execute([$studentId]);
$student = $profile->fetch();

$pageTitle = 'Upload Documents';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">Upload Documents</h1>

<?php foreach ($errors as $e): ?>
    <div class="alert alert-error"><?= htmlspecialchars($e) ?></div>
<?php endforeach; ?>
<?php foreach ($success as $s): ?>
    <div class="alert alert-success"><?= htmlspecialchars($s) ?></div>
<?php endforeach; ?>

<div class="alert alert-info">
    Accepted formats: <strong>PDF, DOC, DOCX</strong> &mdash; Maximum file size: <strong><?= MAX_SIZE_MB ?> MB</strong>
</div>

<div class="two-col">

<!-- ── Upload CV ── -->
<div class="card">
    <h2>Curriculum Vitae (CV)</h2>
    <?php if ($student['cv_path']): ?>
        <p class="text-muted" style="margin-bottom:10px;">
            Current file: <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($student['cv_path'])) ?>" target="_blank">
                <?= htmlspecialchars($student['cv_path']) ?>
            </a>
        </p>
    <?php else: ?>
        <p class="text-muted" style="margin-bottom:10px;">No CV uploaded yet.</p>
    <?php endif; ?>

    <form method="POST" action="upload.php" enctype="multipart/form-data"
          onsubmit="return validateUpload(this)">
        <input type="hidden" name="upload_type" value="cv">
        <div class="form-group">
            <label for="cv_doc">Select CV file *</label>
            <input type="file" id="cv_doc" name="document"
                   accept=".pdf,.doc,.docx"
                   required>
            <small>PDF, DOC or DOCX — max <?= MAX_SIZE_MB ?>MB</small>
        </div>
        <button type="submit" class="btn btn-primary">Upload CV</button>
    </form>
</div>

<!-- ── Upload Transcript ── -->
<div class="card">
    <h2>Academic Transcript</h2>
    <?php if ($student['transcript_path']): ?>
        <p class="text-muted" style="margin-bottom:10px;">
            Current file: <a href="<?= BASE_URL ?>/file.php?type=transcript&f=<?= urlencode(basename($student['transcript_path'])) ?>" target="_blank">
                <?= htmlspecialchars($student['transcript_path']) ?>
            </a>
        </p>
    <?php else: ?>
        <p class="text-muted" style="margin-bottom:10px;">No transcript uploaded yet.</p>
    <?php endif; ?>

    <form method="POST" action="upload.php" enctype="multipart/form-data"
          onsubmit="return validateUpload(this)">
        <input type="hidden" name="upload_type" value="transcript">
        <div class="form-group">
            <label for="tr_doc">Select Transcript file *</label>
            <input type="file" id="tr_doc" name="document"
                   accept=".pdf,.doc,.docx"
                   required>
            <small>PDF, DOC or DOCX — max <?= MAX_SIZE_MB ?>MB</small>
        </div>
        <button type="submit" class="btn btn-primary">Upload Transcript</button>
    </form>
</div>

</div>

<script>
const MAX_MB = <?= MAX_SIZE_MB ?>;

function validateUpload(form) {
    const input = form.querySelector('input[type="file"]');
    if (!input.files.length) {
        alert('Please select a file before uploading.');
        return false;
    }
    const file = input.files[0];
    const name = file.name.toLowerCase();
    const allowed = ['.pdf', '.doc', '.docx'];
    const hasValidExt = allowed.some(ext => name.endsWith(ext));

    if (!hasValidExt) {
        alert('Unsupported file type. Only PDF, DOC, and DOCX are allowed.');
        return false;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
        alert('File is too large. Maximum size is ' + MAX_MB + ' MB.');
        return false;
    }
    return true;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
