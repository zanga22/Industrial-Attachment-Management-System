<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw_id'])) {
    $appId = (int)$_POST['withdraw_id'];
    $upd = $db->prepare("UPDATE applications SET status = 'withdrawn'
                          WHERE id = ? AND student_id = ? AND status = 'pending'");
    $upd->execute([$appId, $studentId]);
    setFlash('success', 'Application withdrawn.');
    header('Location: applications.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['offer_response'])) {
    $appId    = (int)$_POST['app_id'];
    $response = $_POST['offer_response'];

    if (!in_array($response, ['accepted', 'rejected'], true)) {
        setFlash('error', 'Invalid response.');
        header('Location: applications.php');
        exit;
    }


    $chk = $db->prepare('
        SELECT a.id, a.company_id, c.company_name
        FROM applications a
        JOIN companies c ON a.company_id = c.id
        WHERE a.id = ? AND a.student_id = ? AND a.status = "offered"
    ');
    $chk->execute([$appId, $studentId]);
    $offer = $chk->fetch();

    if (!$offer) {
        setFlash('error', 'Offer not found or already responded to.');
        header('Location: applications.php');
        exit;
    }

    $db->beginTransaction();
    try {
        if ($response === 'accepted') {

            $db->prepare("UPDATE applications SET status = 'accepted', reviewed_at = NOW() WHERE id = ?")
               ->execute([$appId]);


            $db->prepare("UPDATE applications SET status = 'withdrawn', reviewed_at = NOW()
                           WHERE student_id = ? AND id != ? AND status IN ('pending', 'offered')")
               ->execute([$studentId, $appId]);


            $db->prepare("UPDATE students SET placement_locked = 1 WHERE id = ?")
               ->execute([$studentId]);


            $db->prepare("INSERT INTO notifications (user_id, message, link) VALUES (
                (SELECT user_id FROM students WHERE id = ?),
                ?,
                ?
            )")->execute([
                $studentId,
                "You have accepted the placement offer from {$offer['company_name']}. All other applications have been withdrawn.",
                BASE_URL . '/student/applications.php'
            ]);

            $db->commit();
            setFlash('success', "You have accepted the placement offer from {$offer['company_name']}! Your other applications have been automatically withdrawn.");

        } else {

            $db->prepare("UPDATE applications SET status = 'rejected', reviewed_at = NOW() WHERE id = ?")
               ->execute([$appId]);

            $db->commit();
            setFlash('info', "You declined the offer from {$offer['company_name']}. You can continue applying to other companies.");
        }

    } catch (Exception $e) {
        $db->rollBack();
        setFlash('error', 'Something went wrong. Please try again.');
    }

    header('Location: applications.php');
    exit;
}

$stmt = $db->prepare('
    SELECT a.id, a.status, a.date_applied, a.cover_note, a.reviewed_at, a.offer_letter_path,
           c.company_name, c.sector, c.contact_person
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ?
    ORDER BY
        FIELD(a.status, "offered", "pending", "accepted", "rejected", "withdrawn"),
        a.date_applied DESC
');
$stmt->execute([$studentId]);
$applications = $stmt->fetchAll();

$activeCount = 0;
$hasAccepted = false;
foreach ($applications as $app) {
    if ($app['status'] === 'pending')  $activeCount++;
    if ($app['status'] === 'accepted') $hasAccepted = true;
}

$lockRow = $db->prepare('SELECT placement_locked FROM students WHERE id = ?');
$lockRow->execute([$studentId]);
$isLocked = (bool)$lockRow->fetchColumn();

$pageTitle = 'My Applications';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">My Applications</h1>
    <?php if (!$isLocked): ?>
        <a href="<?= BASE_URL ?>/student/apply.php" class="btn btn-primary">+ Apply to Company</a>
    <?php endif; ?>
</div>

<?php if ($isLocked): ?>
    <div class="alert alert-success">
        <strong>Placement Confirmed.</strong> You have accepted a placement offer. No further applications can be made.
    </div>
<?php elseif ($activeCount >= 5): ?>
    <div class="alert alert-info">
        ️ You have <strong><?= $activeCount ?> active application<?= $activeCount > 1 ? 's' : '' ?></strong> (maximum 5). Withdraw one to apply elsewhere.
    </div>
<?php else: ?>
    <div class="alert alert-info" style="font-size:13px;">
        Active applications: <strong><?= $activeCount ?> / 5</strong>
        <?= $activeCount > 0 ? ' — You can submit ' . (5 - $activeCount) . ' more.' : '' ?>
    </div>
<?php endif; ?>

<?php if (empty($applications)): ?>
    <div class="card">
        <p class="text-muted">You haven't submitted any applications yet.</p>
        <div class="mt-10">
            <a href="<?= BASE_URL ?>/student/apply.php" class="btn btn-primary">Browse Companies</a>
        </div>
    </div>
<?php else: ?>
    <?php

    $offers = array_filter($applications, fn($a) => $a['status'] === 'offered');
    $others = array_filter($applications, fn($a) => $a['status'] !== 'offered');
    ?>

    <!-- ── Pending offers — show first, prominently ── -->
    <?php foreach ($offers as $app): ?>
        <div class="card" style="margin-bottom:16px;border:2px solid #2563eb;background:#eff6ff;">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;align-items:flex-start;">
                <div>
                    <span style="font-size:12px;font-weight:bold;color:#2563eb;text-transform:uppercase;letter-spacing:1px;">🎉 Placement Offer</span>
                    <h3 style="margin:4px 0;color:#1e3a5f;font-size:18px;"><?= htmlspecialchars($app['company_name']) ?></h3>
                    <span class="text-muted"><?= htmlspecialchars($app['sector']) ?> — Contact: <?= htmlspecialchars($app['contact_person']) ?></span>
                    <br>
                    <small class="text-muted">Applied: <?= date('d M Y', strtotime($app['date_applied'])) ?></small>
                    <?php if ($app['reviewed_at']): ?>
                        &nbsp;|&nbsp;<small class="text-muted">Offer received: <?= date('d M Y', strtotime($app['reviewed_at'])) ?></small>
                    <?php endif; ?>
                    <br>
                    <p style="margin:8px 0 0;font-size:14px;color:#1e40af;">
                        <strong><?= htmlspecialchars($app['company_name']) ?></strong> has sent you a placement offer letter.
                        Please read the offer letter before deciding.
                    </p>
                    <?php if ($app['offer_letter_path']): ?>
                        <div style="margin-top:10px;">
                            <a href="<?= BASE_URL ?>/file.php?type=offer_letter&f=<?= urlencode($app['offer_letter_path']) ?>"
                               target="_blank"
                               class="btn btn-primary btn-sm"
                               style="font-size:14px;padding:8px 16px;">
                                📄 Read Offer Letter
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                    <form method="POST"
                          onsubmit="return confirm('Accept this placement offer? All your other pending applications will be automatically withdrawn.')">
                        <input type="hidden" name="app_id"        value="<?= (int)$app['id'] ?>">
                        <input type="hidden" name="offer_response" value="accepted">
                        <button type="submit" class="btn btn-success" style="padding:10px 22px;font-size:15px;">
                             Accept Offer
                        </button>
                    </form>
                    <form method="POST"
                          onsubmit="return confirm('Decline this offer? You will keep your other applications.')">
                        <input type="hidden" name="app_id"        value="<?= (int)$app['id'] ?>">
                        <input type="hidden" name="offer_response" value="rejected">
                        <button type="submit" class="btn btn-danger" style="padding:10px 22px;font-size:15px;">
                            ✗ Decline Offer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <!-- ── All other applications ── -->
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Company</th>
                    <th>Sector</th>
                    <th>Applied</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; foreach ($others as $app): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td>
                            <strong><?= htmlspecialchars($app['company_name']) ?></strong><br>
                            <small class="text-muted">Contact: <?= htmlspecialchars($app['contact_person']) ?></small>
                            <?php if ($app['cover_note']): ?>
                                <br><small class="text-muted"><em>Note: <?= htmlspecialchars(mb_substr($app['cover_note'], 0, 60)) ?>…</em></small>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($app['sector']) ?></td>
                        <td><?= date('d M Y', strtotime($app['date_applied'])) ?></td>
                        <td>
                            <span class="badge badge-<?= $app['status'] === 'offered' ? 'accepted' : $app['status'] ?>">
                                <?= $app['status'] === 'offered' ? 'Offer Sent' : ucfirst($app['status']) ?>
                            </span>
                            <?php if ($app['reviewed_at']): ?>
                                <br><small class="text-muted"><?= date('d M Y', strtotime($app['reviewed_at'])) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($app['status'] === 'pending'): ?>
                                <form method="POST" onsubmit="return confirm('Withdraw this application?')">
                                    <input type="hidden" name="withdraw_id" value="<?= (int)$app['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Withdraw</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted" style="font-size:13px;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
