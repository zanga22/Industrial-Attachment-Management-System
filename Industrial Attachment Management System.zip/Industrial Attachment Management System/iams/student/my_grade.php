<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

$fg = $db->prepare('SELECT * FROM final_grades WHERE student_id = ?');
$fg->execute([$studentId]);
$grade = $fg->fetch();

$wpsReport = [];
$q = $db->prepare('SELECT * FROM wps_summative_reports WHERE student_id=? AND status="submitted"');
$q->execute([$studentId]); $wpsReport = $q->fetch() ?: [];

$asrReport = [];
$q2 = $db->prepare('SELECT * FROM academic_summative_reports WHERE student_id=? AND status="submitted"');
$q2->execute([$studentId]); $asrReport = $q2->fetch() ?: [];

$srgReport = [];
$q3 = $db->prepare('SELECT * FROM student_report_grades WHERE student_id=? AND status="submitted"');
$q3->execute([$studentId]); $srgReport = $q3->fetch() ?: [];

$scale = $db->query('SELECT letter, MIN(min_score) as min_score, MAX(max_score) as max_score, description FROM grading_scale GROUP BY letter ORDER BY min_score DESC')->fetchAll();

$isPublished = $grade && $grade['status'] === 'published';

$wpsS  = $isPublished && $wpsReport ? (float)$wpsReport['total_score'] : null;
$acadS = $isPublished && $asrReport ? (float)$asrReport['total_score'] : null;
$repS  = $isPublished && $srgReport ? (float)$srgReport['total_score'] : null;
$wt    = ($wpsS!==null&&$acadS!==null&&$repS!==null)
         ? round(($wpsS*.40)+($acadS*.40)+($repS*.20),2) : null;

$pageTitle = 'My Grade';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">My Attachment Grade</h1>

<?php if (!$grade || in_array($grade['status'],['pending','partial'],true)): ?>
<div class="card">
    <div class="alert alert-info">
        ⏳ Your final grade is not yet available.
        <?php if ($grade && $grade['status']==='partial'): ?>
            One or more assessments are still pending. Your grade will appear once all three components are submitted and approved by the coordinator.
        <?php else: ?>
            Assessments have not been submitted yet. Please check back later.
        <?php endif; ?>
    </div>

</div>

<?php elseif (in_array($grade['status'],['submitted','flagged','approved'],true)): ?>
<div class="card">
    <div class="alert alert-info">
         All assessments have been submitted and are currently under coordinator review. Your final grade will be visible once published.
    </div>
</div>

<?php else: // published ?>

<!-- Grade Hero -->
<div class="card" style="text-align:center;padding:40px 24px;background:linear-gradient(135deg,#1e3a5f,#2563eb);border:none;">
    <div style="font-size:14px;color:#93c5fd;margin-bottom:8px;">Final Attachment Grade</div>
    <div style="font-size:80px;font-weight:bold;color:#fff;line-height:1;">
        <?= htmlspecialchars($grade['override_grade'] ?: $grade['letter_grade']) ?>
    </div>
    <div style="font-size:28px;color:#dbeafe;margin-top:8px;">
        <?= number_format($wt ?? $grade['total_score'], 1) ?> / 100
    </div>
    <?php foreach ($scale as $s): if ($wt >= $s['min_score'] && $wt <= $s['max_score']): ?>
        <div style="font-size:16px;color:#93c5fd;margin-top:8px;"><?= htmlspecialchars($s['description']) ?></div>
    <?php break; endif; endforeach; ?>
    <div style="font-size:12px;color:#93c5fd;margin-top:12px;">Published: <?= date('d M Y', strtotime($grade['published_at'])) ?></div>
</div>

<?php if ($grade['override_grade']): ?>
<div class="alert alert-info" style="margin-top:14px;">
    ️ Your letter grade was reviewed and finalised by the coordinator.
</div>
<?php endif; ?>

<!-- Grading Scale -->
<div class="card" style="margin-top:14px;">
    <h2 style="font-size:15px;margin-bottom:12px;">Grading Scale</h2>
    <table>
        <thead><tr><th>Grade</th><th>Range</th><th>Description</th></tr></thead>
        <tbody>
            <?php foreach ($scale as $s): ?>
            <tr style="<?= ($wt>=$s['min_score']&&$wt<=$s['max_score'])?'background:#f0fdf4;font-weight:bold;':'' ?>">
                <td><?= htmlspecialchars($s['letter']) ?></td>
                <td><?= number_format($s['min_score'],0) ?> – <?= number_format($s['max_score'],0) ?>%</td>
                <td><?= htmlspecialchars($s['description']??'') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
