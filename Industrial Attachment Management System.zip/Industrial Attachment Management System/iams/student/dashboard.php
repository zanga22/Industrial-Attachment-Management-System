<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT s.*, u.email FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = ?');
$profile->execute([$studentId]);
$student = $profile->fetch();

$lockRow = $db->prepare('SELECT placement_locked, placement_confirmed_seen FROM students WHERE id = ?');
$lockRow->execute([$studentId]);
$lockData = $lockRow->fetch();
$isLocked = (bool)$lockData['placement_locked'];
$confirmedSeen = (bool)$lockData['placement_confirmed_seen'];

if ($isLocked && !$confirmedSeen) {
    $db->prepare('UPDATE students SET placement_confirmed_seen = 1 WHERE id = ?')->execute([$studentId]);
    $confirmedSeen = false;
} else {
    $confirmedSeen = $isLocked ? true : false;
}

$offersQ = $db->prepare('SELECT COUNT(*) FROM applications WHERE student_id = ? AND status = "offered"');
$offersQ->execute([$studentId]);
$pendingOffers = (int)$offersQ->fetchColumn();

$stats = $db->prepare('
    SELECT
        COUNT(*) AS total,
        SUM(status = "pending")  AS pending,
        SUM(status = "accepted") AS accepted,
        SUM(status = "rejected") AS rejected
    FROM applications WHERE student_id = ?
');
$stats->execute([$studentId]);
$appStats = $stats->fetch();

$recent = $db->prepare('
    SELECT a.status, a.date_applied, c.company_name, c.sector
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ?
    ORDER BY a.date_applied DESC
    LIMIT 5
');
$recent->execute([$studentId]);
$recentApps = $recent->fetchAll();

$supQ = $db->prepare('
    SELECT l.first_name, l.last_name, l.department, u.email
    FROM supervisor_assignments sa
    JOIN lecturers l ON sa.lecturer_id = l.id
    JOIN users u ON l.user_id = u.id
    WHERE sa.student_id = ?
');
$supQ->execute([$studentId]);
$supervisor = $supQ->fetch();

$wpsQ = $db->prepare('
    SELECT w.first_name, w.last_name, w.job_title, w.department, w.phone, u.email, c.company_name
    FROM workplace_assignments wa
    JOIN workplace_supervisors w ON wa.workplace_supervisor_id = w.id
    JOIN users u ON w.user_id = u.id
    JOIN companies c ON w.company_id = c.id
    WHERE wa.student_id = ?
');
$wpsQ->execute([$studentId]);
$wplaceSupervisor = $wpsQ->fetch();

$pageTitle = 'Student Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (empty($_SESSION['is_approved'])): ?>
    <div class="alert alert-info" style="margin-bottom:20px;">
        ⏳ <strong>Account Pending Approval</strong> — Your student account is awaiting admin approval.
        You will be able to apply for internships and access all features once approved.
        Please check back later or contact the administrator.
    </div>
<?php endif; ?>

<h1 class="page-title">
    Welcome, <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
</h1>

<?php if ($isLocked && !$confirmedSeen): ?>
    <div class="alert alert-success" style="margin-bottom:16px;">
        <strong>Placement Confirmed!</strong> You have accepted a placement offer. Your attachment is underway.
    </div>
<?php elseif ($pendingOffers > 0): ?>
    <div class="alert" style="background:#eff6ff;border:2px solid #2563eb;color:#1e40af;margin-bottom:16px;padding:14px;border-radius:6px;">
        🎉 <strong>You have <?= $pendingOffers ?> placement offer<?= $pendingOffers > 1 ? 's' : '' ?> waiting for your response!</strong>
        <a href="<?= BASE_URL ?>/student/applications.php" class="btn btn-primary btn-sm" style="margin-left:12px;">View &amp; Respond</a>
    </div>
<?php endif; ?>

<div class="two-col">

<!-- ── Profile card ── -->
<div class="card">
    <h2>My Profile</h2>
    <table>
        <tr><th>Student No.</th><td><?= htmlspecialchars($student['student_number']) ?></td></tr>
        <tr><th>Programme</th>  <td><?= htmlspecialchars($student['programme']) ?></td></tr>
        <tr><th>Email</th>      <td><?= htmlspecialchars($student['email']) ?></td></tr>
        <tr><th>Phone</th>      <td><?= htmlspecialchars($student['phone'] ?? '—') ?></td></tr>
        <tr>
            <th>CV</th>
            <td>
                <?php if ($student['cv_path']): ?>
                    <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($student['cv_path'])) ?>" target="_blank">View CV</a>
                <?php else: ?>
                    <span class="text-muted" style="color:#dc2626;font-weight:bold;">No CV uploaded</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th>Transcript</th>
            <td>
                <?php if ($student['transcript_path']): ?>
                    <a href="<?= BASE_URL ?>/file.php?type=transcript&f=<?= urlencode(basename($student['transcript_path'])) ?>" target="_blank">View Transcript</a>
                <?php else: ?>
                    <span class="text-muted" style="color:#dc2626;font-weight:bold;">No transcript uploaded</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <div class="mt-10">
        <a href="<?= BASE_URL ?>/student/upload.php" class="btn btn-secondary btn-sm">Upload Documents</a>
    </div>
</div>

<!-- ── Quick actions + supervisor ── -->
<div>

    <div class="card">
        <h2>My Academic Supervisor</h2>
        <?php if ($supervisor): ?>
            <table>
                <tr><th>Name</th>       <td><strong><?= htmlspecialchars($supervisor['first_name'] . ' ' . $supervisor['last_name']) ?></strong></td></tr>
                <tr><th>Department</th> <td><?= htmlspecialchars($supervisor['department']) ?></td></tr>
                <tr><th>Email</th>      <td><?= htmlspecialchars($supervisor['email']) ?></td></tr>
            </table>
        <?php else: ?>
            <p class="text-muted">No academic supervisor assigned yet. The coordinator will assign one once your placement is confirmed.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>My Workplace Supervisor</h2>
        <?php if ($wplaceSupervisor): ?>
            <table>
                <tr><th>Name</th>       <td><strong><?= htmlspecialchars($wplaceSupervisor['first_name'] . ' ' . $wplaceSupervisor['last_name']) ?></strong></td></tr>
                <?php if ($wplaceSupervisor['job_title']): ?>
                <tr><th>Job Title</th>  <td><?= htmlspecialchars($wplaceSupervisor['job_title']) ?></td></tr>
                <?php endif; ?>
                <?php if ($wplaceSupervisor['department']): ?>
                <tr><th>Department</th> <td><?= htmlspecialchars($wplaceSupervisor['department']) ?></td></tr>
                <?php endif; ?>
                <tr><th>Email</th>      <td><?= htmlspecialchars($wplaceSupervisor['email']) ?></td></tr>
                <?php if ($wplaceSupervisor['phone']): ?>
                <tr><th>Phone</th>      <td><?= htmlspecialchars($wplaceSupervisor['phone']) ?></td></tr>
                <?php endif; ?>
                <tr><th>Company</th>    <td><?= htmlspecialchars($wplaceSupervisor['company_name']) ?></td></tr>
            </table>
        <?php else: ?>
            <p class="text-muted">No workplace supervisor assigned yet. Your company will assign one once your placement is confirmed.</p>
        <?php endif; ?>
    </div>
</div>

</div>

<!-- ── Recent applications ── -->
<div class="card">
    <h2>Recent Applications</h2>
    <?php if (empty($recentApps)): ?>
        <p class="text-muted">You haven't applied to any companies yet. <a href="<?= BASE_URL ?>/student/apply.php">Browse companies</a>.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Company</th><th>Sector</th><th>Date Applied</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($recentApps as $app): ?>
                    <tr>
                        <td><?= htmlspecialchars($app['company_name']) ?></td>
                        <td><?= htmlspecialchars($app['sector']) ?></td>
                        <td><?= date('d M Y', strtotime($app['date_applied'])) ?></td>
                        <td><span class="badge badge-<?= $app['status'] ?>"><?= ucfirst($app['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="mt-10">
            <a href="<?= BASE_URL ?>/student/applications.php" class="text-muted" style="font-size:13px;">View all →</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
