<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_company_id'])) {
    $companyId = (int)$_POST['apply_company_id'];
    $coverNote = trim($_POST['cover_note'] ?? '');
    $errors = [];


    $lockChk = $db->prepare('SELECT placement_locked FROM students WHERE id = ?');
    $lockChk->execute([$studentId]);
    if ($lockChk->fetchColumn()) {
        setFlash('error', 'You have already accepted a placement offer. No further applications can be made.');
        header('Location: ' . BASE_URL . '/student/vacancies.php'); exit;
    }


    $countChk = $db->prepare('SELECT COUNT(*) FROM applications WHERE student_id = ? AND status IN ("pending","offered")');
    $countChk->execute([$studentId]);
    if ((int)$countChk->fetchColumn() >= 5) {
        $errors[] = 'You have reached the maximum of 5 active applications. Withdraw one before applying again.';
    }

    $chk = $db->prepare('SELECT id FROM companies WHERE id = ? AND is_approved = 1');
    $chk->execute([$companyId]);
    if (!$chk->fetch()) $errors[] = 'Invalid or unapproved company.';

    $dup = $db->prepare('SELECT id FROM applications WHERE student_id = ? AND company_id = ?');
    $dup->execute([$studentId, $companyId]);
    if ($dup->fetch()) $errors[] = 'You have already applied to this company.';

    if (empty($errors)) {
        $db->prepare('INSERT INTO applications (student_id, company_id, cover_note) VALUES (?, ?, ?)')
           ->execute([$studentId, $companyId, $coverNote ?: null]);
        setFlash('success', 'Application submitted successfully!');
        header('Location: ' . BASE_URL . '/student/applications.php'); exit;
    } else {
        setFlash('error', implode(' ', $errors));
        header('Location: ' . BASE_URL . '/student/vacancies.php'); exit;
    }
}

$lockRow = $db->prepare('SELECT placement_locked FROM students WHERE id = ?');
$lockRow->execute([$studentId]);
$isLocked = (bool)$lockRow->fetchColumn();

$countChk = $db->prepare('SELECT COUNT(*) FROM applications WHERE student_id = ? AND status IN ("pending","offered")');
$countChk->execute([$studentId]);
$activeApps = (int)$countChk->fetchColumn();

$search = trim($_GET['search'] ?? '');
$sector = trim($_GET['sector'] ?? '');

$sql = 'SELECT v.*, c.company_name, c.sector AS co_sector, c.id AS co_id,
               (SELECT COUNT(*) FROM applications a WHERE a.company_id = c.id AND a.student_id = ?) AS already_applied
        FROM vacancies v
        JOIN companies c ON v.company_id = c.id
        WHERE v.is_active = 1 AND c.is_approved = 1';
$params = [$studentId];

if ($search !== '') { $sql .= ' AND (v.position_title LIKE ? OR c.company_name LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($sector !== '')  { $sql .= ' AND c.sector = ?'; $params[] = $sector; }
$sql .= ' ORDER BY v.created_at DESC';

$stmt = $db->prepare($sql); $stmt->execute($params);
$vacancies = $stmt->fetchAll();

$sectors = $db->query('SELECT DISTINCT c.sector FROM vacancies v JOIN companies c ON v.company_id=c.id WHERE v.is_active=1 AND c.is_approved=1 ORDER BY c.sector')->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Available Vacancies';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">Available Vacancies</h1>

<?php if ($isLocked): ?>
    <div class="alert alert-success">
        <strong>Placement confirmed.</strong> You have accepted a placement offer. Browsing is available but applications are closed.
    </div>
<?php elseif ($activeApps >= 5): ?>
    <div class="alert alert-info">
        You have <strong>5 active applications</strong> (the maximum). Withdraw one from <a href="<?= BASE_URL ?>/student/applications.php">My Applications</a> before applying again.
    </div>
<?php else: ?>
    <div class="alert alert-info" style="font-size:13px;padding:8px 14px;">
        Active applications: <strong><?= $activeApps ?> / 5</strong>
    </div>
<?php endif; ?>

<div class="card" style="padding:14px;">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
        <div class="form-group" style="flex:1;min-width:200px;margin:0;">
            <label>Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Position or company...">
        </div>
        <div class="form-group" style="min-width:160px;margin:0;">
            <label>Sector</label>
            <select name="sector">
                <option value="">All sectors</option>
                <?php foreach ($sectors as $s): ?>
                    <option value="<?= htmlspecialchars($s) ?>" <?= $sector===$s?'selected':'' ?>><?= htmlspecialchars($s) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="vacancies.php" class="btn btn-secondary">Clear</a>
        </div>
    </form>
</div>

<?php if (empty($vacancies)): ?>
    <div class="card"><p class="text-muted">No vacancies available at the moment.</p></div>
<?php else: ?>
    <p class="text-muted" style="margin-bottom:12px;"><?= count($vacancies) ?> vacancy/vacancies found</p>
    <?php foreach ($vacancies as $v): ?>
        <div class="card" style="margin-bottom:14px;border-left:4px solid #2563eb;">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;">
                <div>
                    <h3 style="color:#1e3a5f;margin:0 0 4px;"><?= htmlspecialchars($v['position_title']) ?></h3>
                    <strong><?= htmlspecialchars($v['company_name']) ?></strong>
                    <span class="text-muted"> — <?= htmlspecialchars($v['co_sector']) ?></span>
                    <br>
                    <small class="text-muted">
                        <?= (int)$v['num_positions'] ?> position(s) available
                        <?= $v['deadline'] ? ' | Deadline: <strong>'.date('d M Y', strtotime($v['deadline'])).'</strong>' : '' ?>
                        | Posted: <?= date('d M Y', strtotime($v['created_at'])) ?>
                    </small>
                    <?php if ($v['description']): ?>
                        <p style="margin:8px 0 4px;font-size:14px;"><?= nl2br(htmlspecialchars($v['description'])) ?></p>
                    <?php endif; ?>
                    <?php if ($v['requirements']): ?>
                        <p style="font-size:13px;color:#555;"><strong>Requirements:</strong> <?= nl2br(htmlspecialchars($v['requirements'])) ?></p>
                    <?php endif; ?>
                </div>
                <div style="min-width:220px;display:flex;align-items:center;">
                    <?php if ($v['already_applied']): ?>
                        <span class="badge badge-pending" style="padding:8px 14px;">&#10003; Already Applied</span>
                    <?php elseif ($isLocked || $activeApps >= 5): ?>
                        <button type="button" class="btn btn-secondary btn-sm" disabled
                                style="opacity:0.5;cursor:not-allowed;"
                                title="<?= $isLocked ? 'Placement confirmed — applications closed' : 'Maximum 5 active applications reached' ?>">
                            Apply Now
                        </button>
                    <?php else: ?>
                        <form method="POST" action="vacancies.php"
                              onsubmit="return confirm('Apply to <?= htmlspecialchars(addslashes($v['company_name'])) ?>?')"
                              style="width:100%;">
                            <input type="hidden" name="apply_company_id" value="<?= (int)$v['co_id'] ?>">
                            <div class="form-group" style="margin-bottom:6px;">
                                <textarea name="cover_note" rows="2" style="width:100%;font-size:13px;"
                                          placeholder="Optional: short cover note..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-success btn-sm">Apply Now</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
