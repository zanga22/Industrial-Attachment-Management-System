<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['suggest_company'])) {
    $suggestName    = trim($_POST['suggest_name']    ?? '');
    $suggestAddress = trim($_POST['suggest_address'] ?? '');
    $suggestReason  = trim($_POST['suggest_reason']  ?? '');
    if ($suggestName === '') {
        setFlash('error', 'Company name is required.');
    } else {
        $dupChk = $db->prepare("SELECT id FROM company_requests WHERE student_id = ? AND company_name = ? AND status = 'pending'");
        $dupChk->execute([$studentId, $suggestName]);
        if ($dupChk->fetch()) {
            setFlash('error', 'You already have a pending suggestion for that company.');
        } else {
            $db->prepare('INSERT INTO company_requests (student_id, company_name, company_address, reason) VALUES (?, ?, ?, ?)')->execute([$studentId, $suggestName, $suggestAddress ?: null, $suggestReason ?: null]);
            setFlash('success', 'Company suggestion submitted! The coordinator will review it shortly.');
        }
    }
    header('Location: ' . BASE_URL . '/student/apply.php'); exit;
}

$search = trim($_GET['search'] ?? '');
$sector = trim($_GET['sector'] ?? '');
$openTo = (int)($_GET['company_id'] ?? 0);

$sql = 'SELECT c.id, c.company_name, c.sector, c.contact_person, c.capacity,
               (SELECT COUNT(*) FROM applications a WHERE a.company_id=c.id AND a.status="accepted") AS filled,
               (SELECT COUNT(*) FROM applications a WHERE a.company_id=c.id AND a.student_id=?) AS already_applied,
               (SELECT COUNT(*) FROM vacancies v WHERE v.company_id=c.id AND v.is_active=1) AS vacancy_count
        FROM companies c WHERE c.is_approved = 1';
$params = [$studentId];
if ($search !== '') { $sql .= ' AND (c.company_name LIKE ? OR c.sector LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($sector !== '')  { $sql .= ' AND c.sector = ?'; $params[] = $sector; }
$sql .= ' ORDER BY c.company_name';
$stmt = $db->prepare($sql); $stmt->execute($params);
$companies = $stmt->fetchAll();

$sectors = $db->query('SELECT DISTINCT sector FROM companies WHERE is_approved=1 ORDER BY sector')->fetchAll(PDO::FETCH_COLUMN);

$mySuggestions = $db->prepare('SELECT id, company_name, status, reviewer_note, created_at FROM company_requests WHERE student_id = ? ORDER BY created_at DESC');
$mySuggestions->execute([$studentId]);
$suggestions = $mySuggestions->fetchAll();

$pageTitle = 'Browse Companies';
require_once __DIR__ . '/../includes/header.php';
?>
<h1 class="page-title">Browse Companies</h1>

<div class="card">
    <form method="GET" action="apply.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
        <div class="form-group" style="flex:1;min-width:200px;margin:0;">
            <label>Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Company name or sector...">
        </div>
        <div class="form-group" style="min-width:160px;margin:0;">
            <label>Sector</label>
            <select name="sector">
                <option value="">All sectors</option>
                <?php foreach ($sectors as $s): ?><option value="<?= htmlspecialchars($s) ?>" <?= $sector===$s?'selected':'' ?>><?= htmlspecialchars($s) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="apply.php" class="btn btn-secondary">Clear</a>
        </div>
    </form>
</div>

<?php if (empty($companies)): ?>
    <div class="card"><p class="text-muted">No approved companies found<?= $search ? ' matching "'.htmlspecialchars($search).'"' : '' ?>.</p></div>
<?php else: ?>
    <p class="text-muted" style="margin-bottom:12px;"><?= count($companies) ?> company/companies listed</p>
    <?php foreach ($companies as $co):
        $spotsLeft = max(0, $co['capacity'] - $co['filled']);
        $isOpen    = $openTo === (int)$co['id'];
    ?>
    <div class="card" style="margin-bottom:16px;<?= $isOpen ? 'border:2px solid #2563eb;' : '' ?>">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
            <div>
                <h3 style="font-size:17px;color:#1e3a5f;margin-bottom:4px;">
                    <?= htmlspecialchars($co['company_name']) ?>
                    <?php if ($co['vacancy_count'] > 0): ?>
                        <span style="font-size:12px;background:#dbeafe;color:#1e40af;border-radius:10px;padding:2px 8px;margin-left:8px;"><?= (int)$co['vacancy_count'] ?> vacancy/vacancies</span>
                    <?php endif; ?>
                </h3>
                <p class="text-muted" style="margin-bottom:4px;">
                    <strong>Sector:</strong> <?= htmlspecialchars($co['sector']) ?> &nbsp;|&nbsp;
                    <strong>Contact:</strong> <?= htmlspecialchars($co['contact_person']) ?> &nbsp;|&nbsp;
                    <strong>Available:</strong> <?= $spotsLeft > 0 ? $spotsLeft.' spots' : '<span style="color:#991b1b">Full</span>' ?>
                </p>
                <?php if ($co['vacancy_count'] > 0): ?>
                    <a href="<?= BASE_URL ?>/student/vacancies.php?search=<?= urlencode($co['company_name']) ?>" style="font-size:13px;color:#2563eb;">View open positions &rarr;</a>
                <?php endif; ?>
            </div>
            <div style="min-width:180px;">
                <?php if ($co['vacancy_count'] > 0): ?>
                    <a href="<?= BASE_URL ?>/student/vacancies.php?search=<?= urlencode($co['company_name']) ?>" class="btn btn-primary btn-sm">View Vacancies &rarr;</a>
                <?php else: ?>
                    <span class="badge badge-rejected" style="padding:6px 14px;font-size:13px;">No vacancies posted</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="card" style="border-top:3px solid #0d9488;margin-top:8px;">
    <h2 style="color:#0d9488;">Suggest a Company</h2>
    <p class="text-muted" style="margin-bottom:16px;font-size:14px;">Can't find your preferred company? Suggest it below. The coordinator will review your request and notify you of the outcome.</p>
    <form method="POST" action="apply.php">
        <div class="two-col">
            <div class="form-group">
                <label>Company Name *</label>
                <input type="text" name="suggest_name" required placeholder="e.g. ABC Technologies Ltd">
            </div>
            <div class="form-group">
                <label>Address <span style="font-weight:normal;color:#888;">(optional)</span></label>
                <input type="text" name="suggest_address" placeholder="Physical address or city">
            </div>
        </div>
        <div class="form-group">
            <label>Why do you want to intern here? <span style="font-weight:normal;color:#888;">(optional)</span></label>
            <textarea name="suggest_reason" rows="2" placeholder="Briefly explain why this company is suitable..."></textarea>
        </div>
        <button type="submit" name="suggest_company" class="btn btn-secondary">Submit Suggestion</button>
    </form>
</div>

<?php if (!empty($suggestions)): ?>
<div class="card">
    <h2>My Company Suggestions</h2>
    <table>
        <thead><tr><th>Company</th><th>Submitted</th><th>Status</th><th>Coordinator Note</th></tr></thead>
        <tbody>
            <?php foreach ($suggestions as $sg): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($sg['company_name']) ?></strong></td>
                    <td><?= date('d M Y', strtotime($sg['created_at'])) ?></td>
                    <td><span class="badge badge-<?= $sg['status']==='approved'?'approved':($sg['status']==='rejected'?'rejected':'pending') ?>"><?= ucfirst($sg['status']) ?></span></td>
                    <td><?= $sg['reviewer_note'] ? htmlspecialchars($sg['reviewer_note']) : '<span class="text-muted">&mdash;</span>' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
