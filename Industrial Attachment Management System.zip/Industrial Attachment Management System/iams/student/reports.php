<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

const RPT_ALLOWED_MIME = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const RPT_ALLOWED_EXT = ['pdf', 'doc', 'docx'];
const RPT_MAX_MB      = 10;
const RPT_MAX_B       = RPT_MAX_MB * 1024 * 1024;

$errors  = [];
$success = '';

$placementQ = $db->prepare('
    SELECT a.id, c.company_name
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ? AND a.status = "accepted"
    LIMIT 1
');
$placementQ->execute([$studentId]);
$placement = $placementQ->fetch();

$supQ = $db->prepare('
    SELECT l.id AS lecturer_id, l.first_name, l.last_name, l.department, u.email
    FROM supervisor_assignments sa
    JOIN lecturers l ON sa.lecturer_id = l.id
    JOIN users u ON l.user_id = u.id
    WHERE sa.student_id = ?
');
$supQ->execute([$studentId]);
$supervisor = $supQ->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $placement) {
    $reportType = $_POST['report_type'] ?? '';

    if (!in_array($reportType, ['logbook', 'final'], true)) {
        $errors[] = 'Please select a valid report type.';
    }

    if (empty($errors)) {
        if (!isset($_FILES['report_file']) || $_FILES['report_file']['error'] === UPLOAD_ERR_NO_FILE) {
            $errors[] = 'Please choose a file to upload.';
        } elseif ($_FILES['report_file']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload error (code ' . $_FILES['report_file']['error'] . '). Please try again.';
        }
    }

    if (empty($errors)) {
        $file    = $_FILES['report_file'];
        $tmpPath = $file['tmp_name'];
        $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($file['size'] > RPT_MAX_B) {
            $errors[] = 'File too large. Maximum is ' . RPT_MAX_MB . ' MB.';
        }
        if (!in_array($ext, RPT_ALLOWED_EXT, true)) {
            $errors[] = 'Only PDF, DOC, and DOCX files are accepted.';
        }
        if (empty($errors)) {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmpPath);
            if (!in_array($mime, RPT_ALLOWED_MIME, true)) {
                $errors[] = 'File content does not match an accepted document type.';
            }
        }

        if (empty($errors)) {
            $destDir = __DIR__ . '/../uploads/reports/';
            if (!is_dir($destDir)) mkdir($destDir, 0755, true);

            $newName  = 'report_' . $studentId . '_' . $reportType . '_' . time() . '.' . $ext;
            $destPath = $destDir . $newName;

            if (move_uploaded_file($tmpPath, $destPath)) {
                $lecId = $supervisor ? $supervisor['lecturer_id'] : null;
                $db->prepare('INSERT INTO reports (student_id, lecturer_id, file_path, report_type)
                              VALUES (?, ?, ?, ?)')
                   ->execute([$studentId, $lecId, $newName, $reportType]);
                $success = ucfirst($reportType) . ' uploaded successfully. Your supervisor has been notified.';
            } else {
                $errors[] = 'Could not save the file. Check folder permissions.';
            }
        }
    }
}

$reportsQ = $db->prepare('
    SELECT r.id, r.file_path, r.report_type, r.feedback, r.uploaded_at,
           l.first_name AS lec_first, l.last_name AS lec_last
    FROM reports r
    LEFT JOIN lecturers l ON r.lecturer_id = l.id
    WHERE r.student_id = ?
    ORDER BY r.uploaded_at DESC
');
$reportsQ->execute([$studentId]);
$myReports = $reportsQ->fetchAll();

$pageTitle = 'My Reports';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">My Reports &amp; Logbooks</h1>

<?php if (!$placement): ?>
    <div class="alert alert-info">
        ️ You can only upload reports once you have an <strong>accepted placement</strong>.
        Apply to companies and wait for an acceptance before submitting reports.
        <br><a href="<?= BASE_URL ?>/student/apply.php" class="btn btn-primary btn-sm" style="margin-top:8px;">Browse Companies</a>
    </div>
<?php else: ?>

<?php foreach ($errors as $e): ?>
    <div class="alert alert-error"><?= htmlspecialchars($e) ?></div>
<?php endforeach; ?>
<?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div class="two-col">

    <!-- ── Upload form ── -->
    <div class="card">
        <h2>Upload New Report</h2>

        <div class="alert alert-info" style="margin-bottom:14px;">
            📍 Placed at: <strong><?= htmlspecialchars($placement['company_name']) ?></strong>
            <?php if ($supervisor): ?>
                &nbsp;|&nbsp; 👤 Supervisor:
                <strong><?= htmlspecialchars($supervisor['first_name'] . ' ' . $supervisor['last_name']) ?></strong>
            <?php endif; ?>
        </div>

        <form method="POST" action="reports.php" enctype="multipart/form-data"
              onsubmit="return validateReport(this)">

            <div class="form-group">
                <label for="report_type">Report Type *</label>
                <select id="report_type" name="report_type" required>
                    <option value="">-- Select type --</option>
                    <option value="logbook">Weekly Logbook</option>
                    <option value="final">Final Report (end of attachment)</option>
                </select>
            </div>

            <div class="form-group">
                <label for="report_file">Select File *</label>
                <input type="file" id="report_file" name="report_file"
                       accept=".pdf,.doc,.docx" required>
                <small>PDF, DOC or DOCX &mdash; maximum <?= RPT_MAX_MB ?> MB</small>
            </div>

            <button type="submit" class="btn btn-primary">Upload Report</button>
        </form>
    </div>

    <!-- ── Upload tips ── -->
    <div class="card">
        <h2>Report Guidelines</h2>
        <table>
            <tr>
                <th>Weekly Logbook</th>
                <td>Weekly record of activities. Upload regularly throughout your attachment.</td>
            </tr>
            <tr>
                <th>Final Report</th>
                <td>Comprehensive end-of-attachment report. Submit when your attachment is complete.</td>
            </tr>
        </table>
        <p class="text-muted" style="font-size:13px;margin-top:12px;">
            Your supervisor will review each report and may provide written feedback.
            Check back here for their comments.
        </p>
    </div>

</div>

<?php endif; ?>

<!-- ── My submitted reports ── -->
<div class="card">
    <h2>Submitted Reports
        <span style="font-weight:normal;font-size:14px;color:#666;margin-left:8px;">
            (<?= count($myReports) ?> total)
        </span>
    </h2>

    <?php if (empty($myReports)): ?>
        <p class="text-muted">You haven't submitted any reports yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Type</th>
                    <th>Uploaded</th>
                    <th>File</th>
                    <th>Supervisor Feedback</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($myReports as $i => $rep): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td>
                            <span class="badge badge-<?= $rep['report_type'] === 'final' ? 'approved' : ($rep['report_type'] === 'progress' ? 'pending' : 'accepted') ?>">
                                <?= ucfirst($rep['report_type']) ?>
                            </span>
                        </td>
                        <td><?= date('d M Y H:i', strtotime($rep['uploaded_at'])) ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>/file.php?type=report&f=<?= urlencode(basename($rep['file_path'])) ?>"
                               target="_blank" class="btn btn-secondary btn-sm">📄 View</a>
                        </td>
                        <td style="max-width:340px;">
                            <?php if ($rep['feedback']): ?>
                                <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:4px;padding:8px;font-size:13px;">
                                    <?= nl2br(htmlspecialchars($rep['feedback'])) ?>
                                    <?php if ($rep['lec_first']): ?>
                                        <br><small class="text-muted">— <?= htmlspecialchars($rep['lec_first'] . ' ' . $rep['lec_last']) ?></small>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-muted" style="font-size:13px;">Awaiting feedback</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script>
const RPT_MAX_MB = <?= RPT_MAX_MB ?>;
function validateReport(form) {
    const input = form.querySelector('input[type="file"]');
    if (!input.files.length) { alert('Please select a file.'); return false; }
    const name    = input.files[0].name.toLowerCase();
    const allowed = ['.pdf', '.doc', '.docx'];
    if (!allowed.some(e => name.endsWith(e))) {
        alert('Only PDF, DOC, and DOCX files are allowed.');
        return false;
    }
    if (input.files[0].size > RPT_MAX_MB * 1024 * 1024) {
        alert('File exceeds the ' + RPT_MAX_MB + ' MB limit.');
        return false;
    }
    return true;
}
</script>

<!-- ── Company Progress Reports ── -->
<?php
$cprQ = $db->prepare('
    SELECT cpr.*, c.company_name
    FROM company_progress_reports cpr
    JOIN companies c ON cpr.company_id = c.id
    WHERE cpr.student_id = ?
    ORDER BY cpr.submitted_at DESC
');
$cprQ->execute([$studentId]);
$companyReports = $cprQ->fetchAll();
?>
<?php if (!empty($companyReports)): ?>
<div class="card">
    <h2>Company Progress Reports
        <span style="font-size:13px;font-weight:normal;color:#666;margin-left:8px;">(submitted by your company)</span>
    </h2>
    <?php foreach ($companyReports as $cpr): ?>
        <div style="border:1px solid #e2e8f0;border-radius:6px;padding:16px;margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
                <div>
                    <strong><?= htmlspecialchars($cpr['company_name']) ?></strong>
                    &nbsp;|&nbsp; <strong>Period:</strong> <?= htmlspecialchars($cpr['period']) ?>
                </div>
                <small class="text-muted"><?= date('d M Y', strtotime($cpr['submitted_at'])) ?></small>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px;">
                <?php foreach (['performance'=>'Performance','attendance'=>'Attendance','communication'=>'Communication','overall_rating'=>'Overall'] as $col => $lbl): ?>
                    <div style="background:#f8fafc;padding:8px;border-radius:4px;text-align:center;">
                        <div style="font-size:11px;color:#666;"><?= $lbl ?></div>
                        <div style="font-weight:bold;font-size:13px;"><?= htmlspecialchars($cpr[$col] ?? '—') ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if ($cpr['duties_performed']): ?>
                <p style="font-size:13px;margin-bottom:4px;"><strong>Duties:</strong> <?= nl2br(htmlspecialchars($cpr['duties_performed'])) ?></p>
            <?php endif; ?>
            <?php if ($cpr['comments']): ?>
                <p style="font-size:13px;"><strong>Comments:</strong> <?= nl2br(htmlspecialchars($cpr['comments'])) ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
