<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
requireApproved();

$db        = getDB();
$studentId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT s.*, u.email FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = ?');
$profile->execute([$studentId]);
$student = $profile->fetch();

$placement = $db->prepare('
    SELECT a.reviewed_at, c.company_name, c.sector, c.contact_person,
           c.phone AS co_phone, c.address AS co_address
    FROM applications a
    JOIN companies c ON a.company_id = c.id
    WHERE a.student_id = ? AND a.status = "accepted"
    LIMIT 1
');
$placement->execute([$studentId]);
$placed = $placement->fetch();

$supQ = $db->prepare('
    SELECT l.first_name, l.last_name, l.department, l.phone, u.email
    FROM supervisor_assignments sa
    JOIN lecturers l ON sa.lecturer_id = l.id
    JOIN users u ON l.user_id = u.id
    WHERE sa.student_id = ?
');
$supQ->execute([$studentId]);
$supervisor = $supQ->fetch();

$visitsQ = $db->prepare('
    SELECT sv.id, sv.visit_number, sv.visit_date, sv.status,
           sv.comments, sv.scheduled_at, sv.completed_at,
           l.first_name AS lec_first, l.last_name AS lec_last, l.department
    FROM site_visits sv
    JOIN lecturers l ON sv.lecturer_id = l.id
    WHERE sv.student_id = ?
    ORDER BY sv.visit_number ASC
');
$visitsQ->execute([$studentId]);
$visits = $visitsQ->fetchAll();

$pageTitle = 'My Internship';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">My Internship</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<div class="two-col" style="margin-bottom:0;">

    <!-- Placement Info -->
    <div class="card">
        <h2 style="margin-bottom:12px;">📍 Placement Details</h2>
        <?php if ($placed): ?>
            <div class="alert alert-success" style="margin-bottom:12px;">
                Yes Placed at <strong><?= htmlspecialchars($placed['company_name']) ?></strong>
            </div>
            <table>
                <tr><th>Company</th><td><?= htmlspecialchars($placed['company_name']) ?></td></tr>
                <tr><th>Sector</th><td><?= htmlspecialchars($placed['sector']) ?></td></tr>
                <tr><th>Contact Person</th><td><?= htmlspecialchars($placed['contact_person']) ?></td></tr>
                <tr><th>Phone</th><td><?= htmlspecialchars($placed['co_phone'] ?? '—') ?></td></tr>
                <tr><th>Address</th><td><?= htmlspecialchars($placed['co_address'] ?? '—') ?></td></tr>
                <tr><th>Start Date</th><td><?= date('d M Y', strtotime($placed['reviewed_at'])) ?></td></tr>
            </table>
        <?php else: ?>
            <div class="alert alert-info">⏳ You have not been placed at a company yet.</div>
        <?php endif; ?>
    </div>

    <!-- Academic Supervisor -->
    <div class="card">
        <h2 style="margin-bottom:12px;"> Academic Supervisor</h2>
        <?php if ($supervisor): ?>
            <table>
                <tr><th>Name</th><td><?= htmlspecialchars($supervisor['first_name'] . ' ' . $supervisor['last_name']) ?></td></tr>
                <tr><th>Department</th><td><?= htmlspecialchars($supervisor['department']) ?></td></tr>
                <tr><th>Email</th><td><a href="mailto:<?= htmlspecialchars($supervisor['email']) ?>"><?= htmlspecialchars($supervisor['email']) ?></a></td></tr>
                <tr><th>Phone</th><td><?= htmlspecialchars($supervisor['phone'] ?? '—') ?></td></tr>
            </table>
        <?php else: ?>
            <div class="alert alert-info">⏳ No academic supervisor has been assigned to you yet.</div>
        <?php endif; ?>
    </div>
</div>

<!-- ── Site Visit Schedule ── -->
<div class="card" style="margin-top:20px;">
    <h2 style="margin-bottom:16px;"> Site Visit Schedule</h2>

    <?php

    $visitMap = [];
    foreach ($visits as $v) { $visitMap[$v['visit_number']] = $v; }
    ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
        <?php foreach (['1', '2'] as $vn):
            $ordinal  = $vn === '1' ? '1st' : '2nd';
            $icon     = $vn === '1' ? '' : '🏁';
            $label    = $vn === '1' ? 'Initial observation visit' : 'Follow-up & final assessment';
            $v        = $visitMap[$vn] ?? null;
            $done     = $v && $v['status'] === 'completed';
        ?>
        <div style="border:1.5px solid <?= $done ? 'var(--maroon)' : ($v ? 'var(--gold)' : 'var(--border)') ?>;
                    border-radius:var(--r);padding:16px;background:<?= $done ? '#fdf5f5' : ($v ? '#fffdf3' : '#f9fafb') ?>;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <div>
                    <span style="font-size:18px;"><?= $icon ?></span>
                    <strong style="font-size:15px;margin-left:6px;"><?= $ordinal ?> Visit</strong>
                </div>
                <?php if ($done): ?>
                    <span class="badge badge-accepted">Yes Completed</span>
                <?php elseif ($v): ?>
                    <span class="badge badge-pending">⏳ Scheduled</span>
                <?php else: ?>
                    <span class="badge" style="background:#eee;color:#888;">Not yet scheduled</span>
                <?php endif; ?>
            </div>
            <p style="font-size:12px;color:var(--muted);margin-bottom:10px;"><?= $label ?></p>

            <?php if ($v): ?>
                <table style="font-size:13px;width:100%;">
                    <tr>
                        <th style="text-align:left;padding:3px 8px 3px 0;color:var(--muted);white-space:nowrap;">Date &amp; Time</th>
                        <td style="padding:3px 0;"><strong><?= date('d M Y', strtotime($v['visit_date'])) ?></strong>
                            at <?= date('H:i', strtotime($v['visit_date'])) ?></td>
                    </tr>
                    <tr>
                        <th style="text-align:left;padding:3px 8px 3px 0;color:var(--muted);">Supervisor</th>
                        <td style="padding:3px 0;"><?= htmlspecialchars($v['lec_first'] . ' ' . $v['lec_last']) ?></td>
                    </tr>
                    <?php if ($done && $v['completed_at']): ?>
                    <tr>
                        <th style="text-align:left;padding:3px 8px 3px 0;color:var(--muted);">Completed</th>
                        <td style="padding:3px 0;"><?= date('d M Y', strtotime($v['completed_at'])) ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            <?php else: ?>
                <p style="font-size:13px;color:var(--muted);margin-top:4px;">
                    Your academic supervisor will schedule this visit.
                </p>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ── Detailed visit view with comments ── -->
    <?php if (!empty($visits)): ?>
        <h3 style="font-size:15px;margin-bottom:14px;color:var(--navy);">Visit Details &amp; Supervisor Comments</h3>

        <?php foreach ($visits as $visit):
            $ordinal = $visit['visit_number'] === '1' ? '1st' : '2nd';
            $done    = $visit['status'] === 'completed';
        ?>
        <div style="border:1px solid var(--border);border-radius:var(--r);padding:16px;margin-bottom:14px;
                    border-left:4px solid <?= $done ? 'var(--maroon)' : 'var(--gold)' ?>;">

            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;">
                <div>
                    <strong style="font-size:15px;"><?= $ordinal ?> Site Visit</strong>
                    <div style="font-size:13px;color:var(--muted);margin-top:2px;">
                        <?= date('l, d M Y \a\t H:i', strtotime($visit['visit_date'])) ?>
                        &nbsp;·&nbsp;
                        Conducted by <em><?= htmlspecialchars($visit['lec_first'] . ' ' . $visit['lec_last']) ?></em>
                        (<?= htmlspecialchars($visit['department']) ?>)
                    </div>
                </div>
                <span class="badge badge-<?= $done ? 'accepted' : 'pending' ?>">
                    <?= $done ? 'Yes Completed' : '⏳ Scheduled' ?>
                </span>
            </div>

            <!-- Supervisor Comments -->
            <div style="background:<?= $done ? '#f8f9fa' : '#fffdf3' ?>;border-radius:var(--r-sm);padding:12px;">
                <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:6px;">
                    💬 Supervisor Comments
                </div>
                <?php if ($visit['comments']): ?>
                    <p style="font-size:14px;line-height:1.6;color:var(--text);">
                        <?= nl2br(htmlspecialchars($visit['comments'])) ?>
                    </p>
                <?php elseif ($done): ?>
                    <p style="font-size:13px;color:var(--muted);font-style:italic;">
                        No written comments were added for this visit.
                    </p>
                <?php else: ?>
                    <p style="font-size:13px;color:var(--muted);font-style:italic;">
                        Comments will appear here after the visit has been conducted.
                    </p>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>

    <?php else: ?>
        <div class="alert alert-info" style="font-size:14px;">
            📭 No site visits have been scheduled yet. Your academic supervisor will schedule visits once your internship is underway.
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
