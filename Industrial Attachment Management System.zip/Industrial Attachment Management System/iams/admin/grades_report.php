<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();

$filterCompany = (int)($_GET['company_id'] ?? 0);
$filterLec     = (int)($_GET['lecturer_id'] ?? 0);
$export        = $_GET['export'] ?? '';

$sql = '
    SELECT s.id AS student_id, s.first_name, s.last_name, s.student_number, s.programme,
           c.company_name, c.sector,
           CONCAT(l.first_name," ",l.last_name) AS lecturer_name,
           fg.workplace_score, fg.lecturer_score, fg.total_score,
           fg.letter_grade, fg.override_grade, fg.status,
           fg.discrepancy_flag, fg.approved_at, fg.published_at
    FROM students s
    JOIN applications a ON a.student_id=s.id AND a.status="accepted"
    JOIN companies c ON a.company_id=c.id
    LEFT JOIN supervisor_assignments sa ON sa.student_id=s.id
    LEFT JOIN lecturers l ON sa.lecturer_id=l.id
    LEFT JOIN final_grades fg ON fg.student_id=s.id
    WHERE 1=1
';
$params = [];
if ($filterCompany) { $sql .= ' AND c.id=?'; $params[] = $filterCompany; }
if ($filterLec)     { $sql .= ' AND l.id=?'; $params[] = $filterLec; }
$sql .= ' ORDER BY c.company_name, s.last_name';

$stmt = $db->prepare($sql); $stmt->execute($params);
$rows = $stmt->fetchAll();

$totalStudents   = count($rows);
$gradedStudents  = count(array_filter($rows, fn($r) => $r['total_score'] !== null));
$avgTotal        = $gradedStudents > 0 ? array_sum(array_column(array_filter($rows, fn($r) => $r['total_score'] !== null), 'total_score')) / $gradedStudents : 0;
$discrepancies   = count(array_filter($rows, fn($r) => $r['discrepancy_flag']));
$published       = count(array_filter($rows, fn($r) => $r['status'] === 'published'));

$coAvg = $db->query('
    SELECT c.company_name, COUNT(fg.student_id) AS cnt, AVG(fg.total_score) AS avg_score
    FROM final_grades fg
    JOIN applications a ON a.student_id=fg.student_id AND a.status="accepted"
    JOIN companies c ON a.company_id=c.id
    WHERE fg.total_score IS NOT NULL
    GROUP BY c.id ORDER BY avg_score DESC
')->fetchAll();

$lecAvg = $db->query('
    SELECT CONCAT(l.first_name," ",l.last_name) AS lecturer, COUNT(fg.student_id) AS cnt, AVG(fg.total_score) AS avg_score
    FROM final_grades fg
    JOIN supervisor_assignments sa ON sa.student_id=fg.student_id
    JOIN lecturers l ON sa.lecturer_id=l.id
    WHERE fg.total_score IS NOT NULL
    GROUP BY l.id ORDER BY avg_score DESC
')->fetchAll();

if ($export === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="grades_report_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Student','Student No.','Programme','Company','Sector','Lecturer','WP Score','Lec Score','Total','Grade','Status','Discrepancy','Published']);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['first_name'].' '.$r['last_name'], $r['student_number'], $r['programme'],
            $r['company_name'], $r['sector'], $r['lecturer_name'] ?? '',
            $r['workplace_score'] ?? '', $r['lecturer_score'] ?? '',
            $r['total_score'] ?? '', $r['override_grade'] ?: ($r['letter_grade'] ?? ''),
            $r['status'] ?? 'pending', $r['discrepancy_flag'] ? 'YES' : 'No',
            $r['published_at'] ? date('d M Y', strtotime($r['published_at'])) : ''
        ]);
    }
    fclose($out); exit;
}

$companies = $db->query('SELECT id, company_name FROM companies WHERE is_approved=1 ORDER BY company_name')->fetchAll();
$lecturers = $db->query('SELECT id, first_name, last_name FROM lecturers ORDER BY last_name')->fetchAll();

$pageTitle = 'Grades Report';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:10px;">
    <h1 class="page-title">Institutional Grades Report</h1>
    <div>
        <a href="grades_report.php?<?= http_build_query(array_merge($_GET,['export'=>'csv'])) ?>" class="btn btn-secondary btn-sm">⬇ Export CSV</a>
        <a href="dashboard.php" class="btn btn-secondary btn-sm" style="margin-left:6px;">← Dashboard</a>
    </div>
</div>

<!-- Summary stats -->
<div class="stats-grid">
    <div class="stat-box"><div class="stat-num"><?= $totalStudents ?></div><div class="stat-label">Placed Students</div></div>
    <div class="stat-box"><div class="stat-num"><?= $gradedStudents ?></div><div class="stat-label">Grades Submitted</div></div>
    <div class="stat-box"><div class="stat-num"><?= $published ?></div><div class="stat-label">Published</div></div>
    <div class="stat-box"><div class="stat-num"><?= $gradedStudents ? number_format($avgTotal,1) : '—' ?></div><div class="stat-label">Average Score</div></div>
    <div class="stat-box"><div class="stat-num" style="color:<?= $discrepancies>0?'#991b1b':'#166534' ?>"><?= $discrepancies ?></div><div class="stat-label">Discrepancies</div></div>
</div>

<!-- Filters -->
<div class="card" style="padding:14px;">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div class="form-group" style="margin:0;min-width:180px;">
            <label>Company</label>
            <select name="company_id">
                <option value="0">All Companies</option>
                <?php foreach ($companies as $co): ?><option value="<?= $co['id'] ?>" <?= $filterCompany===$co['id']?'selected':'' ?>><?= htmlspecialchars($co['company_name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="form-group" style="margin:0;min-width:180px;">
            <label>Lecturer</label>
            <select name="lecturer_id">
                <option value="0">All Lecturers</option>
                <?php foreach ($lecturers as $lc): ?><option value="<?= $lc['id'] ?>" <?= $filterLec===$lc['id']?'selected':'' ?>><?= htmlspecialchars($lc['first_name'].' '.$lc['last_name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div style="margin-bottom:14px;"><button type="submit" class="btn btn-primary btn-sm">Filter</button> <a href="grades_report.php" class="btn btn-secondary btn-sm">Clear</a></div>
    </form>
</div>

<!-- Per-company averages -->
<?php if (!empty($coAvg)): ?>
<div class="two-col">
    <div class="card">
        <h2>Average by Company</h2>
        <table>
            <thead><tr><th>Company</th><th>Students</th><th>Avg Score</th></tr></thead>
            <tbody>
                <?php foreach ($coAvg as $ca): ?>
                <tr><td><?= htmlspecialchars($ca['company_name']) ?></td><td><?= $ca['cnt'] ?></td><td><strong><?= number_format($ca['avg_score'],1) ?></strong></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="card">
        <h2>Average by Lecturer</h2>
        <table>
            <thead><tr><th>Lecturer</th><th>Students</th><th>Avg Score</th></tr></thead>
            <tbody>
                <?php foreach ($lecAvg as $la): ?>
                <tr><td><?= htmlspecialchars($la['lecturer']) ?></td><td><?= $la['cnt'] ?></td><td><strong><?= number_format($la['avg_score'],1) ?></strong></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Full grade table -->
<div class="card">
    <h2>All Student Grades</h2>
    <table>
        <thead>
            <tr><th>Student</th><th>Programme</th><th>Company</th><th>Lecturer</th><th>WP</th><th>Lec</th><th>Total</th><th>Grade</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $r):
                $grade  = $r['override_grade'] ?: ($r['letter_grade'] ?? '—');
                $status = $r['status'] ?? 'pending';
            ?>
            <tr>
                <td>
                    <strong><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?></strong><br>
                    <small class="text-muted"><?= htmlspecialchars($r['student_number']) ?></small>
                    <?php if ($r['discrepancy_flag']): ?><br><span style="font-size:11px;color:#991b1b;">⚑ Discrepancy</span><?php endif; ?>
                </td>
                <td><?= htmlspecialchars($r['programme']) ?></td>
                <td><?= htmlspecialchars($r['company_name']) ?></td>
                <td><?= htmlspecialchars($r['lecturer_name'] ?? '—') ?></td>
                <td><?= $r['workplace_score'] !== null ? number_format($r['workplace_score'],1) : '<span class="text-muted">—</span>' ?></td>
                <td><?= $r['lecturer_score']  !== null ? number_format($r['lecturer_score'],1)  : '<span class="text-muted">—</span>' ?></td>
                <td><strong><?= $r['total_score'] !== null ? number_format($r['total_score'],1) : '—' ?></strong></td>
                <td style="font-size:18px;font-weight:bold;text-align:center;"><?= $grade !== '—' ? htmlspecialchars($grade) : '—' ?></td>
                <td><span style="font-size:12px;"><?= ucfirst($status) ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
