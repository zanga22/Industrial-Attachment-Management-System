<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (isset($_POST['student_id'])) {
        $sid = (int)$_POST['student_id'];
        if ($action === 'approve') {
            $db->prepare('UPDATE students SET is_approved = 1 WHERE id = ?')->execute([$sid]);
            $userId = $db->prepare('SELECT user_id FROM students WHERE id = ?');
            $userId->execute([$sid]);
            $uid = (int)$userId->fetchColumn();
            sendNotification($db, $uid, 'Your student account has been approved. You can now access all features.', BASE_URL . '/student/dashboard.php');
            setFlash('success', 'Student approved.');
        } else {
            $userId = $db->prepare('SELECT user_id FROM students WHERE id = ?');
            $userId->execute([$sid]);
            $uid = (int)$userId->fetchColumn();
            $db->prepare('DELETE FROM students WHERE id = ?')->execute([$sid]);
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            setFlash('success', 'Student rejected and deleted.');
        }

    } elseif (isset($_POST['lecturer_id'])) {
        $lid = (int)$_POST['lecturer_id'];
        if ($action === 'approve') {
            $db->prepare('UPDATE lecturers SET is_approved = 1 WHERE id = ?')->execute([$lid]);
            $userId = $db->prepare('SELECT user_id FROM lecturers WHERE id = ?');
            $userId->execute([$lid]);
            $uid = (int)$userId->fetchColumn();
            sendNotification($db, $uid, 'Your lecturer account has been approved. You can now access all features.', BASE_URL . '/lecturer/dashboard.php');
            setFlash('success', 'Lecturer approved.');
        } else {
            $userId = $db->prepare('SELECT user_id FROM lecturers WHERE id = ?');
            $userId->execute([$lid]);
            $uid = (int)$userId->fetchColumn();
            $db->prepare('DELETE FROM lecturers WHERE id = ?')->execute([$lid]);
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            setFlash('success', 'Lecturer rejected and deleted.');
        }

    } elseif (isset($_POST['coordinator_id'])) {
        $coid = (int)$_POST['coordinator_id'];
        if ($action === 'approve') {
            $db->prepare('UPDATE coordinators SET is_approved = 1 WHERE id = ?')->execute([$coid]);
            $userId = $db->prepare('SELECT user_id FROM coordinators WHERE id = ?');
            $userId->execute([$coid]);
            $uid = (int)$userId->fetchColumn();
            sendNotification($db, $uid, 'Your coordinator account has been approved. You can now access all features.', BASE_URL . '/coordinator/dashboard.php');
            setFlash('success', 'Coordinator approved.');
        } else {
            $userId = $db->prepare('SELECT user_id FROM coordinators WHERE id = ?');
            $userId->execute([$coid]);
            $uid = (int)$userId->fetchColumn();
            $db->prepare('DELETE FROM coordinators WHERE id = ?')->execute([$coid]);
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            setFlash('success', 'Coordinator rejected and deleted.');
        }

    } elseif (isset($_POST['company_id'])) {
        $cid = (int)$_POST['company_id'];
        if ($action === 'approve') {
            $db->prepare('UPDATE companies SET is_approved = 1 WHERE id = ?')->execute([$cid]);
            setFlash('success', 'Company approved.');
        } else {
            $userId = $db->prepare('SELECT user_id FROM companies WHERE id = ?');
            $userId->execute([$cid]);
            $uid = (int)$userId->fetchColumn();
            $db->prepare('DELETE FROM companies WHERE id = ?')->execute([$cid]);
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
            setFlash('success', 'Company rejected and deleted.');
        }
    }

    header('Location: pending_approvals.php?tab=' . ($_POST['tab'] ?? 'students'));
    exit;
}

$validTabs = ['students', 'lecturers', 'coordinators', 'companies'];
$tab = in_array($_GET['tab'] ?? '', $validTabs) ? $_GET['tab'] : 'students';

$pendingStudentCount     = (int)$db->query('SELECT COUNT(*) FROM students     WHERE is_approved = 0')->fetchColumn();
$pendingLecturerCount    = (int)$db->query('SELECT COUNT(*) FROM lecturers    WHERE is_approved = 0')->fetchColumn();
$pendingCoordinatorCount = (int)$db->query('SELECT COUNT(*) FROM coordinators WHERE is_approved = 0')->fetchColumn();
$pendingCompanyCount     = (int)$db->query('SELECT COUNT(*) FROM companies    WHERE is_approved = 0')->fetchColumn();

$rows = [];
if ($tab === 'students') {
    $rows = $db->query('
        SELECT s.id, s.first_name, s.last_name, s.student_number AS detail,
               s.programme AS extra, s.phone, s.is_approved, s.created_at, u.email
        FROM students s JOIN users u ON s.user_id = u.id
        ORDER BY s.is_approved ASC, s.created_at DESC
    ')->fetchAll();
} elseif ($tab === 'lecturers') {
    $rows = $db->query('
        SELECT l.id, l.first_name, l.last_name, l.department AS detail,
               NULL AS extra, l.phone, l.is_approved, l.created_at, u.email
        FROM lecturers l JOIN users u ON l.user_id = u.id
        ORDER BY l.is_approved ASC, l.created_at DESC
    ')->fetchAll();
} elseif ($tab === 'coordinators') {
    $rows = $db->query('
        SELECT c.id, c.first_name, c.last_name, c.department AS detail,
               NULL AS extra, c.phone, c.is_approved, c.created_at, u.email
        FROM coordinators c JOIN users u ON c.user_id = u.id
        ORDER BY c.is_approved ASC, c.created_at DESC
    ')->fetchAll();
} elseif ($tab === 'companies') {
    $rows = $db->query('
        SELECT c.id, c.company_name AS first_name, "" AS last_name,
               c.sector AS detail, c.contact_person AS extra,
               c.phone, c.is_approved, c.created_at, u.email
        FROM companies c JOIN users u ON c.user_id = u.id
        ORDER BY c.is_approved ASC, c.created_at DESC
    ')->fetchAll();
}

$detailLabel = ['students'=>'Student No.','lecturers'=>'Department','coordinators'=>'Department','companies'=>'Sector'];
$extraLabel  = ['students'=>'Programme','lecturers'=>'','coordinators'=>'','companies'=>'Contact Person'];
$idField     = ['students'=>'student_id','lecturers'=>'lecturer_id','coordinators'=>'coordinator_id','companies'=>'company_id'];

$pageTitle = 'Pending Approvals';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h1 class="page-title">Pending Approvals</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Tab navigation -->
<div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;">
<?php
$tabDefs = [
    'students'     => ['label'=>'Students',     'count'=>$pendingStudentCount],
    'lecturers'    => ['label'=>'Lecturers',    'count'=>$pendingLecturerCount],
    'coordinators' => ['label'=>'Coordinators', 'count'=>$pendingCoordinatorCount],
    'companies'    => ['label'=>'Companies',    'count'=>$pendingCompanyCount],
];
foreach ($tabDefs as $key => $def):
?>
    <a href="?tab=<?= $key ?>"
       class="btn btn-sm <?= $tab === $key ? 'btn-primary' : 'btn-secondary' ?>">
        <?= $def['label'] ?>
        <?php if ($def['count'] > 0): ?>
            <span style="background:#dc2626;color:#fff;border-radius:999px;padding:1px 7px;font-size:11px;margin-left:4px;">
                <?= $def['count'] ?>
            </span>
        <?php endif; ?>
    </a>
<?php endforeach; ?>
</div>

<div class="card">
    <p class="text-muted" style="margin-bottom:12px;"><?= count($rows) ?> record(s) found</p>
    <?php if (empty($rows)): ?>
        <p class="text-muted" style="text-align:center;padding:30px;">No records found.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th><?= $detailLabel[$tab] ?></th>
                <?php if ($extraLabel[$tab]): ?><th><?= $extraLabel[$tab] ?></th><?php endif; ?>
                <th>Email</th>
                <th>Phone</th>
                <th>Registered</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $i => $r): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><strong><?= htmlspecialchars(trim($r['first_name'] . ' ' . $r['last_name'])) ?></strong></td>
                    <td><?= htmlspecialchars($r['detail'] ?? '—') ?></td>
                    <?php if ($extraLabel[$tab]): ?>
                        <td><?= htmlspecialchars($r['extra'] ?? '—') ?></td>
                    <?php endif; ?>
                    <td><?= htmlspecialchars($r['email']) ?></td>
                    <td><?= htmlspecialchars($r['phone'] ?? '—') ?></td>
                    <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
                    <td>
                        <span class="badge <?= $r['is_approved'] ? 'badge-approved' : 'badge-pending' ?>">
                            <?= $r['is_approved'] ? 'Approved' : 'Pending' ?>
                        </span>
                    </td>
                    <td style="white-space:nowrap;">
                        <?php if (!$r['is_approved']): ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Approve this record?')">
                                <input type="hidden" name="tab" value="<?= $tab ?>">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="<?= $idField[$tab] ?>" value="<?= (int)$r['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-success">✔ Approve</button>
                            </form>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Reject and permanently delete this registration?')">
                                <input type="hidden" name="tab" value="<?= $tab ?>">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="<?= $idField[$tab] ?>" value="<?= (int)$r['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">✖ Reject</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted" style="font-size:12px;">Approved</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
