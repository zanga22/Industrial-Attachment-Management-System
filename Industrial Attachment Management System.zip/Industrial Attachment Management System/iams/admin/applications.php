<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();

$filterStatus = $_GET['status'] ?? 'all';
$sql = '
    SELECT a.id, a.status, a.date_applied,
           s.first_name, s.last_name, s.student_number,
           c.company_name
    FROM applications a
    JOIN students s ON a.student_id = s.id
    JOIN companies c ON a.company_id = c.id
    WHERE 1=1
';
$params = [];
if ($filterStatus !== 'all') {
    $sql .= ' AND a.status = ?';
    $params[] = $filterStatus;
}
$sql .= ' ORDER BY a.date_applied DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$applications = $stmt->fetchAll();

$pageTitle = 'All Applications';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h1 class="page-title">All Applications</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<div class="card" style="padding:14px;">
    <?php foreach (['all','pending','offered','accepted','rejected','withdrawn'] as $st): ?>
        <a href="?status=<?= $st ?>" class="btn btn-sm <?= $filterStatus === $st ? 'btn-primary' : 'btn-secondary' ?>" style="margin-right:6px;">
            <?= ucfirst($st) ?>
        </a>
    <?php endforeach; ?>
</div>

<div class="card">
    <p class="text-muted" style="margin-bottom:12px;"><?= count($applications) ?> record(s)</p>
    <table>
        <thead><tr><th>#</th><th>Student</th><th>Student No.</th><th>Company</th><th>Date Applied</th><th>Status</th></tr></thead>
        <tbody>
            <?php foreach ($applications as $i => $app): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= htmlspecialchars($app['first_name'] . ' ' . $app['last_name']) ?></td>
                    <td><?= htmlspecialchars($app['student_number']) ?></td>
                    <td><?= htmlspecialchars($app['company_name']) ?></td>
                    <td><?= date('d M Y', strtotime($app['date_applied'])) ?></td>
                    <td><span class="badge badge-<?= $app['status'] ?>"><?= ucfirst($app['status']) ?></span></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
