<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_user'])) {
    $uid = (int)$_POST['toggle_user'];
    if ($uid !== currentUserId()) {
        $db->prepare('UPDATE users SET is_active = 1 - is_active WHERE id = ?')->execute([$uid]);
        setFlash('success', 'User status updated.');
    } else {
        setFlash('error', 'You cannot deactivate your own account.');
    }
    header('Location: users.php');
    exit;
}

$filterRole = $_GET['role'] ?? 'all';
$search     = trim($_GET['search'] ?? '');

$sql = '
    SELECT u.id, u.email, u.role, u.is_active, u.created_at,
           COALESCE(s.first_name, c.company_name, l.first_name, "Admin") AS display_name,
           COALESCE(s.last_name, "", l.last_name, "") AS last_name
    FROM users u
    LEFT JOIN students  s ON s.user_id = u.id AND u.role = "student"
    LEFT JOIN companies c ON c.user_id = u.id AND u.role = "company"
    LEFT JOIN lecturers l ON l.user_id = u.id AND u.role = "lecturer"
    WHERE 1=1
';
$params = [];

if ($filterRole !== 'all') {
    $sql .= ' AND u.role = ?';
    $params[] = $filterRole;
}
if ($search !== '') {
    $sql .= ' AND (u.email LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR c.company_name LIKE ? OR l.first_name LIKE ?)';
    $like = '%' . $search . '%';
    $params = array_merge($params, [$like, $like, $like, $like, $like]);
}
$sql .= ' ORDER BY u.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'Manage Users';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h1 class="page-title">Manage Users</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Filter bar -->
<div class="card" style="padding:14px;">
    <form method="GET" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">
        <div class="form-group" style="margin:0;flex:1;min-width:180px;">
            <label>Search</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Email or name...">
        </div>
        <div class="form-group" style="margin:0;">
            <label>Role</label>
            <select name="role">
                <option value="all">All roles</option>
                <?php foreach (['student','company','lecturer','admin'] as $r): ?>
                    <option value="<?= $r ?>" <?= $filterRole === $r ? 'selected' : '' ?>><?= ucfirst($r) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="users.php" class="btn btn-secondary">Clear</a>
        </div>
    </form>
</div>

<div class="card">
    <p class="text-muted" style="margin-bottom:12px;"><?= count($users) ?> user(s) found</p>
    <table>
        <thead>
            <tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Registered</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
            <?php foreach ($users as $i => $u): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars(trim($u['display_name'] . ' ' . $u['last_name'])) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><span class="badge badge-pending"><?= ucfirst($u['role']) ?></span></td>
                    <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <?php if ($u['is_active']): ?>
                            <span style="color:green;font-weight:bold;">Active</span>
                        <?php else: ?>
                            <span style="color:red;font-weight:bold;">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($u['id'] !== currentUserId()): ?>
                            <form method="POST" onsubmit="return confirm('Toggle user status?')">
                                <input type="hidden" name="toggle_user" value="<?= (int)$u['id'] ?>">
                                <button type="submit" class="btn btn-sm <?= $u['is_active'] ? 'btn-danger' : 'btn-success' ?>">
                                    <?= $u['is_active'] ? 'Deactivate' : 'Activate' ?>
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted">You</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
