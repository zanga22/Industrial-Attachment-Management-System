<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();

$stats = [
    'students'        => $db->query('SELECT COUNT(*) FROM students')->fetchColumn(),
    'companies'       => $db->query('SELECT COUNT(*) FROM companies')->fetchColumn(),
    'approved_co'     => $db->query('SELECT COUNT(*) FROM companies WHERE is_approved=1')->fetchColumn(),
    'lecturers'       => $db->query('SELECT COUNT(*) FROM lecturers')->fetchColumn(),
    'applications'    => $db->query('SELECT COUNT(*) FROM applications')->fetchColumn(),
    'pending_apps'    => $db->query('SELECT COUNT(*) FROM applications WHERE status="pending"')->fetchColumn(),
    'accepted_apps'   => $db->query('SELECT COUNT(*) FROM applications WHERE status="accepted"')->fetchColumn(),
    'pending_co'      => $db->query('SELECT COUNT(*) FROM companies  WHERE is_approved=0')->fetchColumn(),
    'pending_students'=> $db->query('SELECT COUNT(*) FROM students   WHERE is_approved=0')->fetchColumn(),
    'pending_lec'     => $db->query('SELECT COUNT(*) FROM lecturers  WHERE is_approved=0')->fetchColumn(),
];

$recentUsers = $db->query('
    SELECT u.id, u.email, u.role, u.created_at, u.is_active
    FROM users u ORDER BY u.created_at DESC LIMIT 8
')->fetchAll();

$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">Admin Dashboard</h1>

<?php if ($stats['pending_co'] > 0): ?>
    <div class="alert alert-info">
         <strong><?= (int)$stats['pending_co'] ?></strong> company account(s) are awaiting approval.
        <a href="<?= BASE_URL ?>/admin/companies.php">Review now →</a>
    </div>
<?php endif; ?>

<?php if ($stats['pending_students'] > 0): ?>
    <div class="alert alert-info">
         <strong><?= (int)$stats['pending_students'] ?></strong> student account(s) are awaiting approval.
        <a href="<?= BASE_URL ?>/admin/pending_approvals.php?tab=students&status=pending">Review now →</a>
    </div>
<?php endif; ?>

<?php if ($stats['pending_lec'] > 0): ?>
    <div class="alert alert-info">
         <strong><?= (int)$stats['pending_lec'] ?></strong> lecturer account(s) are awaiting approval.
        <a href="<?= BASE_URL ?>/admin/pending_approvals.php?tab=lecturers&status=pending">Review now →</a>
    </div>
<?php endif; ?>

<!-- Stats grid -->
<div class="stats-grid">
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['students'] ?></div><div class="stat-label">Students</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['companies'] ?></div><div class="stat-label">Companies</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['lecturers'] ?></div><div class="stat-label">Lecturers</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['applications'] ?></div><div class="stat-label">Total Applications</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['pending_apps'] ?></div><div class="stat-label">Pending</div></div>
    <div class="stat-box"><div class="stat-num"><?= (int)$stats['accepted_apps'] ?></div><div class="stat-label">Accepted</div></div>
</div>

<div class="two-col">
    <!-- Quick links -->
    <div class="card">
        <h2>Admin Actions</h2>
        <p style="margin-bottom:8px;"><a href="<?= BASE_URL ?>/admin/users.php" class="btn btn-primary" style="width:100%;"> Manage Users</a></p>
        <p style="margin-bottom:8px;"><a href="<?= BASE_URL ?>/admin/applications.php" class="btn btn-primary" style="width:100%;"> View All Applications</a></p>

    </div>

    <!-- Recent registrations -->
    <div class="card">
        <h2>Recent Registrations</h2>
        <table>
            <thead><tr><th>Email</th><th>Role</th><th>Date</th><th>Active</th></tr></thead>
            <tbody>
                <?php foreach ($recentUsers as $u): ?>
                    <tr>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><span class="badge badge-pending"><?= ucfirst($u['role']) ?></span></td>
                        <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                        <td><?= $u['is_active'] ? 'Yes' : 'No' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
