<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$type     = $_GET['type'] ?? '';
$filename = basename($_GET['f'] ?? '');

$typeMap = [
    'cv'           => __DIR__ . '/uploads/cv/',
    'transcript'   => __DIR__ . '/uploads/transcripts/',
    'report'       => __DIR__ . '/uploads/reports/',
    'offer_letter' => __DIR__ . '/uploads/offer_letters/',
];

if (!isset($typeMap[$type])) {
    http_response_code(400); die('Invalid file type.');
}
if ($filename === '' || $filename === '.') {
    http_response_code(400); die('No file specified.');
}

$fullPath = $typeMap[$type] . $filename;

if (!file_exists($fullPath) || !is_file($fullPath)) {
    http_response_code(404); die('File not found. It may have been deleted or not yet uploaded.');
}

$ext  = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mime = match($ext) {
    'pdf'  => 'application/pdf',
    'doc'  => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    default => 'application/octet-stream',
};

header('Content-Type: '        . $mime);
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Length: '      . filesize($fullPath));
header('Cache-Control: private, max-age=3600');
readfile($fullPath);
exit;
