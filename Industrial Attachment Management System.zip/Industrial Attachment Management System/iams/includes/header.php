<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$flashError   = getFlash('error');
$flashSuccess = getFlash('success');
$flashInfo    = getFlash('info');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'IAMS') ?> — IAMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;1,9..144,300&display=swap" rel="stylesheet">
    <style>
        :root {
            --maroon:    #8B1A1A;
            --maroon-d:  #6b1414;
            --navy:      #1a2e4a;
            --navy-mid:  #243d5e;
            --navy-l:    #2d5080;
            --gold:      #c9952a;
            --gold-l:    #f0c45a;
            --bg:        #f0f3f8;
            --bg-card:   #ffffff;
            --border:    #dde2eb;
            --text:      #1a1f2e;
            --muted:     #5a6478;
            --light:     #8a94a8;
            --shadow-sm: 0 1px 4px rgba(0,0,0,.07),0 1px 2px rgba(0,0,0,.04);
            --shadow-md: 0 4px 16px rgba(0,0,0,.10),0 2px 4px rgba(0,0,0,.05);
            --shadow-lg: 0 10px 32px rgba(0,0,0,.13);
            --r:         10px;
            --r-sm:      6px;
            --r-lg:      14px;
            --font:      'Outfit', sans-serif;
            --serif:     'Fraunces', serif;
            --ease:      all .18s ease;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { font-family: var(--font); font-size: 14.5px; background: var(--bg); color: var(--text); line-height: 1.65; min-height: 100vh; }
        a { color: var(--navy-l); text-decoration: none; transition: var(--ease); }
        a:hover { color: var(--maroon); }


        nav {
            position: sticky; top: 0; z-index: 200;
            height: 62px; background: var(--navy);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 24px;
            box-shadow: 0 2px 20px rgba(0,0,0,.25);
        }
        nav::after {
            content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, var(--maroon) 0%, var(--gold) 55%, transparent 100%);
        }
        nav .brand { display: flex; align-items: center; gap: 11px; text-decoration: none; flex-shrink: 0; }
        nav .brand img { height: 38px; width: auto; filter: drop-shadow(0 1px 4px rgba(0,0,0,.35)); }
        nav .brand-text { display: flex; flex-direction: column; line-height: 1.2; }
        nav .brand-text .b-title { font-family: var(--serif); font-size: 13.5px; font-weight: 600; color: #fff; }
        nav .brand-text .b-sub { font-size: 9px; font-weight: 600; color: var(--gold-l); letter-spacing: 2px; text-transform: uppercase; }
        .nav-links { display: flex; align-items: center; gap: 2px; }
        .nav-divider { width: 1px; height: 16px; background: rgba(255,255,255,.15); margin: 0 5px; flex-shrink: 0; }
        .nav-role { font-size: 10px; font-weight: 700; background: var(--maroon); color: #fff; padding: 3px 10px; border-radius: 20px; letter-spacing: 1.2px; text-transform: uppercase; margin: 0 3px; flex-shrink: 0; }
        .nav-signout { font-size: 12.5px !important; color: rgba(255,255,255,.6) !important; border: 1px solid rgba(255,255,255,.18) !important; border-radius: 20px !important; padding: 4px 13px !important; }
        .nav-signout:hover { color: #fff !important; border-color: rgba(255,255,255,.4) !important; background: rgba(255,255,255,.08) !important; }
        .nav-bell { position: relative; display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 50%; font-size: 16px !important; color: rgba(255,255,255,.75) !important; padding: 0 !important; }
        .nav-bell:hover { background: rgba(255,255,255,.12) !important; color: #fff !important; }
        .bell-dot { position: absolute; top: 4px; right: 4px; width: 8px; height: 8px; background: #ef4444; border-radius: 50%; border: 1.5px solid var(--navy); }


        .app-shell { display: flex; min-height: calc(100vh - 62px); }


        .sidebar {
            width: 214px; flex-shrink: 0;
            background: var(--bg-card);
            border-right: 1px solid var(--border);
            padding: 18px 0 0;
            display: flex; flex-direction: column;
            position: sticky; top: 62px;
            height: calc(100vh - 62px); overflow-y: auto;
        }
        .sidebar-label { font-size: 9px; font-weight: 700; color: var(--light); text-transform: uppercase; letter-spacing: 1.6px; padding: 0 14px; margin: 14px 0 4px; }
        .sidebar-section { padding: 0 8px; }
        .sidebar a {
            position: relative; display: flex; align-items: center; gap: 9px;
            padding: 7.5px 10px; border-radius: 7px;
            color: var(--muted); font-size: 13px; font-weight: 500;
            transition: var(--ease); white-space: nowrap;
        }
        .sidebar a .s-icon { width: 16px; height: 16px; flex-shrink: 0; opacity: .55; transition: opacity .15s; }
        .sidebar a:hover { color: var(--navy); background: var(--bg); }
        .sidebar a:hover .s-icon { opacity: .9; }
        .sidebar a.active { color: var(--navy); background: #eef1f8; font-weight: 600; }
        .sidebar a.active .s-icon { opacity: 1; }
        .sidebar a.active::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 3px; height: 18px; background: var(--maroon); border-radius: 0 2px 2px 0; }
        .sidebar-bottom { margin-top: auto; padding: 14px 8px 14px; border-top: 1px solid var(--border); }
        .sidebar-user { display: flex; align-items: center; gap: 9px; padding: 6px 8px; border-radius: 7px; }
        .sidebar-avatar { width: 30px; height: 30px; border-radius: 50%; background: var(--navy); display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #fff; flex-shrink: 0; }
        .sidebar-user-name { font-size: 12.5px; font-weight: 600; color: var(--navy); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 130px; }
        .sidebar-user-role { font-size: 9.5px; color: var(--light); text-transform: uppercase; letter-spacing: .8px; }


        .main-content { flex: 1; min-width: 0; }
        .page-wrap { padding: 24px 28px 52px; animation: fadeUp .22s ease both; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }


        .card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--r-lg); padding: 22px 24px; margin-bottom: 20px; box-shadow: var(--shadow-sm); transition: box-shadow .2s; }
        .card:hover { box-shadow: var(--shadow-md); }
        .card h2 { font-family: var(--serif); font-size: 15.5px; font-weight: 600; color: var(--navy); margin-bottom: 16px; padding-bottom: 10px; border-bottom: 1px solid #eef1f7; display: flex; align-items: center; gap: 8px; }
        .card h2::before { content: ''; display: block; width: 3px; height: 15px; background: var(--maroon); border-radius: 2px; flex-shrink: 0; }
        .card h3 { font-size: 14px; color: var(--navy); margin-bottom: 12px; font-weight: 600; }


        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: .6px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 9px 13px; border: 1.5px solid #d2d8e4; border-radius: var(--r-sm); font-size: 14px; font-family: var(--font); color: var(--text); background: #fff; transition: var(--ease); outline: none; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: var(--navy-l); box-shadow: 0 0 0 3px rgba(45,80,128,.12); }
        .form-group textarea { resize: vertical; min-height: 86px; }
        .form-group small { color: var(--light); font-size: 12px; margin-top: 4px; display: block; }


        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 18px; border: none; border-radius: var(--r-sm); cursor: pointer; font-size: 13px; font-weight: 600; font-family: var(--font); text-decoration: none; transition: var(--ease); letter-spacing: .1px; white-space: nowrap; }
        .btn:hover { transform: translateY(-1px); box-shadow: var(--shadow-md); text-decoration: none; }
        .btn:active { transform: none; box-shadow: none; }
        .btn-primary   { background: var(--navy); color: #fff; }
        .btn-primary:hover { background: var(--navy-mid); color: #fff; }
        .btn-success   { background: #0c6b35; color: #fff; }
        .btn-success:hover { background: #0a5a2c; color: #fff; }
        .btn-danger    { background: var(--maroon); color: #fff; }
        .btn-danger:hover { background: var(--maroon-d); color: #fff; }
        .btn-secondary { background: #fff; color: var(--muted); border: 1.5px solid var(--border); }
        .btn-secondary:hover { background: #f4f6fb; color: var(--text); }
        .btn-gold      { background: var(--gold); color: #fff; }
        .btn-gold:hover { background: #b5831f; color: #fff; }
        .btn-sm { padding: 5px 12px; font-size: 12px; }
        .btn-sm:hover { transform: none; box-shadow: none; }


        .alert { padding: 11px 15px; border-radius: var(--r-sm); margin-bottom: 16px; font-size: 13.5px; border-left: 3px solid transparent; display: flex; align-items: flex-start; gap: 8px; }
        .alert-error   { background: #fef2f2; border-left-color: #ef4444; color: #7f1d1d; }
        .alert-success { background: #f0fdf4; border-left-color: #22c55e; color: #14532d; }
        .alert-info    { background: #eff6ff; border-left-color: var(--navy-l); color: #1e3a5f; }
        .alert-warn    { background: #fffbeb; border-left-color: var(--gold); color: #78350f; }


        table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
        thead tr { background: var(--navy); }
        thead th { padding: 10px 14px; text-align: left; font-size: 10.5px; font-weight: 700; color: rgba(255,255,255,.8); text-transform: uppercase; letter-spacing: .9px; }
        tbody td { padding: 10px 14px; border-bottom: 1px solid #eef1f7; vertical-align: middle; }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: #f8f9fd; }
        .card > table thead tr { background: none; }
        .card > table thead th { background: #f4f6fb; color: var(--muted); font-size: 11.5px; border: 1px solid #eef1f7; }
        .card > table tbody td { border: 1px solid #eef1f7; }


        .badge { display: inline-flex; align-items: center; padding: 3px 9px; border-radius: 20px; font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; }
        .badge-pending   { background: #fef3c7; color: #92400e; }
        .badge-accepted  { background: #d1fae5; color: #065f46; }
        .badge-rejected  { background: #fee2e2; color: #7f1d1d; }
        .badge-approved  { background: #d1fae5; color: #065f46; }
        .badge-offered   { background: #dbeafe; color: #1e3a8a; }
        .badge-withdrawn { background: #f3f4f6; color: #374151; }
        .badge-wp        { background: #ede9fe; color: #4c1d95; }


        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 14px; margin-bottom: 22px; }
        .stat-box { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--r-lg); padding: 18px 16px 16px; box-shadow: var(--shadow-sm); position: relative; overflow: hidden; transition: var(--ease); }
        .stat-box:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
        .stat-box::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px; background: linear-gradient(90deg, var(--maroon), var(--gold)); }
        .stat-box .stat-num { font-family: var(--serif); font-size: 34px; font-weight: 600; color: var(--navy); line-height: 1; margin-bottom: 4px; }
        .stat-box .stat-label { font-size: 11px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .65px; }


        .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media(max-width: 720px) { .two-col { grid-template-columns: 1fr; } }
        .mt-10 { margin-top: 10px; }
        .mt-20 { margin-top: 20px; }
        .text-muted  { color: var(--muted); font-size: 13px; }
        .text-center { text-align: center; }
        .flex-between { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        h1.page-title { font-family: var(--serif); font-size: 21px; font-weight: 600; color: var(--navy); margin-bottom: 18px; }

        @media(max-width: 900px) {
            nav { padding: 0 14px; }
            .sidebar { display: none; }
            .page-wrap { padding: 18px 16px 40px; }
            nav .brand-text { display: none; }
        }
        @media(max-width: 600px) { .stats-grid { grid-template-columns: 1fr 1fr; } }
    </style>
</head>
<body>

<nav>
    <a href="<?= BASE_URL ?>/index.php" class="brand">
        <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="University of Botswana">
        <div class="brand-text">
            <span class="b-title">University of Botswana</span>
            <span class="b-sub">IAMS Portal</span>
        </div>
    </a>
    <span class="nav-links">
        <?php if (isLoggedIn()): ?>
            <?php if (currentRole() === 'student'): ?>
                <?php
                $db_nav = getDB();
                $nq = $db_nav->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
                $nq->execute([$_SESSION['user_id']]);
                $unread = (int)$nq->fetchColumn();
                ?>
                <a href="<?= BASE_URL ?>/student/notifications.php" class="nav-bell" title="Notifications">
                    🔔<?php if ($unread > 0): ?><span class="bell-dot"></span><?php endif; ?>
                </a>
                <span class="nav-divider"></span>
            <?php endif; ?>

            <a href="<?= BASE_URL ?>/logout.php" class="nav-signout">Sign out</a>
        <?php elseif (($pageTitle ?? '') !== 'Login'): ?>
            <a href="<?= BASE_URL ?>/login.php" style="color:rgba(255,255,255,.7);font-size:13px;padding:6px 11px;border-radius:6px;">Login</a>
            <a href="<?= BASE_URL ?>/register.php" style="color:rgba(255,255,255,.7);font-size:13px;padding:6px 11px;border-radius:6px;">Register</a>
        <?php endif; ?>
    </span>
</nav>

<div class="app-shell">
<?php if (isLoggedIn()): ?>
<aside class="sidebar">
    <?php $role = currentRole(); ?>
    <div class="sidebar-section">
        <div class="sidebar-label">Menu</div>
        <?php if ($role === 'student'): ?>
            <a href="<?= BASE_URL ?>/student/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/student/apply.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>Browse &amp; Apply</a>
            <a href="<?= BASE_URL ?>/student/applications.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Applications</a>
            <a href="<?= BASE_URL ?>/student/vacancies.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-4 0v2"/></svg>Vacancies</a>
            <a href="<?= BASE_URL ?>/student/my_internship.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>My Internship</a>
            <a href="<?= BASE_URL ?>/student/reports.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Reports</a>
            <a href="<?= BASE_URL ?>/student/my_grade.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>My Grade</a>
        <?php elseif ($role === 'company'): ?>
            <a href="<?= BASE_URL ?>/company/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/company/applicants.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Applicants</a>
            <a href="<?= BASE_URL ?>/company/vacancies.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-4 0v2"/></svg>Vacancies</a>
            <a href="<?= BASE_URL ?>/company/wp_supervisors.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>WP Supervisors</a>
            <a href="<?= BASE_URL ?>/company/reports.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Student Reports</a>
            <a href="<?= BASE_URL ?>/company/profile.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 13h6M9 17h4"/></svg>Profile</a>
        <?php elseif ($role === 'lecturer'): ?>
            <a href="<?= BASE_URL ?>/lecturer/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/lecturer/students.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>My Students</a>
            <a href="<?= BASE_URL ?>/lecturer/summative_report.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Summative Report</a>
            <a href="<?= BASE_URL ?>/lecturer/reports.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Reports</a>
        <?php elseif ($role === 'coordinator'): ?>
            <a href="<?= BASE_URL ?>/coordinator/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/coordinator/students.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Students</a>
            <a href="<?= BASE_URL ?>/coordinator/active_placements.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/></svg>Placements</a>
            <a href="<?= BASE_URL ?>/coordinator/assign.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Assign</a>
            <a href="<?= BASE_URL ?>/coordinator/marks_table.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>Marks</a>
            <a href="<?= BASE_URL ?>/coordinator/rubric.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>Rubric</a>
            <a href="<?= BASE_URL ?>/coordinator/company_requests.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>Requests</a>
            <a href="<?= BASE_URL ?>/coordinator/vacancies.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-4 0v2"/></svg>Vacancies</a>
        <?php elseif ($role === 'admin'): ?>
            <a href="<?= BASE_URL ?>/admin/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Users</a>
            <a href="<?= BASE_URL ?>/admin/pending_approvals.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Pending Approvals</a>
            <a href="<?= BASE_URL ?>/admin/applications.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Applications</a>
            <a href="<?= BASE_URL ?>/admin/grades_report.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Grades</a>

        <?php elseif ($role === 'workplace_supervisor'): ?>
            <a href="<?= BASE_URL ?>/workplace_supervisor/dashboard.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
            <a href="<?= BASE_URL ?>/workplace_supervisor/my_students.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>My Students</a>
            <a href="<?= BASE_URL ?>/workplace_supervisor/summative_report.php"><svg class="s-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Summative Report</a>
        <?php endif; ?>
    </div>

    <div class="sidebar-bottom">
        <div class="sidebar-user">
            <div class="sidebar-avatar"><?= strtoupper(substr($_SESSION['display_name'] ?? $_SESSION['email'] ?? 'U', 0, 1)) ?></div>
            <div>
                <div class="sidebar-user-name"><?= htmlspecialchars($_SESSION['display_name'] ?? $_SESSION['email'] ?? '') ?></div>
                <div class="sidebar-user-role"><?= htmlspecialchars(str_replace('_', ' ', $_SESSION['role'] ?? '')) ?></div>
            </div>
        </div>
    </div>
</aside>
<?php endif; ?>

<div class="main-content">
<div class="page-wrap">
<?php if ($flashError):   ?><div class="alert alert-error"><?= htmlspecialchars($flashError) ?></div><?php endif; ?>
<?php if ($flashSuccess): ?><div class="alert alert-success"><?= htmlspecialchars($flashSuccess) ?></div><?php endif; ?>
<?php if ($flashInfo):    ?><div class="alert alert-info"><?= htmlspecialchars($flashInfo) ?></div><?php endif; ?>
