<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function requireLogin(): void {
    if (empty($_SESSION['user_id'])) {
        $_SESSION['flash_error'] = 'You must be logged in to access that page.';
        header('Location: ' . BASE_URL . '/login.php'); exit;
    }
}

function requireRole(string ...$roles): void {
    requireLogin();
    if (!in_array($_SESSION['role'] ?? '', $roles, true)) {
        http_response_code(403);
        die(
            '<h2 style="font-family:sans-serif;color:red">403 — Access Denied</h2>' .
            '<p style="font-family:sans-serif">You do not have permission to view this page.</p>' .
            '<p style="font-family:sans-serif"><a href="' . BASE_URL . '/login.php">Go to Login</a></p>'
        );
    }
}

function requireApproved(): void {
    requireLogin();
    $role = $_SESSION['role'] ?? '';
    if (in_array($role, ['student', 'lecturer', 'coordinator'], true) && empty($_SESSION['is_approved'])) {
        header('Location: ' . dashboardUrl($role)); exit;
    }
}

function isLoggedIn(): bool    { return !empty($_SESSION['user_id']); }
function currentRole(): string { return $_SESSION['role'] ?? ''; }
function currentUserId(): int  { return (int)($_SESSION['user_id'] ?? 0); }

function setFlash(string $type, string $msg): void { $_SESSION['flash_' . $type] = $msg; }
function getFlash(string $type): string {
    $msg = $_SESSION['flash_' . $type] ?? '';
    unset($_SESSION['flash_' . $type]);
    return $msg;
}

function dashboardUrl(string $role): string {
    $map = [
        'student'              => BASE_URL . '/student/dashboard.php',
        'company'              => BASE_URL . '/company/dashboard.php',
        'lecturer'             => BASE_URL . '/lecturer/dashboard.php',
        'admin'                => BASE_URL . '/admin/dashboard.php',
        'coordinator'          => BASE_URL . '/coordinator/dashboard.php',
        'workplace_supervisor' => BASE_URL . '/workplace_supervisor/dashboard.php',
    ];
    return $map[$role] ?? BASE_URL . '/login.php';
}

function computeLetterGrade(PDO $db, float $total): string {
    $scale = $db->query('SELECT letter, min_score, max_score FROM grading_scale ORDER BY min_score DESC')->fetchAll();
    foreach ($scale as $s) {
        if ($total >= (float)$s['min_score'] && $total <= (float)$s['max_score']) return $s['letter'];
    }
    return 'F';
}

function recomputeFinalGradeNew(PDO $db, int $studentId): void {
    $wps  = $db->prepare('SELECT total_score FROM wps_summative_reports WHERE student_id=? AND status="submitted"');
    $wps->execute([$studentId]); $wpsRow = $wps->fetch();

    $acad = $db->prepare('SELECT total_score FROM academic_summative_reports WHERE student_id=? AND status="submitted"');
    $acad->execute([$studentId]); $acadRow = $acad->fetch();

    $rep  = $db->prepare('SELECT total_score FROM student_report_grades WHERE student_id=? AND status="submitted"');
    $rep->execute([$studentId]); $repRow = $rep->fetch();

    $wpsScore  = $wpsRow  ? (float)$wpsRow['total_score']  : null;
    $acadScore = $acadRow ? (float)$acadRow['total_score'] : null;
    $repScore  = $repRow  ? (float)$repRow['total_score']  : null;

    $total = null; $letter = null;
    if ($wpsScore !== null && $acadScore !== null && $repScore !== null) {
        $total  = round(($wpsScore * 0.30) + ($acadScore * 0.20) + ($repScore * 0.50), 2);
        $letter = computeLetterGrade($db, $total);
    }

    $submitted = array_filter([$wpsScore, $acadScore, $repScore], fn($v) => $v !== null);
    if (count($submitted) === 0)   $status = 'pending';
    elseif (count($submitted) < 3) $status = 'partial';
    else                           $status = 'submitted';

    $discrepancy = 0;
    if ($wpsScore !== null && $acadScore !== null) {
        $discrepancy = (abs($wpsScore - $acadScore) >= 20) ? 1 : 0;
        if ($discrepancy && $status === 'submitted') $status = 'flagged';
    }

    $existing = $db->prepare('SELECT id FROM final_grades WHERE student_id=?');
    $existing->execute([$studentId]);
    if ($existing->fetch()) {
        $db->prepare('UPDATE final_grades SET wps_report_score=?, academic_report_score=?, student_report_score=?,
            workplace_score=?, lecturer_score=?, total_score=?, letter_grade=?, status=?, discrepancy_flag=?, updated_at=NOW()
            WHERE student_id=?')
           ->execute([$wpsScore, $acadScore, $repScore, $wpsScore, $acadScore, $total, $letter, $status, $discrepancy, $studentId]);
    } else {
        $db->prepare('INSERT INTO final_grades (student_id, wps_report_score, academic_report_score, student_report_score,
            workplace_score, lecturer_score, total_score, letter_grade, status, discrepancy_flag)
            VALUES (?,?,?,?,?,?,?,?,?,?)')
           ->execute([$studentId, $wpsScore, $acadScore, $repScore, $wpsScore, $acadScore, $total, $letter, $status, $discrepancy]);
    }
}

function sendNotification(PDO $db, int $userId, string $message, string $link = ''): void {
    $db->prepare('INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)')
       ->execute([$userId, $message, $link ?: null]);
}
