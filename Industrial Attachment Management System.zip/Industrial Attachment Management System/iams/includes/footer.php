</div>
</div>
</div>

<footer style="background:var(--navy);border-top:2px solid var(--maroon);padding:13px 28px;display:flex;justify-content:center;align-items:center;margin-top:auto;">
    <span style="font-size:12px;color:rgba(255,255,255,.38);font-family:'Outfit',sans-serif;">
        &copy; <?= date('Y') ?> University of Botswana
    </span>
</footer>
</body>
</html>
