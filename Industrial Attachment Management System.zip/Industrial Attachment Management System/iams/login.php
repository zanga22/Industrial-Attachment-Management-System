<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) { header('Location: ' . dashboardUrl(currentRole())); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '')                                    $errors[] = 'Email is required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))  $errors[] = 'Please enter a valid email address.';
    if ($password === '')                                 $errors[] = 'Password is required.';

    if (empty($errors)) {
        $db   = getDB();
        $stmt = $db->prepare('SELECT id, email, password, role, is_active FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            $errors[] = 'Invalid email or password.';
        } elseif (!$user['is_active']) {
            $errors[] = 'Your account has been deactivated. Please contact the admin.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email']   = $user['email'];
            $_SESSION['role']    = $user['role'];

            $roleProfiles = [
                'student'              => ['table' => 'students',              'name_col' => true,  'approved' => true],
                'company'              => ['table' => 'companies',             'name_col' => false, 'approved' => false],
                'lecturer'             => ['table' => 'lecturers',             'name_col' => true,  'approved' => true],
                'coordinator'          => ['table' => 'coordinators',          'name_col' => true,  'approved' => false],
                'workplace_supervisor' => ['table' => 'workplace_supervisors', 'name_col' => true,  'approved' => false],
            ];

            if (isset($roleProfiles[$user['role']])) {
                $cfg = $roleProfiles[$user['role']];
                if ($cfg['name_col']) {
                    $s = $db->prepare("SELECT id, first_name, last_name" . ($cfg['approved'] ? ', is_approved' : '') . ($user['role'] === 'workplace_supervisor' ? ', company_id' : '') . " FROM {$cfg['table']} WHERE user_id = ?");
                } else {
                    $s = $db->prepare("SELECT id, company_name FROM {$cfg['table']} WHERE user_id = ?");
                }
                $s->execute([$user['id']]);
                $p = $s->fetch();
                if ($p) {
                    $_SESSION['profile_id']   = $p['id'];
                    $_SESSION['display_name'] = $cfg['name_col'] ? ($p['first_name'] . ' ' . $p['last_name']) : $p['company_name'];
                    if ($cfg['approved'] && isset($p['is_approved']))     $_SESSION['is_approved']  = (bool)$p['is_approved'];
                    if ($user['role'] === 'workplace_supervisor')         $_SESSION['company_id']   = $p['company_id'];
                }
            } else {
                $_SESSION['display_name'] = 'Administrator';
            }

            setFlash('success', 'Welcome back, ' . ($_SESSION['display_name'] ?? $user['email']) . '!');
            header('Location: ' . dashboardUrl($user['role'])); exit;
        }
    }
}

$pageTitle = 'Login';
require_once __DIR__ . '/includes/header.php';
?>
<style>
body { background: linear-gradient(135deg, #1a2e4a 0%, #243d5e 50%, #6b1414 100%); }
.page-wrap { display:flex; align-items:center; justify-content:center; min-height:calc(100vh - 64px); padding:32px 16px; }
@keyframes fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
.login-box  { width:100%; max-width:420px; animation:fadeUp .3s ease both; }
.login-card { background:rgba(255,255,255,.97); border-radius:16px; box-shadow:0 24px 60px rgba(0,0,0,.35),0 4px 12px rgba(0,0,0,.15); overflow:hidden; }
.login-header { background:linear-gradient(135deg,#1a2e4a,#243d5e); padding:30px 32px 26px; text-align:center; border-bottom:3px solid #8B1A1A; }
.login-header img { height:64px; margin-bottom:12px; filter:drop-shadow(0 2px 6px rgba(0,0,0,.4)); }
.login-header h1 { font-family:'DM Serif Display',serif; font-size:20px; color:#fff; margin-bottom:3px; }
.login-header p  { font-size:11px; color:#f0c45a; letter-spacing:1.5px; text-transform:uppercase; font-weight:600; }
.login-body { padding:28px 32px 24px; }
.login-body .form-group label { color:#5a6478; }
.login-body .form-group input { border:1.5px solid #d2d8e4; border-radius:8px; padding:10px 14px; font-size:14px; transition:all .18s ease; }
.login-body .form-group input:focus { border-color:#2d5080; box-shadow:0 0 0 3px rgba(45,80,128,.13); }
.btn-login { width:100%; padding:11px; background:linear-gradient(135deg,#1a2e4a,#2d5080); color:#fff; border:none; border-radius:8px; font-size:15px; font-weight:700; font-family:'DM Sans',sans-serif; cursor:pointer; letter-spacing:.3px; transition:all .18s ease; margin-top:4px; }
.btn-login:hover { background:linear-gradient(135deg,#243d5e,#1a2e4a); box-shadow:0 4px 16px rgba(26,46,74,.35); transform:translateY(-1px); }
.login-footer { padding:0 32px 24px; text-align:center; }
.login-footer a { color:#2d5080; font-weight:600; font-size:13.5px; }
.login-footer a:hover { color:#8B1A1A; }
.guidelines-btn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; margin-top:14px; padding:10px 16px; background:transparent; border:1.5px solid rgba(139,26,26,.35); border-radius:8px; color:#8B1A1A; font-family:'DM Sans',sans-serif; font-size:13px; font-weight:600; text-decoration:none; letter-spacing:.2px; transition:all .18s ease; }
.guidelines-btn:hover { box-shadow:0 4px 16px rgba(139,26,26,.2); transform:translateY(-1px); color:#8B1A1A; }
</style>

<div class="login-box">
    <div class="login-card">
        <div class="login-header">
            <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="UB Logo">
            <h1>Industrial Attachment Portal</h1>
        </div>
        <div class="login-body">
            <?php foreach ($errors as $e): ?>
                <div class="alert alert-error" style="margin-bottom:16px;">⚠ <?= htmlspecialchars($e) ?></div>
            <?php endforeach; ?>
            <form method="POST" action="login.php" novalidate>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           required placeholder="you@ub.bw" autofocus>
                </div>
                <div class="form-group" style="margin-bottom:20px;">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn-login">Sign In →</button>
            </form>
        </div>
        <div class="login-footer">
            <p style="font-size:13.5px;color:#5a6478;">Don't have an account? <a href="register.php">Register here</a></p>
            <a href="<?= BASE_URL ?>/uploads/ATTACHMENT_GUIDELINES.pdf" class="guidelines-btn" target="_blank">
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                </svg>
                Read Attachment Guidelines
            </a>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
