<?php
if (!defined('BASE_URL')) {
    $configDir  = str_replace('\\', '/', __DIR__);
    $docRoot    = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
    $projectDir = str_replace('\\', '/', dirname($configDir));
    $base = str_replace($docRoot, '', $projectDir);
    $base = rtrim($base, '/');
    define('BASE_URL', $base);
}
