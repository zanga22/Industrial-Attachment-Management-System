<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('workplace_supervisor');

$db    = getDB();
$wpsId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('
    SELECT w.*, c.company_name, u.email,
           CONCAT(w.first_name," ",w.last_name) AS full_name
    FROM workplace_supervisors w
    JOIN companies c ON w.company_id = c.id
    JOIN users u ON w.user_id = u.id
    WHERE w.id = ?
');
$profile->execute([$wpsId]);
$wps = $profile->fetch();
if (!$wps) { die('Profile not found.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = (int)($_POST['student_id'] ?? 0);
    $action    = $_POST['action'] ?? 'save_draft';


    $chk = $db->prepare('
        SELECT wa.student_id, u.id AS user_id
        FROM workplace_assignments wa
        JOIN students s ON wa.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE wa.student_id = ? AND wa.workplace_supervisor_id = ?
    ');
    $chk->execute([$studentId, $wpsId]);
    $stuRow = $chk->fetch();
    if (!$stuRow) { setFlash('error','Student not found or not assigned to you.'); header('Location: summative_report.php'); exit; }


    $existing = $db->prepare('SELECT id, status FROM wps_summative_reports WHERE student_id = ?');
    $existing->execute([$studentId]);
    $existingReport = $existing->fetch();
    if ($existingReport && $existingReport['status'] === 'submitted') {
        setFlash('error','You have already submitted the summative report for this student.');
        header('Location: summative_report.php?student_id='.$studentId); exit;
    }

    $isDraft     = ($action === 'save_draft');
    $status      = $isDraft ? 'draft' : 'submitted';
    $submittedAt = $isDraft ? null : date('Y-m-d H:i:s');


    $stuInfo = $db->prepare('
        SELECT s.first_name, s.last_name, s.student_number, s.programme,
               c.company_name,
               (SELECT CONCAT(wps2.first_name," ",wps2.last_name) FROM workplace_supervisors wps2 WHERE wps2.id=?) AS sup_name,
               (SELECT wps2.job_title FROM workplace_supervisors wps2 WHERE wps2.id=?) AS sup_title,
               (SELECT wps2.department FROM workplace_supervisors wps2 WHERE wps2.id=?) AS sup_dept
        FROM students s
        JOIN workplace_assignments wa ON wa.student_id = s.id
        JOIN companies c ON wa.company_id = c.id
        WHERE s.id = ?
    ');
    $stuInfo->execute([$wpsId, $wpsId, $wpsId, $studentId]);
    $info = $stuInfo->fetch();


    $fields = [
        'conduct_punctuality','conduct_appearance','conduct_initiative','conduct_teamwork',
        'tech_application','tech_problem_solving','tech_quality',
        'comm_written','comm_verbal',
        'ethic_responsibility','ethic_adaptability','ethic_improvement'
    ];
    $maxMap = [
        'conduct_punctuality'=>5,'conduct_appearance'=>5,'conduct_initiative'=>5,'conduct_teamwork'=>5,
        'tech_application'=>10,'tech_problem_solving'=>10,'tech_quality'=>10,
        'comm_written'=>10,'comm_verbal'=>10,
        'ethic_responsibility'=>10,'ethic_adaptability'=>10,'ethic_improvement'=>10
    ];
    $scores = [];
    $total  = 0;
    foreach ($fields as $f) {
        $val = min(max(0, (float)($_POST[$f] ?? 0)), (float)$maxMap[$f]);
        $scores[$f] = $val;
        $total += $val;
    }

    $data = array_merge($scores, [
        'student_id'              => $studentId,
        'workplace_supervisor_id' => $wpsId,
        'company_id'              => $wps['company_id'],
        'student_name'            => ($info['first_name'] ?? '').' '.($info['last_name'] ?? ''),
        'student_number'          => $info['student_number'] ?? '',
        'programme'               => $info['programme'] ?? '',
        'company_name'            => $info['company_name'] ?? $wps['company_name'],
        'supervisor_name'         => $wps['full_name'],
        'supervisor_title'        => $wps['job_title'] ?? '',
        'department'              => $wps['department'] ?? '',
        'attachment_period'       => trim($_POST['attachment_period'] ?? ''),
        'general_comments'        => trim($_POST['general_comments'] ?? ''),
        'strengths'               => trim($_POST['strengths'] ?? ''),
        'areas_for_improvement'   => trim($_POST['areas_for_improvement'] ?? ''),
        'recommendation'          => $_POST['recommendation'] ?? null,
        'total_score'             => $total,
        'status'                  => $status,
        'submitted_at'            => $submittedAt,
    ]);

    $db->beginTransaction();
    try {
        if ($existingReport) {
            $db->prepare('UPDATE wps_summative_reports SET
                student_name=:student_name, student_number=:student_number, programme=:programme,
                company_name=:company_name, supervisor_name=:supervisor_name,
                supervisor_title=:supervisor_title, department=:department,
                attachment_period=:attachment_period,
                conduct_punctuality=:conduct_punctuality, conduct_appearance=:conduct_appearance,
                conduct_initiative=:conduct_initiative, conduct_teamwork=:conduct_teamwork,
                tech_application=:tech_application, tech_problem_solving=:tech_problem_solving,
                tech_quality=:tech_quality,
                comm_written=:comm_written, comm_verbal=:comm_verbal,
                ethic_responsibility=:ethic_responsibility, ethic_adaptability=:ethic_adaptability,
                ethic_improvement=:ethic_improvement,
                general_comments=:general_comments, strengths=:strengths,
                areas_for_improvement=:areas_for_improvement, recommendation=:recommendation,
                total_score=:total_score, status=:status, submitted_at=:submitted_at
                WHERE student_id=:student_id
            ')->execute($data);
        } else {
            $db->prepare('INSERT INTO wps_summative_reports (
                student_id, workplace_supervisor_id, company_id,
                student_name, student_number, programme, company_name,
                supervisor_name, supervisor_title, department, attachment_period,
                conduct_punctuality, conduct_appearance, conduct_initiative, conduct_teamwork,
                tech_application, tech_problem_solving, tech_quality,
                comm_written, comm_verbal,
                ethic_responsibility, ethic_adaptability, ethic_improvement,
                general_comments, strengths, areas_for_improvement, recommendation,
                total_score, status, submitted_at
            ) VALUES (
                :student_id, :workplace_supervisor_id, :company_id,
                :student_name, :student_number, :programme, :company_name,
                :supervisor_name, :supervisor_title, :department, :attachment_period,
                :conduct_punctuality, :conduct_appearance, :conduct_initiative, :conduct_teamwork,
                :tech_application, :tech_problem_solving, :tech_quality,
                :comm_written, :comm_verbal,
                :ethic_responsibility, :ethic_adaptability, :ethic_improvement,
                :general_comments, :strengths, :areas_for_improvement, :recommendation,
                :total_score, :status, :submitted_at
            )')->execute($data);
        }

        $db->prepare('INSERT INTO grade_audit_log (student_id, action, performed_by, details) VALUES (?,?,?,?)')
           ->execute([$studentId, $isDraft ? 'wps_summative_draft' : 'wps_summative_submitted', currentUserId(), "Total: $total/100"]);

        if (!$isDraft) {
            recomputeFinalGradeNew($db, $studentId);


            $acadSup = $db->prepare('
                SELECT u.id FROM supervisor_assignments sa
                JOIN lecturers l ON sa.lecturer_id = l.id
                JOIN users u ON l.user_id = u.id
                WHERE sa.student_id = ?
            ');
            $acadSup->execute([$studentId]);
            $as = $acadSup->fetch();
            if ($as) {
                sendNotification($db, $as['id'],
                    'The workplace supervisor has submitted the summative report for '.($data['student_name']).'. Please review.',
                    BASE_URL.'/lecturer/summative_report.php?student_id='.$studentId);
            }

            $coord = $db->query('SELECT u.id FROM coordinators c JOIN users u ON c.user_id=u.id LIMIT 1')->fetch();
            if ($coord) {
                sendNotification($db, $coord['id'],
                    'WPS summative report submitted for student '.($data['student_name']).'.',
                    BASE_URL.'/coordinator/marks_table.php');
            }
        }

        $db->commit();
        setFlash('success', $isDraft ? 'Draft saved.' : 'Summative report submitted. Academic supervisor and coordinator have been notified.');
    } catch (Exception $e) {
        $db->rollBack();
        setFlash('error', 'Error: '.$e->getMessage());
    }
    header('Location: summative_report.php?student_id='.$studentId); exit;
}

$students = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           r.status AS report_status, r.total_score AS report_score
    FROM workplace_assignments wa
    JOIN students s ON wa.student_id = s.id
    LEFT JOIN wps_summative_reports r ON r.student_id = s.id
    WHERE wa.workplace_supervisor_id = ?
    ORDER BY s.last_name
');
$students->execute([$wpsId]);
$assignedStudents = $students->fetchAll();

$selectedId = (int)($_GET['student_id'] ?? 0);
$selStudent = null;
foreach ($assignedStudents as $st) { if ((int)$st['id'] === $selectedId) { $selStudent = $st; break; } }

$reportData = [];
if ($selStudent) {
    $rd = $db->prepare('SELECT * FROM wps_summative_reports WHERE student_id = ?');
    $rd->execute([$selectedId]);
    $reportData = $rd->fetch() ?: [];
}

$isSubmitted = !empty($reportData['status']) && $reportData['status'] === 'submitted';

$pageTitle = 'Summative Report';
require_once __DIR__ . '/../includes/header.php';

function fv(array $data, string $key, $default = ''): string {
    return htmlspecialchars((string)($data[$key] ?? $default));
}
function fv_float(array $data, string $key): string {
    return isset($data[$key]) ? number_format((float)$data[$key], 1) : '';
}
?>

<style>
.sr-header { background:#1e3a5f; color:#fff; padding:20px 28px; border-radius:8px 8px 0 0; margin-bottom:0; }
.sr-header h1 { font-size:18px; margin:0 0 4px 0; color:#fff; }
.sr-header p  { font-size:13px; margin:0; opacity:.8; color:#fff; }
.sr-body      { border:1px solid #d1d5db; border-top:none; border-radius:0 0 8px 8px; padding:24px; background:#f9fafb; }
.sr-section   { margin-bottom:28px; }
.sr-section h2{ font-size:15px; color:#1e3a5f; border-bottom:2px solid #1e3a5f; padding-bottom:6px; margin-bottom:16px; }
.sr-grid      { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.sr-grid-3    { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
.sr-row       { display:flex; justify-content:space-between; align-items:center; padding:10px 14px;
                border:1px solid #e5e7eb; border-radius:6px; margin-bottom:6px; }
.sr-row:hover { background:#f8fafc; }
.sr-row label { font-size:13px; color:#374151; flex:1; }
.sr-row .sr-max{ font-size:11px; color:#9ca3af; margin:0 12px; white-space:nowrap; }
.sr-row input  { width:70px; text-align:center; padding:5px; border:1px solid #d1d5db; border-radius:4px; font-size:14px; }
.sr-subtotal  { background:#eff6ff; border:1px solid #bfdbfe; padding:8px 14px; border-radius:6px;
                font-size:13px; color:#1e40af; text-align:right; margin-bottom:16px; }
.info-grid    { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
.info-item    { font-size:13px; }
.info-item strong { display:block; font-size:11px; text-transform:uppercase; color:#9ca3af; margin-bottom:2px; }
</style>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Summative Report — Company Supervisor</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<div style="display:grid;grid-template-columns:260px 1fr;gap:20px;align-items:start;">

<!-- Sidebar -->
<div class="card" style="padding:16px;">
    <h2 style="font-size:15px;margin-bottom:12px;">My Students</h2>
    <?php if (empty($assignedStudents)): ?>
        <p class="text-muted" style="font-size:13px;">No students assigned.</p>
    <?php else: ?>
        <?php foreach ($assignedStudents as $st): ?>
            <a href="summative_report.php?student_id=<?= $st['id'] ?>"
               style="display:block;padding:10px;border-radius:4px;text-decoration:none;margin-bottom:6px;
                      background:<?= $selectedId===$st['id']?'#dbeafe':'#f8fafc' ?>;
                      border:1px solid <?= $selectedId===$st['id']?'#3b82f6':'#e2e8f0' ?>;">
                <div style="font-weight:bold;font-size:13px;color:#1e3a5f;">
                    <?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?>
                </div>
                <div style="font-size:11px;color:#666;"><?= htmlspecialchars($st['student_number']) ?></div>
                <div style="margin-top:4px;">
                    <?php if (!$st['report_status']): ?>
                        <span style="font-size:11px;color:#92400e;background:#fef3c7;padding:1px 6px;border-radius:8px;">Not started</span>
                    <?php elseif ($st['report_status'] === 'draft'): ?>
                        <span style="font-size:11px;color:#1e40af;background:#dbeafe;padding:1px 6px;border-radius:8px;">Draft</span>
                    <?php else: ?>
                        <span style="font-size:11px;color:#166534;background:#dcfce7;padding:1px 6px;border-radius:8px;"> Submitted <?= number_format($st['report_score'],1) ?>/100</span>
                    <?php endif; ?>
                </div>
            </a>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Main form -->
<div>
<?php if (!$selStudent): ?>
    <div class="card"><p class="text-muted">Select a student to fill their summative report.</p></div>
<?php else: ?>

    <!-- UB Header -->
    <div class="sr-header">
        <div style="display:flex;align-items:center;gap:16px;">
            <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="UB" style="height:48px;filter:brightness(0) invert(1);">
            <div>
                <h1>University of Botswana — Faculty of Science</h1>
                <p>Department of Computer Science &amp; Information Systems</p>
                <p style="font-size:11px;margin-top:4px;opacity:.7;">SUMMATIVE REPORT — COMPANY SUPERVISOR — Industrial Attachment (CS)</p>
            </div>
        </div>
    </div>

    <div class="sr-body">
        <?php if ($isSubmitted): ?>
            <div class="alert alert-success">Yes Summative report submitted on <?= date('d M Y H:i', strtotime($reportData['submitted_at'])) ?>. Total score: <strong><?= number_format($reportData['total_score'],1) ?>/100</strong>.</div>
        <?php endif; ?>

        <?php if ($isSubmitted): ?>
        <!-- Read-only view -->
        <div class="sr-section">
            <h2>A. Student &amp; Placement Information</h2>
            <div class="info-grid">
                <div class="info-item"><strong>Student Name</strong><?= fv($reportData,'student_name') ?></div>
                <div class="info-item"><strong>Student Number</strong><?= fv($reportData,'student_number') ?></div>
                <div class="info-item"><strong>Programme</strong><?= fv($reportData,'programme') ?></div>
                <div class="info-item"><strong>Company</strong><?= fv($reportData,'company_name') ?></div>
                <div class="info-item"><strong>Supervisor</strong><?= fv($reportData,'supervisor_name') ?></div>
                <div class="info-item"><strong>Period</strong><?= fv($reportData,'attachment_period') ?></div>
            </div>
        </div>

        <?php
        $sections = [
            'Professional Conduct (/20)' => [
                'conduct_punctuality' => ['Punctuality & Attendance',5],
                'conduct_appearance'  => ['Professional Appearance',5],
                'conduct_initiative'  => ['Initiative & Proactiveness',5],
                'conduct_teamwork'    => ['Teamwork & Collaboration',5],
            ],
            'Technical Competency (/30)' => [
                'tech_application'    => ['Application of Technical Knowledge',10],
                'tech_problem_solving'=> ['Problem-Solving Ability',10],
                'tech_quality'        => ['Quality of Work Output',10],
            ],
            'Communication Skills (/20)' => [
                'comm_written'        => ['Written Communication',10],
                'comm_verbal'         => ['Verbal & Interpersonal Communication',10],
            ],
            'Work Ethic & Attitude (/30)' => [
                'ethic_responsibility'=> ['Responsibility & Reliability',10],
                'ethic_adaptability'  => ['Adaptability & Flexibility',10],
                'ethic_improvement'   => ['Willingness to Learn & Improve',10],
            ],
        ];
        foreach ($sections as $title => $criteria): ?>
        <div class="sr-section">
            <h2>B. <?= $title ?></h2>
            <table><thead><tr><th>Criterion</th><th>Max</th><th>Score</th></tr></thead><tbody>
            <?php foreach ($criteria as $key => [$label, $max]): ?>
                <tr><td><?= $label ?></td><td><?= $max ?></td><td><strong><?= fv_float($reportData,$key) ?></strong></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php endforeach; ?>

        <div class="sr-section">
            <h2>C. Comments &amp; Recommendation</h2>
            <p><strong>General Comments:</strong> <?= nl2br(fv($reportData,'general_comments')) ?></p>
            <p><strong>Strengths:</strong> <?= nl2br(fv($reportData,'strengths')) ?></p>
            <p><strong>Areas for Improvement:</strong> <?= nl2br(fv($reportData,'areas_for_improvement')) ?></p>
            <p><strong>Recommendation:</strong> <strong><?= fv($reportData,'recommendation') ?></strong></p>
        </div>

        <div class="sr-subtotal" style="font-size:16px;text-align:center;padding:14px;">
            <strong>TOTAL SCORE: <?= number_format($reportData['total_score'],1) ?> / 100</strong>
        </div>
        <p class="text-muted" style="font-size:13px;margin-top:12px;">To revise this report, contact the coordinator.</p>

        <?php else: // Editable form ?>
        <form method="POST" id="srForm">
            <input type="hidden" name="student_id" value="<?= $selectedId ?>">

            <div class="sr-section">
                <h2>A. Student &amp; Placement Information</h2>
                <?php
                $stuInfoQ = $db->prepare('
                    SELECT s.first_name, s.last_name, s.student_number, s.programme,
                           c.company_name
                    FROM students s
                    JOIN workplace_assignments wa ON wa.student_id = s.id
                    JOIN companies c ON wa.company_id = c.id
                    WHERE s.id = ?
                ');
                $stuInfoQ->execute([$selectedId]);
                $si = $stuInfoQ->fetch() ?: [];
                ?>
                <div class="info-grid">
                    <div class="info-item"><strong>Student Name</strong><?= htmlspecialchars(($si['first_name']??'').' '.($si['last_name']??'')) ?></div>
                    <div class="info-item"><strong>Student Number</strong><?= htmlspecialchars($si['student_number']??'') ?></div>
                    <div class="info-item"><strong>Programme</strong><?= htmlspecialchars($si['programme']??'') ?></div>
                    <div class="info-item"><strong>Company</strong><?= htmlspecialchars($si['company_name']??$wps['company_name']) ?></div>
                    <div class="info-item"><strong>Supervisor</strong><?= htmlspecialchars($wps['full_name']) ?></div>
                    <div class="info-item">
                        <strong>Attachment Period</strong>
                        <input type="text" name="attachment_period"
                               value="<?= fv($reportData,'attachment_period') ?>"
                               placeholder="e.g. June – December 2025"
                               style="width:100%;padding:5px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;margin-top:4px;">
                    </div>
                </div>
            </div>

            <?php
            $editSections = [
                ['B1','Professional Conduct','conduct',[
                    'conduct_punctuality' => ['Punctuality & Attendance',5],
                    'conduct_appearance'  => ['Professional Appearance',5],
                    'conduct_initiative'  => ['Initiative & Proactiveness',5],
                    'conduct_teamwork'    => ['Teamwork & Collaboration',5],
                ]],
                ['B2','Technical Competency','tech',[
                    'tech_application'    => ['Application of Technical Knowledge',10],
                    'tech_problem_solving'=> ['Problem-Solving Ability',10],
                    'tech_quality'        => ['Quality of Work Output',10],
                ]],
                ['B3','Communication Skills','comm',[
                    'comm_written'        => ['Written Communication',10],
                    'comm_verbal'         => ['Verbal & Interpersonal Communication',10],
                ]],
                ['B4','Work Ethic & Attitude','ethic',[
                    'ethic_responsibility'=> ['Responsibility & Reliability',10],
                    'ethic_adaptability'  => ['Adaptability & Flexibility',10],
                    'ethic_improvement'   => ['Willingness to Learn & Improve',10],
                ]],
            ];
            foreach ($editSections as [$ref, $title, $prefix, $criteria]):
                $sectionMax = array_sum(array_column($criteria,'1'));
            ?>
            <div class="sr-section">
                <h2><?= $ref ?>. <?= $title ?> <small style="font-weight:normal;color:#6b7280;">(Max: <?= $sectionMax ?>)</small></h2>
                <?php foreach ($criteria as $key => [$label, $max]): ?>
                <div class="sr-row">
                    <label><?= $label ?></label>
                    <span class="sr-max">Max: <?= $max ?></span>
                    <input type="number" name="<?= $key ?>" min="0" max="<?= $max ?>" step="0.5"
                           value="<?= fv_float($reportData, $key) ?: '0' ?>"
                           oninput="calcTotal()" required>
                </div>
                <?php endforeach; ?>
                <div class="sr-subtotal" id="sub_<?= $prefix ?>">Section Total: — / <?= $sectionMax ?></div>
            </div>
            <?php endforeach; ?>

            <div class="sr-section">
                <h2>C. Comments &amp; Recommendation</h2>
                <div style="margin-bottom:12px;">
                    <label style="font-size:13px;font-weight:600;">General Comments</label>
                    <textarea name="general_comments" rows="3"
                              style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"
                              placeholder="Overall comments on the student's performance..."><?= fv($reportData,'general_comments') ?></textarea>
                </div>
                <div style="margin-bottom:12px;">
                    <label style="font-size:13px;font-weight:600;">Strengths</label>
                    <textarea name="strengths" rows="3"
                              style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"
                              placeholder="Key strengths observed during attachment..."><?= fv($reportData,'strengths') ?></textarea>
                </div>
                <div style="margin-bottom:12px;">
                    <label style="font-size:13px;font-weight:600;">Areas for Improvement</label>
                    <textarea name="areas_for_improvement" rows="3"
                              style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;"
                              placeholder="Areas the student should work on..."><?= fv($reportData,'areas_for_improvement') ?></textarea>
                </div>
                <div>
                    <label style="font-size:13px;font-weight:600;">Overall Recommendation *</label>
                    <select name="recommendation" required
                            style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;">
                        <option value="">— Select —</option>
                        <?php foreach (['Highly Recommended','Recommended','Recommended with Reservations','Not Recommended'] as $opt): ?>
                            <option value="<?= $opt ?>" <?= ($reportData['recommendation']??'')===$opt?'selected':'' ?>><?= $opt ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- Total display -->
            <div style="background:#1e3a5f;color:#fff;padding:16px 24px;border-radius:8px;text-align:center;margin-bottom:20px;">
                <div style="font-size:13px;opacity:.8;margin-bottom:4px;">TOTAL SCORE</div>
                <div style="font-size:36px;font-weight:bold;" id="grandTotal">0.0</div>
                <div style="opacity:.7;">/ 100</div>
            </div>

            <div style="display:flex;gap:12px;align-items:center;">
                <button type="submit" name="action" value="save_draft" class="btn btn-secondary">💾 Save Draft</button>
                <button type="submit" name="action" value="submit_final" class="btn btn-success"
                        onclick="return confirm('Submit summative report? This will notify the academic supervisor and coordinator. Cannot be changed without coordinator approval.')">
                     Submit Final Report
                </button>
                <small class="text-muted">Once submitted, this report is sent to the academic supervisor and coordinator.</small>
            </div>
        </form>
        <?php endif; ?>
    </div><!-- sr-body -->

<?php endif; ?>
</div><!-- main -->
</div><!-- grid -->

<script>
const sectionGroups = {
    conduct: ['conduct_punctuality','conduct_appearance','conduct_initiative','conduct_teamwork'],
    tech:    ['tech_application','tech_problem_solving','tech_quality'],
    comm:    ['comm_written','comm_verbal'],
    ethic:   ['ethic_responsibility','ethic_adaptability','ethic_improvement']
};
const sectionMax = { conduct:20, tech:30, comm:20, ethic:30 };

function calcTotal() {
    var grand = 0;
    for (var prefix in sectionGroups) {
        var sub = 0;
        sectionGroups[prefix].forEach(function(name) {
            var el = document.querySelector('[name="'+name+'"]');
            if (el) sub += parseFloat(el.value) || 0;
        });
        grand += sub;
        var el = document.getElementById('sub_'+prefix);
        if (el) el.textContent = 'Section Total: ' + sub.toFixed(1) + ' / ' + sectionMax[prefix];
    }
    var gt = document.getElementById('grandTotal');
    if (gt) gt.textContent = grand.toFixed(1);
}
document.addEventListener('DOMContentLoaded', calcTotal);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
