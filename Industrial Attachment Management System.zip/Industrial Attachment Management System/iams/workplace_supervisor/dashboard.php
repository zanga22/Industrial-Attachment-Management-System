<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('workplace_supervisor');

$db    = getDB();
$wpsId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('
    SELECT w.*, u.email, c.company_name
    FROM workplace_supervisors w
    JOIN users u ON w.user_id = u.id
    JOIN companies c ON w.company_id = c.id
    WHERE w.id = ?
');
$profile->execute([$wpsId]);
$wps = $profile->fetch();

$studentCount = $db->prepare('SELECT COUNT(*) FROM workplace_assignments WHERE workplace_supervisor_id = ?');
$studentCount->execute([$wpsId]);
$totalStudents = (int)$studentCount->fetchColumn();

$pageTitle = 'Workplace Supervisor Dashboard';
$assignedStudents = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           wa.assigned_at
    FROM workplace_assignments wa
    JOIN students s ON wa.student_id = s.id
    WHERE wa.workplace_supervisor_id = ?
    ORDER BY wa.assigned_at DESC
    LIMIT 5
');
$assignedStudents->execute([$wpsId]);
$recentStudents = $assignedStudents->fetchAll();

$pageTitle = 'Workplace Supervisor Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<h1 class="page-title">
    Welcome, <?= htmlspecialchars($wps['first_name'] . ' ' . $wps['last_name']) ?>
</h1>
<p class="text-muted" style="margin-bottom:20px;">
    <?= htmlspecialchars($wps['job_title'] ?? 'Workplace Supervisor') ?> &mdash;
    <?= htmlspecialchars($wps['company_name']) ?>
</p>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-box">
        <div class="stat-num"><?= $totalStudents ?></div>
        <div class="stat-label">Students Assigned</div>
    </div>
</div>

<div class="two-col">

    <!-- Profile card -->
    <div class="card">
        <h2>My Profile</h2>
        <table>
            <tr><th>Name</th>       <td><?= htmlspecialchars($wps['first_name'] . ' ' . $wps['last_name']) ?></td></tr>
            <tr><th>Job Title</th>  <td><?= htmlspecialchars($wps['job_title'] ?? '—') ?></td></tr>
            <tr><th>Department</th> <td><?= htmlspecialchars($wps['department'] ?? '—') ?></td></tr>
            <tr><th>Email</th>      <td><?= htmlspecialchars($wps['email']) ?></td></tr>
            <tr><th>Phone</th>      <td><?= htmlspecialchars($wps['phone'] ?? '—') ?></td></tr>
            <tr><th>Company</th>    <td><?= htmlspecialchars($wps['company_name']) ?></td></tr>
        </table>
    </div>

    <!-- Quick actions -->
    <div class="card">
        <h2>Quick Actions</h2>
        <p style="margin-bottom:10px;">
            <a href="<?= BASE_URL ?>/workplace_supervisor/my_students.php" class="btn btn-primary"> View My Students</a>
        </p>
    </div>

</div>

<!-- Recent assigned students -->
<div class="card">
    <h2>Recently Assigned Students</h2>
    <?php if (empty($recentStudents)): ?>
        <p class="text-muted">No students have been assigned to you yet. Your company will assign students once placements are confirmed.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Student</th><th>Programme</th><th>Student No.</th><th>Assigned On</th></tr>
            </thead>
            <tbody>
                <?php foreach ($recentStudents as $st): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($st['programme']) ?></td>
                        <td><?= htmlspecialchars($st['student_number']) ?></td>
                        <td><?= date('d M Y', strtotime($st['assigned_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($totalStudents > 5): ?>
            <div class="mt-10"><a href="<?= BASE_URL ?>/workplace_supervisor/my_students.php" class="text-muted" style="font-size:13px;">View all <?= $totalStudents ?> students →</a></div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
