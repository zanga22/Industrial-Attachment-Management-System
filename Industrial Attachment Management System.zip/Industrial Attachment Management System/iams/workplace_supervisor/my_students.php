<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('workplace_supervisor');

$db    = getDB();
$wpsId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT w.company_id, c.company_name FROM workplace_supervisors w JOIN companies c ON w.company_id = c.id WHERE w.id = ?');
$profile->execute([$wpsId]);
$wps = $profile->fetch();

$students = $db->prepare('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           s.cv_path, s.phone,
           u.email,
           wa.assigned_at
    FROM workplace_assignments wa
    JOIN students s ON wa.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE wa.workplace_supervisor_id = ?
    ORDER BY s.last_name, s.first_name
');
$students->execute([$wpsId]);
$assignedStudents = $students->fetchAll();

$pageTitle = 'My Students';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">My Students</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<?php if (empty($assignedStudents)): ?>
    <div class="card">
        <div class="alert alert-info">
            No students have been assigned to you yet. Your company contact will assign students through the company portal.
        </div>
    </div>
<?php else: ?>
    <p class="text-muted" style="margin-bottom:12px;"><?= count($assignedStudents) ?> student<?= count($assignedStudents) != 1 ? 's' : '' ?> assigned to you at <?= htmlspecialchars($wps['company_name']) ?></p>

    <?php foreach ($assignedStudents as $st): ?>
    <div class="card" style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
            <div>
                <h3 style="font-size:17px;margin-bottom:6px;">
                    <?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?>
                </h3>
                <table style="width:auto;font-size:13px;">
                    <tr><th style="padding:4px 10px 4px 0;background:none;border:none;color:#555;">Student No.</th><td style="border:none;padding:4px 0;"><?= htmlspecialchars($st['student_number']) ?></td></tr>
                    <tr><th style="padding:4px 10px 4px 0;background:none;border:none;color:#555;">Programme</th>  <td style="border:none;padding:4px 0;"><?= htmlspecialchars($st['programme']) ?></td></tr>
                    <tr><th style="padding:4px 10px 4px 0;background:none;border:none;color:#555;">Email</th>      <td style="border:none;padding:4px 0;"><?= htmlspecialchars($st['email']) ?></td></tr>
                    <tr><th style="padding:4px 10px 4px 0;background:none;border:none;color:#555;">Phone</th>      <td style="border:none;padding:4px 0;"><?= htmlspecialchars($st['phone'] ?? '—') ?></td></tr>
                    <tr><th style="padding:4px 10px 4px 0;background:none;border:none;color:#555;">Assigned</th>   <td style="border:none;padding:4px 0;"><?= date('d M Y', strtotime($st['assigned_at'])) ?></td></tr>
                </table>
            </div>
            <div style="text-align:right;">
                <?php if ($st['cv_path']): ?>
                    <div style="margin-bottom:6px;">
                        <a href="<?= BASE_URL ?>/file.php?type=cv&f=<?= urlencode(basename($st['cv_path'])) ?>"
                           target="_blank" class="btn btn-secondary btn-sm">View CV</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
