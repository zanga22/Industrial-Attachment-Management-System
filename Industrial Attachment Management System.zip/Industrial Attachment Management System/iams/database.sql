CREATE DATABASE IF NOT EXISTS iams_db;
USE iams_db;


CREATE TABLE IF NOT EXISTS users (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email        VARCHAR(255) NOT NULL UNIQUE,
    password     VARCHAR(255) NOT NULL,
    role         ENUM('student','company','lecturer','admin','coordinator','workplace_supervisor') NOT NULL,
    is_active    TINYINT(1) NOT NULL DEFAULT 1,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS grading_scale (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    letter       VARCHAR(2) NOT NULL,
    min_score    DECIMAL(5,2) NOT NULL,
    max_score    DECIMAL(5,2) NOT NULL,
    description  VARCHAR(100) DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL UNIQUE,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    student_number  VARCHAR(50)  NOT NULL UNIQUE,
    programme       VARCHAR(150) NOT NULL,
    phone           VARCHAR(30)  DEFAULT NULL,
    cv_path         VARCHAR(500) DEFAULT NULL,
    transcript_path VARCHAR(500) DEFAULT NULL,
    placement_locked TINYINT(1) NOT NULL DEFAULT 0,
    placement_confirmed_seen TINYINT(1) NOT NULL DEFAULT 0,
    is_approved     TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS companies (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id          INT UNSIGNED NOT NULL UNIQUE,
    company_name     VARCHAR(200) NOT NULL,
    sector           VARCHAR(150) NOT NULL,
    contact_person   VARCHAR(150) NOT NULL,
    phone            VARCHAR(30)  DEFAULT NULL,
    address          TEXT         DEFAULT NULL,
    capacity         INT UNSIGNED NOT NULL DEFAULT 0,
    is_approved      TINYINT(1)   NOT NULL DEFAULT 0,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_company_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS coordinators (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL UNIQUE,
    first_name   VARCHAR(100) NOT NULL,
    last_name    VARCHAR(100) NOT NULL,
    department   VARCHAR(150) NOT NULL,
    phone        VARCHAR(30)  DEFAULT NULL,
    is_approved  TINYINT(1)   NOT NULL DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coordinator_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS lecturers (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL UNIQUE,
    first_name   VARCHAR(100) NOT NULL,
    last_name    VARCHAR(100) NOT NULL,
    department   VARCHAR(150) NOT NULL,
    phone        VARCHAR(30)  DEFAULT NULL,
    is_approved  TINYINT(1)   NOT NULL DEFAULT 0,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_lecturer_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS workplace_supervisors (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL UNIQUE,
    company_id   INT UNSIGNED NOT NULL,
    first_name   VARCHAR(100) NOT NULL,
    last_name    VARCHAR(100) NOT NULL,
    job_title    VARCHAR(150) DEFAULT NULL,
    phone        VARCHAR(30)  DEFAULT NULL,
    department   VARCHAR(150) DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ws_user    FOREIGN KEY (user_id)    REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_ws_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS applications (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id        INT UNSIGNED NOT NULL,
    company_id        INT UNSIGNED NOT NULL,
    status            ENUM('pending','offered','accepted','rejected','withdrawn') NOT NULL DEFAULT 'pending',
    cover_note        TEXT DEFAULT NULL,
    date_applied      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at       DATETIME DEFAULT NULL,
    offer_letter_path VARCHAR(500) DEFAULT NULL,
    CONSTRAINT fk_app_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_app_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    UNIQUE KEY uq_student_company (student_id, company_id)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS supervisor_assignments (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id   INT UNSIGNED NOT NULL UNIQUE,
    lecturer_id  INT UNSIGNED NOT NULL,
    assigned_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_assign_student  FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_assign_lecturer FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS company_requests (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id      INT UNSIGNED NOT NULL,
    company_name    VARCHAR(200) NOT NULL,
    company_address TEXT DEFAULT NULL,
    reason          TEXT DEFAULT NULL,
    status          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    reviewed_by     INT UNSIGNED DEFAULT NULL,
    reviewer_note   TEXT DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_creq_student    FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_creq_reviewer   FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS vacancies (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id       INT UNSIGNED NOT NULL,
    position_title   VARCHAR(200) NOT NULL,
    description      TEXT DEFAULT NULL,
    requirements     TEXT DEFAULT NULL,
    num_positions    INT UNSIGNED NOT NULL DEFAULT 1,
    deadline         DATE DEFAULT NULL,
    is_active        TINYINT(1) NOT NULL DEFAULT 1,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vacancy_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS notifications (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    message    TEXT NOT NULL,
    link       VARCHAR(500) DEFAULT NULL,
    is_read    TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS site_visits (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id      INT UNSIGNED NOT NULL,
    lecturer_id     INT UNSIGNED NOT NULL,
    visit_number    ENUM('1','2') NOT NULL,
    visit_date      DATETIME NOT NULL,
    status          ENUM('scheduled','completed') NOT NULL DEFAULT 'scheduled',
    comments        TEXT DEFAULT NULL,
    scheduled_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at    DATETIME DEFAULT NULL,
    CONSTRAINT fk_sv_student  FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_sv_lecturer FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE,
    UNIQUE KEY uq_student_visit (student_id, visit_number)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS workplace_assignments (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id              INT UNSIGNED NOT NULL UNIQUE,
    workplace_supervisor_id INT UNSIGNED NOT NULL,
    company_id              INT UNSIGNED NOT NULL,
    assigned_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_wa_student  FOREIGN KEY (student_id)              REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_wa_wps      FOREIGN KEY (workplace_supervisor_id) REFERENCES workplace_supervisors(id) ON DELETE CASCADE,
    CONSTRAINT fk_wa_company  FOREIGN KEY (company_id)              REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS reports (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id           INT UNSIGNED NOT NULL,
    lecturer_id          INT UNSIGNED DEFAULT NULL,
    file_path            VARCHAR(500) DEFAULT NULL,
    report_type          ENUM('logbook','progress','final') NOT NULL DEFAULT 'logbook',
    feedback             TEXT DEFAULT NULL,
    is_lecturer_report   TINYINT(1) NOT NULL DEFAULT 0,
    overall_grade        ENUM('Excellent','Good','Satisfactory','Needs Improvement','Unsatisfactory') DEFAULT NULL,
    conduct              TEXT DEFAULT NULL,
    technical_skills     TEXT DEFAULT NULL,
    communication_skills TEXT DEFAULT NULL,
    recommendations      TEXT DEFAULT NULL,
    uploaded_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_report_student  FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_report_lecturer FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS company_progress_reports (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id              INT UNSIGNED NOT NULL,
    company_id              INT UNSIGNED NOT NULL,
    workplace_supervisor_id INT UNSIGNED NOT NULL,
    submitted_by_wps        INT UNSIGNED DEFAULT NULL,
    period                  VARCHAR(100) NOT NULL,
    duties_performed        TEXT DEFAULT NULL,
    performance             ENUM('Excellent','Good','Satisfactory','Poor') DEFAULT NULL,
    attendance              ENUM('Excellent','Good','Fair','Poor') DEFAULT NULL,
    communication           ENUM('Excellent','Good','Fair','Poor') DEFAULT NULL,
    overall_rating          ENUM('Excellent','Good','Satisfactory','Unsatisfactory') DEFAULT NULL,
    comments                TEXT DEFAULT NULL,
    submitted_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cpr_student    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_cpr_company    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_cpr_wps        FOREIGN KEY (workplace_supervisor_id) REFERENCES workplace_supervisors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grading_rubric (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    grader_type  ENUM('workplace','lecturer') NOT NULL,
    criterion    VARCHAR(200) NOT NULL,
    max_score    INT UNSIGNED NOT NULL DEFAULT 10,
    description  TEXT DEFAULT NULL,
    sort_order   INT UNSIGNED NOT NULL DEFAULT 0,
    is_active    TINYINT(1) NOT NULL DEFAULT 1,
    created_by   INT UNSIGNED DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rubric_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grade_entries (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id     INT UNSIGNED NOT NULL,
    rubric_id      INT UNSIGNED NOT NULL,
    grader_type    ENUM('workplace','lecturer') NOT NULL,
    grader_id      INT UNSIGNED NOT NULL,
    score          DECIMAL(5,2) NOT NULL DEFAULT 0,
    comment        TEXT DEFAULT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_grade (student_id, rubric_id, grader_type, grader_id),
    CONSTRAINT fk_ge_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_ge_rubric  FOREIGN KEY (rubric_id)  REFERENCES grading_rubric(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS student_grades (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id           INT UNSIGNED NOT NULL,
    grader_type          ENUM('workplace','lecturer') NOT NULL,
    grader_id            INT UNSIGNED NOT NULL,
    total_score          DECIMAL(5,2) NOT NULL DEFAULT 0,
    max_possible         INT UNSIGNED NOT NULL DEFAULT 50,
    is_draft             TINYINT(1) NOT NULL DEFAULT 1,
    submitted_at         DATETIME DEFAULT NULL,
    resubmit_requested   TINYINT(1) NOT NULL DEFAULT 0,
    resubmit_comment     TEXT DEFAULT NULL,
    resubmit_count       INT UNSIGNED NOT NULL DEFAULT 0,
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_grader (student_id, grader_type, grader_id),
    CONSTRAINT fk_sg_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS wps_summative_reports (
    id                          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id                  INT UNSIGNED NOT NULL UNIQUE,
    workplace_supervisor_id     INT UNSIGNED NOT NULL,
    company_id                  INT UNSIGNED NOT NULL,
    student_name                VARCHAR(200) DEFAULT NULL,
    student_number              VARCHAR(50)  DEFAULT NULL,
    programme                   VARCHAR(200) DEFAULT NULL,
    company_name                VARCHAR(200) DEFAULT NULL,
    supervisor_name             VARCHAR(200) DEFAULT NULL,
    supervisor_title            VARCHAR(150) DEFAULT NULL,
    department                  VARCHAR(150) DEFAULT NULL,
    attachment_period           VARCHAR(100) DEFAULT NULL,
    conduct_punctuality         DECIMAL(5,2) DEFAULT NULL,
    conduct_appearance          DECIMAL(5,2) DEFAULT NULL,
    conduct_initiative          DECIMAL(5,2) DEFAULT NULL,
    conduct_teamwork            DECIMAL(5,2) DEFAULT NULL,
    tech_application            DECIMAL(5,2) DEFAULT NULL,
    tech_problem_solving        DECIMAL(5,2) DEFAULT NULL,
    tech_quality                DECIMAL(5,2) DEFAULT NULL,
    comm_written                DECIMAL(5,2) DEFAULT NULL,
    comm_verbal                 DECIMAL(5,2) DEFAULT NULL,
    ethic_responsibility        DECIMAL(5,2) DEFAULT NULL,
    ethic_adaptability          DECIMAL(5,2) DEFAULT NULL,
    ethic_improvement           DECIMAL(5,2) DEFAULT NULL,
    general_comments            TEXT DEFAULT NULL,
    strengths                   TEXT DEFAULT NULL,
    areas_for_improvement       TEXT DEFAULT NULL,
    recommendation              ENUM('Highly Recommended','Recommended','Recommended with Reservations','Not Recommended') DEFAULT NULL,
    total_score                 DECIMAL(5,2) DEFAULT NULL,
    status                      ENUM('draft','submitted') NOT NULL DEFAULT 'draft',
    submitted_at                DATETIME DEFAULT NULL,
    created_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_wsr_student  FOREIGN KEY (student_id)              REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_wsr_wps      FOREIGN KEY (workplace_supervisor_id) REFERENCES workplace_supervisors(id) ON DELETE CASCADE,
    CONSTRAINT fk_wsr_company  FOREIGN KEY (company_id)              REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS academic_summative_reports (
    id                          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id                  INT UNSIGNED NOT NULL UNIQUE,
    lecturer_id                 INT UNSIGNED NOT NULL,
    student_name                VARCHAR(200) DEFAULT NULL,
    student_number              VARCHAR(50)  DEFAULT NULL,
    programme                   VARCHAR(200) DEFAULT NULL,
    company_name                VARCHAR(200) DEFAULT NULL,
    supervisor_name             VARCHAR(200) DEFAULT NULL,
    attachment_period           VARCHAR(100) DEFAULT NULL,
    logbook_regularity          DECIMAL(5,2) DEFAULT NULL,
    logbook_detail              DECIMAL(5,2) DEFAULT NULL,
    logbook_reflection          DECIMAL(5,2) DEFAULT NULL,
    logbook_presentation        DECIMAL(5,2) DEFAULT NULL,
    visit_engagement            DECIMAL(5,2) DEFAULT NULL,
    visit_progress              DECIMAL(5,2) DEFAULT NULL,
    report_structure            DECIMAL(5,2) DEFAULT NULL,
    report_content              DECIMAL(5,2) DEFAULT NULL,
    report_technical            DECIMAL(5,2) DEFAULT NULL,
    report_analysis             DECIMAL(5,2) DEFAULT NULL,
    report_presentation         DECIMAL(5,2) DEFAULT NULL,
    general_comments            TEXT DEFAULT NULL,
    academic_observations       TEXT DEFAULT NULL,
    recommendation              ENUM('Pass','Pass with Distinction','Fail','Deferred') DEFAULT NULL,
    logbook_total               DECIMAL(5,2) DEFAULT NULL,
    visit_total                 DECIMAL(5,2) DEFAULT NULL,
    report_total                DECIMAL(5,2) DEFAULT NULL,
    total_score                 DECIMAL(5,2) DEFAULT NULL,
    status                      ENUM('draft','submitted') NOT NULL DEFAULT 'draft',
    submitted_at                DATETIME DEFAULT NULL,
    created_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_asr_student  FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_asr_lecturer FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS student_report_grades (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id          INT UNSIGNED NOT NULL UNIQUE,
    lecturer_id         INT UNSIGNED NOT NULL,
    report_file_path    VARCHAR(500) DEFAULT NULL,
    structure_score     DECIMAL(5,2) DEFAULT NULL,
    content_score       DECIMAL(5,2) DEFAULT NULL,
    technical_score     DECIMAL(5,2) DEFAULT NULL,
    analysis_score      DECIMAL(5,2) DEFAULT NULL,
    presentation_score  DECIMAL(5,2) DEFAULT NULL,
    total_score         DECIMAL(5,2) DEFAULT NULL,
    feedback            TEXT DEFAULT NULL,
    status              ENUM('draft','submitted') NOT NULL DEFAULT 'draft',
    submitted_at        DATETIME DEFAULT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_srg_student  FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_srg_lecturer FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS final_grades (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id              INT UNSIGNED NOT NULL UNIQUE,
    workplace_score         DECIMAL(5,2) DEFAULT NULL,
    lecturer_score          DECIMAL(5,2) DEFAULT NULL,
    total_score             DECIMAL(5,2) DEFAULT NULL,
    letter_grade            VARCHAR(2)   DEFAULT NULL,
    status                  ENUM('pending','partial','submitted','flagged','approved','published') NOT NULL DEFAULT 'pending',
    discrepancy_flag        TINYINT(1) NOT NULL DEFAULT 0,
    discrepancy_threshold   INT UNSIGNED NOT NULL DEFAULT 15,
    coordinator_note        TEXT DEFAULT NULL,
    override_grade          VARCHAR(2) DEFAULT NULL,
    override_justification  TEXT DEFAULT NULL,
    override_by             INT UNSIGNED DEFAULT NULL,
    approved_by             INT UNSIGNED DEFAULT NULL,
    approved_at             DATETIME DEFAULT NULL,
    published_at            DATETIME DEFAULT NULL,
    last_reminder_sent      DATETIME DEFAULT NULL,
    wps_report_score        DECIMAL(5,2) DEFAULT NULL,
    academic_report_score   DECIMAL(5,2) DEFAULT NULL,
    student_report_score    DECIMAL(5,2) DEFAULT NULL,
    created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fg_student      FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_fg_override_by  FOREIGN KEY (override_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_fg_approved_by  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grade_audit_log (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id  INT UNSIGNED NOT NULL,
    action      VARCHAR(200) NOT NULL,
    performed_by INT UNSIGNED NOT NULL,
    details     TEXT DEFAULT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_gal_student FOREIGN KEY (student_id)   REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_gal_user    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Admin user
INSERT IGNORE INTO users (email, password, role, is_active) VALUES
('admin@iams.ub.bw', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1);

INSERT IGNORE INTO grading_scale (letter, min_score, max_score, description) VALUES
('A', 80, 100, 'Distinction'),
('B', 70, 79.99, 'Credit'),
('C', 60, 69.99, 'Pass'),
('D', 50, 59.99, 'Borderline'),
('F', 0, 49.99, 'Fail');

INSERT IGNORE INTO grading_rubric (grader_type, criterion, max_score, description, sort_order) VALUES
('workplace', 'Punctuality & Attendance',   10, 'Consistent attendance and timekeeping',            1),
('workplace', 'Task Completion',            10, 'Ability to complete assigned tasks to standard',   2),
('workplace', 'Initiative',                 10, 'Proactiveness and self-motivation',                3),
('workplace', 'Teamwork & Collaboration',   10, 'Working effectively with colleagues',              4),
('workplace', 'Professional Conduct',       10, 'Attitude, dress code, and overall professionalism',5);

INSERT IGNORE INTO grading_rubric (grader_type, criterion, max_score, description, sort_order) VALUES
('lecturer', 'Logbook Completeness',     15, 'Regular, thorough, and accurate logbook entries',  1),
('lecturer', 'Final Report Quality',     20, 'Structure, depth, and quality of the final report',2),
('lecturer', 'Technical Understanding',  15, 'Demonstrated grasp of technical concepts',         3);

