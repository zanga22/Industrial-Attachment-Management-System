<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');

$db    = getDB();
$coordId = (int)$_SESSION['profile_id'];

$profile = $db->prepare('SELECT c.*, u.email FROM coordinators c JOIN users u ON c.user_id = u.id WHERE c.id = ?');
$profile->execute([$coordId]);
$coord = $profile->fetch();

$counts = $db->query('
    SELECT
        (SELECT COUNT(*) FROM students) AS students,
        (SELECT COUNT(*) FROM supervisor_assignments) AS assigned,
        (SELECT COUNT(*) FROM company_requests WHERE status = "pending") AS pending_requests,
        (SELECT COUNT(*) FROM applications WHERE status = "accepted") AS placements
')->fetch();

$approvalCheck = $db->prepare('SELECT is_approved FROM coordinators WHERE id = ?');
$approvalCheck->execute([$coordId]);
$coordApproved = (bool)($approvalCheck->fetchColumn());
$_SESSION['is_approved'] = $coordApproved;

$pageTitle = 'Coordinator Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (!$coordApproved): ?>
<div class="alert alert-info" style="margin-bottom:20px;">
    ⏳ <strong>Account Pending Approval</strong> — Your coordinator account is awaiting admin approval.
    You will be able to manage students and access all features once approved.
    Please check back later or contact the administrator.
</div>
<?php endif; ?>

<h1 class="page-title">
    Welcome, <?= htmlspecialchars($coord['first_name'] . ' ' . $coord['last_name']) ?>
    <span style="font-size:14px;color:#666;font-weight:normal;"> — Coordinator</span>
</h1>

<?php if (!$coordApproved): ?>
<div class="card">
    <h2>My Profile</h2>
    <table>
        <tr><th>Department</th><td><?= htmlspecialchars($coord['department']) ?></td></tr>
        <tr><th>Email</th>     <td><?= htmlspecialchars($coord['email']) ?></td></tr>
        <tr><th>Phone</th>     <td><?= htmlspecialchars($coord['phone'] ?? '—') ?></td></tr>
    </table>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<?php exit; ?>
<?php endif; ?>

<div class="stats-grid">
    <div class="stat-box"><div class="stat-num"><?= $counts['students'] ?></div><div class="stat-label">Total Students</div></div>
    <div class="stat-box"><div class="stat-num"><?= $counts['assigned'] ?></div><div class="stat-label">Assigned Supervisors</div></div>
    <div class="stat-box"><div class="stat-num"><?= $counts['placements'] ?></div><div class="stat-label">Active Placements</div></div>
    <div class="stat-box">
        <div class="stat-num"><?= $counts['pending_requests'] ?></div>
        <div class="stat-label">Pending Company Requests</div>
    </div>
</div>

<div class="two-col">
    <div class="card">
        <h2>My Profile</h2>
        <table>
            <tr><th>Department</th><td><?= htmlspecialchars($coord['department']) ?></td></tr>
            <tr><th>Email</th>     <td><?= htmlspecialchars($coord['email']) ?></td></tr>
            <tr><th>Phone</th>     <td><?= htmlspecialchars($coord['phone'] ?? '—') ?></td></tr>
        </table>
    </div>
    <div class="card">
        <h2>Quick Actions</h2>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <a href="<?= BASE_URL ?>/coordinator/assign.php" class="btn btn-primary">Assign Supervisors</a>
            <a href="<?= BASE_URL ?>/coordinator/company_requests.php" class="btn btn-secondary">Review Company Requests</a>
            <a href="<?= BASE_URL ?>/coordinator/students.php" class="btn btn-secondary">View All Students</a>
            <a href="<?= BASE_URL ?>/coordinator/vacancies.php" class="btn btn-secondary">View Vacancies</a>
        </div>
    </div>
</div>

<?php

$recentReq = $db->query('
    SELECT cr.id, cr.company_name, cr.status, cr.created_at,
           s.first_name, s.last_name, s.student_number
    FROM company_requests cr
    JOIN students s ON cr.student_id = s.id
    ORDER BY cr.created_at DESC LIMIT 5
')->fetchAll();
?>
<div class="card">
    <h2>Recent Company Requests</h2>
    <?php if (empty($recentReq)): ?>
        <p class="text-muted">No company requests yet.</p>
    <?php else: ?>
        <table>
            <thead><tr><th>Student</th><th>Suggested Company</th><th>Date</th><th>Status</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($recentReq as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?> <small class="text-muted">(<?= htmlspecialchars($r['student_number']) ?>)</small></td>
                        <td><?= htmlspecialchars($r['company_name']) ?></td>
                        <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
                        <td><span class="badge badge-<?= $r['status'] === 'approved' ? 'approved' : ($r['status'] === 'rejected' ? 'rejected' : 'pending') ?>"><?= ucfirst($r['status']) ?></span></td>
                        <td><a href="<?= BASE_URL ?>/coordinator/company_requests.php" class="btn btn-secondary btn-sm">Review</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
