<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');

$db = getDB();

$rows = $db->query('
    SELECT s.id AS student_id, s.first_name, s.last_name, s.student_number, s.programme,
           c.company_name, l.first_name AS lec_first, l.last_name AS lec_last,
           wsr.total_score AS wps_score, wsr.status AS wps_status,
           asr.total_score AS acad_score, asr.status AS acad_status,
           srg.total_score AS rep_score, srg.status AS rep_status,
           fg.total_score, fg.letter_grade, fg.override_grade,
           fg.status, fg.published_at
    FROM students s
    LEFT JOIN workplace_assignments wa ON wa.student_id=s.id
    LEFT JOIN companies c ON wa.company_id=c.id
    LEFT JOIN supervisor_assignments sa ON sa.student_id=s.id
    LEFT JOIN lecturers l ON sa.lecturer_id=l.id
    LEFT JOIN wps_summative_reports wsr ON wsr.student_id=s.id
    LEFT JOIN academic_summative_reports asr ON asr.student_id=s.id
    LEFT JOIN student_report_grades srg ON srg.student_id=s.id
    LEFT JOIN final_grades fg ON fg.student_id=s.id
    ORDER BY s.last_name, s.first_name
')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>IAMS Grades — <?= date('d M Y') ?></title>
<style>
  @page { size: A4 landscape; margin: 15mm 12mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, sans-serif; font-size: 11px; color: #111; margin: 0; }
  .page-header { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; border-bottom: 2px solid #1e3a5f; padding-bottom: 10px; }
  .page-header img { height: 48px; }
  .page-header h1 { font-size: 15px; color: #1e3a5f; margin: 0 0 3px 0; }
  .page-header p  { font-size: 11px; color: #555; margin: 0; }
  table { width: 100%; border-collapse: collapse; }
  thead tr { background: #1e3a5f; color: #fff; }
  thead th { padding: 7px 6px; text-align: left; font-size: 10px; white-space: nowrap; }
  tbody tr:nth-child(even) { background: #f8fafc; }
  tbody td { padding: 6px 6px; border-bottom: 1px solid #e5e7eb; vertical-align: middle; }
  .grade-cell { font-size: 15px; font-weight: bold; text-align: center; }
  .pend { color: #92400e; }
  .sub  { color: #1e40af; }
  .pub  { color: #166534; }
  .formula { font-size: 10px; color: #555; margin-bottom: 10px; }
  .footer { margin-top: 14px; font-size: 10px; color: #888; text-align: right; }
  .no-print { }
  @media print { .no-print { display: none !important; } }
  .btn-print { background: #1e3a5f; color: #fff; border: none; padding: 8px 20px; border-radius: 4px; cursor: pointer; font-size: 13px; margin-bottom: 14px; }
</style>
</head>
<body>

<button class="btn-print no-print" onclick="downloadPDF()">⬇ Download PDF</button>
<button class="btn-print no-print" onclick="window.close()" style="background:#6b7280;margin-left:8px;">✕ Close</button>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function downloadPDF() {
    const btn = document.querySelectorAll('.no-print');
    btn.forEach(b => b.style.display = 'none');
    const { jsPDF } = window.jspdf;
    html2canvas(document.body, { scale: 2, useCORS: true }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        const imgW = pageW;
        const imgH = (canvas.height * imgW) / canvas.width;
        let y = 0;
        while (y < imgH) {
            if (y > 0) pdf.addPage();
            pdf.addImage(imgData, 'PNG', 0, -y, imgW, imgH);
            y += pageH;
        }
        pdf.save('IAMS_Grades_<?= date('Y-m-d') ?>.pdf');
        btn.forEach(b => b.style.display = '');
    });
}
<?php if (!empty($_GET['download'])): ?>
window.addEventListener('load', function() { downloadPDF(); });
<?php endif; ?>
</script>

<div class="page-header">
  <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="UB">
  <div>
    <h1>University of Botswana — Industrial Attachment Grades</h1>
    <p>Department of Computer Science &amp; Information Systems &nbsp;|&nbsp; Generated: <?= date('d F Y, H:i') ?></p>
  </div>
</div>

<p class="formula">
  <strong>Grading Formula:</strong>
  WPS Summative Report × 30% &nbsp;+&nbsp; Academic Supervisor Summative Report × 20% &nbsp;+&nbsp; Student Final Report × 50% = Weighted Total / 100
</p>

<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Student Name</th>
      <th>Student No.</th>
      <th>Programme</th>
      <th>Company</th>
      <th>Academic Supervisor</th>
      <th>WPS Summative<br>/100 (×30%)</th>
      <th>Academic Summative<br>/100 (×20%)</th>
      <th>Student Report<br>/100 (×50%)</th>
      <th>Weighted Total<br>/100</th>
      <th>Grade</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($rows as $i => $r):
    $wS = $r['wps_score']  !== null ? (float)$r['wps_score']  : null;
    $aS = $r['acad_score'] !== null ? (float)$r['acad_score'] : null;
    $rS = $r['rep_score']  !== null ? (float)$r['rep_score']  : null;
    $wt = ($wS!==null && $aS!==null && $rS!==null) ? round(($wS*.3)+($aS*.2)+($rS*.5), 2) : null;
    $grade = $r['override_grade'] ?: ($r['letter_grade'] ?? '—');
    $status = $r['status'] ?? 'pending';
    $statusClass = $status === 'published' ? 'pub' : ($status === 'submitted' || $status === 'approved' ? 'sub' : 'pend');
  ?>
  <tr>
    <td><?= $i+1 ?></td>
    <td><strong><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?></strong></td>
    <td><?= htmlspecialchars($r['student_number']) ?></td>
    <td><?= htmlspecialchars($r['programme']) ?></td>
    <td><?= htmlspecialchars($r['company_name'] ?? '—') ?></td>
    <td><?= htmlspecialchars(($r['lec_first']??'').' '.($r['lec_last']??'')) ?></td>
    <td style="text-align:center;">
      <?php if ($wS !== null): ?>
        <strong><?= number_format($wS,1) ?></strong>
        <br><small style="color:#6b7280;">→ <?= number_format($wS*.3,1) ?></small>
      <?php else: ?><span class="pend"><?= $r['wps_status']==='draft'?'Draft':'—' ?></span><?php endif; ?>
    </td>
    <td style="text-align:center;">
      <?php if ($aS !== null): ?>
        <strong><?= number_format($aS,1) ?></strong>
        <br><small style="color:#6b7280;">→ <?= number_format($aS*.2,1) ?></small>
      <?php else: ?><span class="pend"><?= $r['acad_status']==='draft'?'Draft':'—' ?></span><?php endif; ?>
    </td>
    <td style="text-align:center;">
      <?php if ($rS !== null): ?>
        <strong><?= number_format($rS,1) ?></strong>
        <br><small style="color:#6b7280;">→ <?= number_format($rS*.5,1) ?></small>
      <?php else: ?><span class="pend"><?= $r['rep_status']==='draft'?'Draft':'—' ?></span><?php endif; ?>
    </td>
    <td style="text-align:center;font-weight:bold;">
      <?= $wt !== null ? number_format($wt,2) : '—' ?>
    </td>
    <td class="grade-cell"><?= htmlspecialchars($grade) ?></td>
    <td class="<?= $statusClass ?>"><?= ucfirst($status) ?></td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<div class="footer">
  IAMS — University of Botswana &nbsp;|&nbsp; Confidential — For Academic Use Only &nbsp;|&nbsp; Page 1
</div>

</body>
</html>
