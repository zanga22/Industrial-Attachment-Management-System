<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

$students = $db->query('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme,
           u.email, s.phone,
           c.company_name, c.sector, c.location,
           a.date_applied AS offer_date,
           wa.assigned_at AS placement_date,
           CONCAT(l.first_name, " ", l.last_name) AS supervisor_name,
           CONCAT(ws.first_name, " ", ws.last_name) AS wps_name,
           ws.job_title AS wps_title
    FROM students s
    JOIN users u ON s.user_id = u.id
    JOIN applications a ON a.student_id = s.id AND a.status = "accepted"
    JOIN companies c ON a.company_id = c.id
    LEFT JOIN workplace_assignments wa ON wa.student_id = s.id
    LEFT JOIN supervisor_assignments sa ON sa.student_id = s.id
    LEFT JOIN lecturers l ON sa.lecturer_id = l.id
    LEFT JOIN workplace_supervisors ws ON wa.workplace_supervisor_id = ws.id
    WHERE s.placement_locked = 1
    ORDER BY s.last_name, s.first_name
')->fetchAll();

if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="active_placements_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['#', 'Student Name', 'Student Number', 'Programme', 'Email', 'Phone',
                   'Company', 'Sector', 'Location', 'Placement Date',
                   'Academic Supervisor', 'Workplace Supervisor', 'WPS Job Title']);
    foreach ($students as $i => $st) {
        fputcsv($out, [
            $i + 1,
            $st['first_name'] . ' ' . $st['last_name'],
            $st['student_number'],
            $st['programme'],
            $st['email'],
            $st['phone'] ?? '—',
            $st['company_name'],
            $st['sector'] ?? '—',
            $st['location'] ?? '—',
            $st['placement_date'] ? date('d M Y', strtotime($st['placement_date'])) : '—',
            $st['supervisor_name'] ?? '—',
            $st['wps_name'] ?? '—',
            $st['wps_title'] ?? '—',
        ]);
    }
    fclose($out);
    exit;
}

if (isset($_GET['export']) && $_GET['export'] === 'pdf') {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Active Placements — <?= date('d M Y') ?></title>
<style>
  @page { size: A4 landscape; margin: 12mm 10mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, sans-serif; font-size: 10px; color: #111; margin: 0; }
  .page-header { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; border-bottom: 2px solid #1e3a5f; padding-bottom: 8px; }
  .page-header img { height: 44px; }
  .page-header h1 { font-size: 14px; color: #1e3a5f; margin: 0 0 2px 0; }
  .page-header p  { font-size: 10px; color: #555; margin: 0; }
  table { width: 100%; border-collapse: collapse; }
  thead tr { background: #1e3a5f; color: #fff; }
  thead th { padding: 6px 5px; text-align: left; font-size: 9px; white-space: nowrap; }
  tbody tr:nth-child(even) { background: #f8fafc; }
  tbody td { padding: 5px 5px; border-bottom: 1px solid #e5e7eb; vertical-align: middle; }
  .footer { margin-top: 12px; font-size: 9px; color: #888; text-align: right; }
  .btn-print { background: #1e3a5f; color: #fff; border: none; padding: 7px 18px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-bottom: 12px; }
  @media print { .no-print { display: none !important; } }
</style>
</head>
<body>
<button class="btn-print no-print" onclick="downloadPDF()">⬇ Download PDF</button>
<button class="btn-print no-print" onclick="window.close()" style="background:#6b7280;margin-left:8px;">✕ Close</button>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function downloadPDF() {
    const btn = document.querySelectorAll('.no-print');
    btn.forEach(b => b.style.display = 'none');
    const { jsPDF } = window.jspdf;
    html2canvas(document.body, { scale: 2, useCORS: true }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        const imgW = pageW;
        const imgH = (canvas.height * imgW) / canvas.width;
        let y = 0;
        while (y < imgH) {
            if (y > 0) pdf.addPage();
            pdf.addImage(imgData, 'PNG', 0, -y, imgW, imgH);
            y += pageH;
        }
        pdf.save('Active_Placements_<?= date('Y-m-d') ?>.pdf');
        btn.forEach(b => b.style.display = '');
    });
}
<?php if (!empty($_GET['download'])): ?>
window.addEventListener('load', function() { downloadPDF(); });
<?php endif; ?>
</script>
<div class="page-header">
  <img src="<?= BASE_URL ?>/assets/ub_logo.png" alt="UB">
  <div>
    <h1>University of Botswana — Active Placement Students</h1>
    <p>Department of Computer Science &amp; Information Systems &nbsp;|&nbsp; Generated: <?= date('d F Y, H:i') ?> &nbsp;|&nbsp; Total: <?= count($students) ?> student(s)</p>
  </div>
</div>
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Student Name</th>
      <th>Student No.</th>
      <th>Programme</th>
      <th>Email</th>
      <th>Company</th>
      <th>Sector</th>
      <th>Location</th>
      <th>Placement Date</th>
      <th>Academic Supervisor</th>
      <th>Workplace Supervisor</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($students as $i => $st): ?>
  <tr>
    <td><?= $i + 1 ?></td>
    <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
    <td><?= htmlspecialchars($st['student_number']) ?></td>
    <td><?= htmlspecialchars($st['programme']) ?></td>
    <td><?= htmlspecialchars($st['email']) ?></td>
    <td><?= htmlspecialchars($st['company_name']) ?></td>
    <td><?= htmlspecialchars($st['sector'] ?? '—') ?></td>
    <td><?= htmlspecialchars($st['location'] ?? '—') ?></td>
    <td><?= $st['placement_date'] ? date('d M Y', strtotime($st['placement_date'])) : '—' ?></td>
    <td><?= htmlspecialchars($st['supervisor_name'] ?? '—') ?></td>
    <td><?= htmlspecialchars($st['wps_name'] ?? '—') ?><?= $st['wps_title'] ? '<br><small style="color:#6b7280;">' . htmlspecialchars($st['wps_title']) . '</small>' : '' ?></td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<div class="footer">IAMS — University of Botswana &nbsp;|&nbsp; Confidential — For Academic Use Only</div>
</body>
</html>
    <?php
    exit;
}

$pageTitle = 'Active Placements';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Active Placements</h1>
    <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-size:13px;color:#6b7280;"><?= count($students) ?> student(s) placed</span>
        <a href="active_placements.php?export=excel" class="btn btn-secondary btn-sm">⬇ Export CSV</a>
        <a href="active_placements.php?export=pdf&download=1" target="_blank" class="btn btn-secondary btn-sm" style="background:#1e3a5f;color:#fff;">⬇ Export PDF</a>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
    </div>
</div>

<?php if (empty($students)): ?>
    <div class="card">
        <p class="text-muted">No students have confirmed placements yet.</p>
    </div>
<?php else: ?>
<div class="card" style="overflow-x:auto;">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Student Name</th>
                <th>Student No.</th>
                <th>Programme</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Company</th>
                <th>Sector</th>
                <th>Location</th>
                <th>Placement Date</th>
                <th>Academic Supervisor</th>
                <th>Workplace Supervisor</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $i => $st): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><strong><?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']) ?></strong></td>
                <td><?= htmlspecialchars($st['student_number']) ?></td>
                <td><?= htmlspecialchars($st['programme']) ?></td>
                <td><?= htmlspecialchars($st['email']) ?></td>
                <td><?= htmlspecialchars($st['phone'] ?? '—') ?></td>
                <td><span class="badge badge-accepted"><?= htmlspecialchars($st['company_name']) ?></span></td>
                <td><?= htmlspecialchars($st['sector'] ?? '—') ?></td>
                <td><?= htmlspecialchars($st['location'] ?? '—') ?></td>
                <td><?= $st['placement_date'] ? date('d M Y', strtotime($st['placement_date'])) : '—' ?></td>
                <td><?= $st['supervisor_name'] ? htmlspecialchars($st['supervisor_name']) : '<span class="text-muted">None</span>' ?></td>
                <td>
                    <?php if ($st['wps_name']): ?>
                        <?= htmlspecialchars($st['wps_name']) ?>
                        <?php if ($st['wps_title']): ?>
                            <br><small class="text-muted"><?= htmlspecialchars($st['wps_title']) ?></small>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="text-muted">None</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
