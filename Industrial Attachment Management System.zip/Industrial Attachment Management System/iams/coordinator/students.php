<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

$students = $db->query('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme, u.email,
           (SELECT c.company_name FROM applications a JOIN companies c ON a.company_id=c.id
            WHERE a.student_id=s.id AND a.status="accepted" LIMIT 1) AS placed_company,
           (SELECT CONCAT(l.first_name," ",l.last_name) FROM supervisor_assignments sa
            JOIN lecturers l ON sa.lecturer_id=l.id WHERE sa.student_id=s.id LIMIT 1) AS supervisor
    FROM students s JOIN users u ON s.user_id=u.id
    ORDER BY s.last_name
')->fetchAll();

$pageTitle = 'All Students';
require_once __DIR__ . '/../includes/header.php';
?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">All Students</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>
<div class="card">
    <p class="text-muted" style="margin-bottom:12px;"><?= count($students) ?> student(s) registered.</p>
    <?php if (empty($students)): ?>
        <p class="text-muted">No students registered yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>#</th><th>Name</th><th>Student No.</th><th>Programme</th><th>Email</th><th>Placed At</th><th>Supervisor</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($students as $i => $st): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><strong><?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?></strong></td>
                        <td><?= htmlspecialchars($st['student_number']) ?></td>
                        <td><?= htmlspecialchars($st['programme']) ?></td>
                        <td><?= htmlspecialchars($st['email']) ?></td>
                        <td><?= $st['placed_company'] ? '<span class="badge badge-accepted">'.htmlspecialchars($st['placed_company']).'</span>' : '<span class="text-muted">Not placed</span>' ?></td>
                        <td><?= $st['supervisor'] ? htmlspecialchars($st['supervisor']) : '<span class="text-muted">None</span>' ?></td>
                        <td><a href="<?= BASE_URL ?>/coordinator/assign.php" class="btn btn-primary btn-sm">Assign</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
