<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

$vacancies = $db->query('
    SELECT v.*, c.company_name, c.sector
    FROM vacancies v
    JOIN companies c ON v.company_id = c.id
    WHERE v.is_active = 1
    ORDER BY v.created_at DESC
')->fetchAll();

$pageTitle = 'Vacancies';
require_once __DIR__ . '/../includes/header.php';
?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Available Vacancies</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<?php if (empty($vacancies)): ?>
    <div class="card"><p class="text-muted">No active vacancies posted by companies yet.</p></div>
<?php else: ?>
    <p class="text-muted" style="margin-bottom:12px;"><?= count($vacancies) ?> active vacancy/vacancies.</p>
    <?php foreach ($vacancies as $v): ?>
        <div class="card" style="margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;">
                <div>
                    <h3 style="color:#1e3a5f;margin:0 0 4px;"><?= htmlspecialchars($v['position_title']) ?></h3>
                    <span class="text-muted"><?= htmlspecialchars($v['company_name']) ?> — <?= htmlspecialchars($v['sector']) ?></span>
                    <br>
                    <small class="text-muted">
                        <?= (int)$v['num_positions'] ?> position(s)
                        <?= $v['deadline'] ? ' | Deadline: '.date('d M Y', strtotime($v['deadline'])) : '' ?>
                    </small>
                    <?php if ($v['description']): ?>
                        <p style="margin:8px 0 4px;font-size:14px;"><?= nl2br(htmlspecialchars($v['description'])) ?></p>
                    <?php endif; ?>
                    <?php if ($v['requirements']): ?>
                        <p style="margin:4px 0;font-size:13px;color:#555;"><strong>Requirements:</strong> <?= nl2br(htmlspecialchars($v['requirements'])) ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
