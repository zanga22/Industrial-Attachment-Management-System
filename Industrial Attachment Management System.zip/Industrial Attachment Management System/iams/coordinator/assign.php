<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign'])) {
    $studentId  = (int)$_POST['student_id'];
    $lecturerId = (int)$_POST['lecturer_id'];

    if ($studentId && $lecturerId) {

        $db->prepare('
            INSERT INTO supervisor_assignments (student_id, lecturer_id)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE lecturer_id = VALUES(lecturer_id), assigned_at = NOW()
        ')->execute([$studentId, $lecturerId]);
        setFlash('success', 'Supervisor assigned successfully.');
    } else {
        setFlash('error', 'Please select both a student and a lecturer.');
    }
    header('Location: ' . BASE_URL . '/coordinator/assign.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_id'])) {
    $db->prepare('DELETE FROM supervisor_assignments WHERE student_id = ?')
       ->execute([(int)$_POST['remove_id']]);
    setFlash('success', 'Assignment removed.');
    header('Location: ' . BASE_URL . '/coordinator/assign.php');
    exit;
}

$students = $db->query('
    SELECT s.id, s.first_name, s.last_name, s.student_number, s.programme
    FROM students s
    WHERE s.id NOT IN (SELECT student_id FROM supervisor_assignments)
    ORDER BY s.last_name
')->fetchAll();

$lecturers = $db->query('
    SELECT l.id, l.first_name, l.last_name, l.department
    FROM lecturers l
    ORDER BY l.last_name
')->fetchAll();

$assignments = $db->query('
    SELECT sa.student_id, sa.assigned_at,
           s.first_name AS s_first, s.last_name AS s_last,
           s.student_number, s.programme,
           l.first_name AS l_first, l.last_name AS l_last, l.department
    FROM supervisor_assignments sa
    JOIN students s  ON sa.student_id  = s.id
    JOIN lecturers l ON sa.lecturer_id = l.id
    ORDER BY sa.assigned_at DESC
')->fetchAll();

$pageTitle = 'Assign Supervisors';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h1 class="page-title">Assign Supervisors</h1>
    <a href="<?= BASE_URL ?>/coordinator/dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- ── Assignment form ── -->
<div class="card">
    <h2>New Assignment</h2>
    <?php if (empty($lecturers)): ?>
        <div class="alert alert-info">No lecturers registered yet.</div>
    <?php elseif (empty($students)): ?>
        <div class="alert alert-info">All students already have supervisors assigned.</div>
    <?php else: ?>
        <form method="POST" action="assign.php">
            <div class="two-col">
                <div class="form-group">
                    <label for="student_id">Student *</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">-- Select student --</option>
                        <?php foreach ($students as $st): ?>
                            <option value="<?= (int)$st['id'] ?>">
                                <?= htmlspecialchars($st['first_name'] . ' ' . $st['last_name']
                                    . ' (' . $st['student_number'] . ') — ' . $st['programme']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="lecturer_id">Supervisor (Lecturer) *</label>
                    <select name="lecturer_id" id="lecturer_id" required>
                        <option value="">-- Select lecturer --</option>
                        <?php foreach ($lecturers as $lc): ?>
                            <option value="<?= (int)$lc['id'] ?>">
                                <?= htmlspecialchars($lc['first_name'] . ' ' . $lc['last_name']
                                    . ' — ' . $lc['department']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <input type="hidden" name="assign" value="1">
            <button type="submit" class="btn btn-success">Assign Supervisor</button>
        </form>
    <?php endif; ?>
</div>

<!-- ── Existing assignments ── -->
<div class="card">
    <h2>Current Assignments</h2>
    <?php if (empty($assignments)): ?>
        <p class="text-muted">No supervisor assignments yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Student No.</th>
                    <th>Programme</th>
                    <th>Supervisor</th>
                    <th>Department</th>
                    <th>Assigned</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assignments as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['s_first'] . ' ' . $a['s_last']) ?></td>
                        <td><?= htmlspecialchars($a['student_number']) ?></td>
                        <td><?= htmlspecialchars($a['programme']) ?></td>
                        <td><strong><?= htmlspecialchars($a['l_first'] . ' ' . $a['l_last']) ?></strong></td>
                        <td><?= htmlspecialchars($a['department']) ?></td>
                        <td><?= date('d M Y', strtotime($a['assigned_at'])) ?></td>
                        <td>
                            <form method="POST" onsubmit="return confirm('Remove this assignment?')">
                                <input type="hidden" name="remove_id" value="<?= (int)$a['student_id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
