<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['decision'])) {
    $reqId    = (int)$_POST['req_id'];
    $decision = $_POST['decision'];
    $note     = trim($_POST['reviewer_note'] ?? '');

    if (!in_array($decision, ['approved','rejected'], true)) {
        setFlash('error', 'Invalid decision.');
    } else {

        $chk = $db->prepare('SELECT cr.id, cr.student_id, cr.company_name, s.first_name, s.last_name, u.id AS user_id
                              FROM company_requests cr
                              JOIN students s ON cr.student_id = s.id
                              JOIN users u ON s.user_id = u.id
                              WHERE cr.id = ? AND cr.status = "pending"');
        $chk->execute([$reqId]);
        $req = $chk->fetch();

        if ($req) {
            $db->prepare('UPDATE company_requests SET status = ?, reviewed_by = ?, reviewer_note = ? WHERE id = ?')
               ->execute([$decision, currentUserId(), $note ?: null, $reqId]);


            if ($decision === 'approved') {
                $msg = "Your company suggestion \"{$req['company_name']}\" has been approved by the coordinator!";
                $link = BASE_URL . '/student/apply.php';
            } else {
                $msg = "Your company suggestion \"{$req['company_name']}\" was not approved." . ($note ? " Reason: $note" : '');
                $link = BASE_URL . '/student/apply.php';
            }
            sendNotification($db, $req['user_id'], $msg, $link);

            setFlash('success', 'Request ' . $decision . '. Student has been notified.');
        } else {
            setFlash('error', 'Request not found or already reviewed.');
        }
    }
    header('Location: ' . BASE_URL . '/coordinator/company_requests.php');
    exit;
}

$filterStatus = $_GET['status'] ?? 'pending';
if (!in_array($filterStatus, ['all','pending','approved','rejected'], true)) $filterStatus = 'pending';

$sql = 'SELECT cr.id, cr.company_name, cr.company_address, cr.reason, cr.status,
               cr.reviewer_note, cr.created_at,
               s.first_name, s.last_name, s.student_number, s.programme
        FROM company_requests cr
        JOIN students s ON cr.student_id = s.id';
$params = [];
if ($filterStatus !== 'all') { $sql .= ' WHERE cr.status = ?'; $params[] = $filterStatus; }
$sql .= ' ORDER BY cr.created_at DESC';
$stmt = $db->prepare($sql); $stmt->execute($params);
$requests = $stmt->fetchAll();

$pageTitle = 'Company Requests';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Student Company Suggestions</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<!-- Filter tabs -->
<div class="card" style="padding:12px;">
    <?php foreach (['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected','all'=>'All'] as $val => $lbl): ?>
        <a href="?status=<?= $val ?>"
           class="btn btn-sm <?= $filterStatus === $val ? 'btn-primary' : 'btn-secondary' ?>"
           style="margin-right:6px;"><?= $lbl ?></a>
    <?php endforeach; ?>
</div>

<?php if (empty($requests)): ?>
    <div class="card"><p class="text-muted">No company requests found.</p></div>
<?php else: ?>
    <?php foreach ($requests as $r): ?>
        <div class="card" style="margin-bottom:14px;border-left:4px solid <?= $r['status']==='pending' ? '#f59e0b' : ($r['status']==='approved' ? '#10b981' : '#ef4444') ?>">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;">
                <div>
                    <strong style="font-size:16px;"><?= htmlspecialchars($r['company_name']) ?></strong>
                    <span class="badge badge-<?= $r['status']==='approved' ? 'approved' : ($r['status']==='rejected' ? 'rejected' : 'pending') ?>" style="margin-left:10px;"><?= ucfirst($r['status']) ?></span>
                    <br>
                    <span class="text-muted">Suggested by: <strong><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?></strong>
                        (<?= htmlspecialchars($r['student_number']) ?>) — <?= htmlspecialchars($r['programme']) ?></span>
                    <br>
                    <small class="text-muted"><?= date('d M Y H:i', strtotime($r['created_at'])) ?></small>
                    <?php if ($r['company_address']): ?>
                        <br><small><strong>Address:</strong> <?= htmlspecialchars($r['company_address']) ?></small>
                    <?php endif; ?>
                    <?php if ($r['reason']): ?>
                        <br><small><strong>Reason:</strong> <?= htmlspecialchars($r['reason']) ?></small>
                    <?php endif; ?>
                    <?php if ($r['reviewer_note']): ?>
                        <br><small style="color:#666;"><em>Reviewer note: <?= htmlspecialchars($r['reviewer_note']) ?></em></small>
                    <?php endif; ?>
                </div>

                <?php if ($r['status'] === 'pending'): ?>
                    <div style="min-width:280px;">
                        <form method="POST" action="company_requests.php">
                            <input type="hidden" name="req_id" value="<?= (int)$r['id'] ?>">
                            <div class="form-group" style="margin-bottom:8px;">
                                <label style="font-size:13px;">Note to student (optional)</label>
                                <textarea name="reviewer_note" rows="2" style="width:100%;font-size:13px;"
                                          placeholder="Reason for approval/rejection..."></textarea>
                            </div>
                            <div style="display:flex;gap:8px;">
                                <button type="submit" name="decision" value="approved"
                                        class="btn btn-success btn-sm"
                                        onclick="return confirm('Approve this company suggestion?')"> Approve</button>
                                <button type="submit" name="decision" value="rejected"
                                        class="btn btn-danger btn-sm"
                                        onclick="return confirm('Reject this company suggestion?')">✗ Reject</button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
