<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = (int)($_POST['student_id'] ?? 0);
    $action    = $_POST['action'] ?? '';

    if ($studentId && in_array($action, ['approve','publish','flag','override','edit_scores'], true)) {
        $db->beginTransaction();
        try {
            if ($action === 'approve') {
                $db->prepare("UPDATE final_grades SET status='approved', approved_by=?, approved_at=NOW() WHERE student_id=?")
                   ->execute([currentUserId(), $studentId]);
                $db->prepare("INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)")
                   ->execute([$studentId,'coordinator_approved',currentUserId(),'Grade approved']);
                setFlash('success','Grade approved.');

            } elseif ($action === 'publish') {
                $db->prepare("UPDATE final_grades SET status='published', published_at=NOW(), approved_by=?, approved_at=COALESCE(approved_at,NOW()) WHERE student_id=?")
                   ->execute([currentUserId(), $studentId]);
                $db->prepare("INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)")
                   ->execute([$studentId,'coordinator_published',currentUserId(),'Grade published']);
                $su = $db->prepare('SELECT u.id FROM students s JOIN users u ON s.user_id=u.id WHERE s.id=?');
                $su->execute([$studentId]); $suRow = $su->fetch();
                if ($suRow) sendNotification($db,$suRow['id'],'Your attachment final grade has been published.',BASE_URL.'/student/my_grade.php');
                setFlash('success','Grade published. Student notified.');

            } elseif ($action === 'flag') {
                $note = trim($_POST['coordinator_note'] ?? '');
                $db->prepare("UPDATE final_grades SET status='flagged', coordinator_note=? WHERE student_id=?")
                   ->execute([$note ?: null, $studentId]);
                $db->prepare("INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)")
                   ->execute([$studentId,'coordinator_flagged',currentUserId(),$note]);
                setFlash('success','Entry flagged.');

            } elseif ($action === 'override') {
                $og = strtoupper(trim($_POST['override_grade'] ?? ''));
                $just = trim($_POST['override_justification'] ?? '');
                if (!$og || !$just) { setFlash('error','Override grade and justification required.'); }
                else {
                    $db->prepare("UPDATE final_grades SET override_grade=?, override_justification=?, override_by=?, status='approved', approved_by=?, approved_at=NOW() WHERE student_id=?")
                       ->execute([$og,$just,currentUserId(),currentUserId(),$studentId]);
                    $db->prepare("INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)")
                       ->execute([$studentId,'coordinator_override',currentUserId(),"Override:$og. $just"]);
                    setFlash('success','Grade overridden.');
                }

            } elseif ($action === 'edit_scores') {
                $wpsS  = isset($_POST['wps_score'])  && $_POST['wps_score']  !== '' ? min(100,max(0,(float)$_POST['wps_score']))  : null;
                $acadS = isset($_POST['acad_score']) && $_POST['acad_score'] !== '' ? min(100,max(0,(float)$_POST['acad_score'])) : null;
                $repS  = isset($_POST['rep_score'])  && $_POST['rep_score']  !== '' ? min(100,max(0,(float)$_POST['rep_score']))  : null;
                $total = null; $letter = null;
                if ($wpsS!==null && $acadS!==null && $repS!==null) {
                    $total  = round(($wpsS*0.30)+($acadS*0.20)+($repS*0.50),2);
                    $letter = computeLetterGrade($db,$total);
                }
                $existing = $db->prepare('SELECT id FROM final_grades WHERE student_id=?');
                $existing->execute([$studentId]);
                if ($existing->fetch()) {
                    $db->prepare('UPDATE final_grades SET wps_report_score=?,academic_report_score=?,student_report_score=?,workplace_score=?,lecturer_score=?,total_score=?,letter_grade=?,updated_at=NOW() WHERE student_id=?')
                       ->execute([$wpsS,$acadS,$repS,$wpsS,$acadS,$total,$letter,$studentId]);
                } else {
                    $db->prepare('INSERT INTO final_grades (student_id,wps_report_score,academic_report_score,student_report_score,workplace_score,lecturer_score,total_score,letter_grade,status) VALUES (?,?,?,?,?,?,?,?,?)')
                       ->execute([$studentId,$wpsS,$acadS,$repS,$wpsS,$acadS,$total,$letter,'partial']);
                }
                $db->prepare("INSERT INTO grade_audit_log (student_id,action,performed_by,details) VALUES (?,?,?,?)")
                   ->execute([$studentId,'coordinator_edit_scores',currentUserId(),"WPS:$wpsS Acad:$acadS Rep:$repS Total:$total"]);
                setFlash('success','Scores updated.');
            }
            $db->commit();
        } catch (Exception $e) { $db->rollBack(); setFlash('error','Error: '.$e->getMessage()); }
    }
    header('Location: marks_table.php'); exit;
}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $rows = getMarksRows($db);
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="iams_grades_'.date('Ymd').'.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,['Student Name','Student Number','Programme','Company','Academic Supervisor',
                  'WPS Summative /100 (30%)','Academic Summative /100 (20%)','Student Report /100 (50%)',
                  'Weighted Total /100','Letter Grade','Status','Published']);
    foreach ($rows as $r) {
        $wS=$r['wps_score']!==null?(float)$r['wps_score']:null;
        $aS=$r['acad_score']!==null?(float)$r['acad_score']:null;
        $rS=$r['rep_score']!==null?(float)$r['rep_score']:null;
        $wt=($wS!==null&&$aS!==null&&$rS!==null)?round(($wS*.3)+($aS*.2)+($rS*.5),2):null;
        fputcsv($out,[
            $r['first_name'].' '.$r['last_name'],$r['student_number'],$r['programme'],
            $r['company_name']??'—',($r['lec_first']??'').' '.($r['lec_last']??''),
            $wS!==null?number_format($wS,1):'—',
            $aS!==null?number_format($aS,1):'—',
            $rS!==null?number_format($rS,1):'—',
            $wt!==null?number_format($wt,2):'—',
            $r['override_grade']?:($r['letter_grade']??'—'),
            $r['status']??'pending',
            $r['published_at']?date('d M Y',strtotime($r['published_at'])):'—',
        ]);
    }
    fclose($out); exit;
}

function getMarksRows(PDO $db): array {
    return $db->query('
        SELECT s.id AS student_id, s.first_name, s.last_name, s.student_number, s.programme,
               c.company_name, l.first_name AS lec_first, l.last_name AS lec_last,
               wsr.total_score AS wps_score, wsr.status AS wps_status,
               asr.total_score AS acad_score, asr.status AS acad_status,
               srg.total_score AS rep_score, srg.status AS rep_status,
               fg.total_score, fg.letter_grade, fg.override_grade, fg.override_justification,
               fg.status, fg.discrepancy_flag, fg.coordinator_note, fg.published_at
        FROM students s
        LEFT JOIN workplace_assignments wa ON wa.student_id=s.id
        LEFT JOIN companies c ON wa.company_id=c.id
        LEFT JOIN supervisor_assignments sa ON sa.student_id=s.id
        LEFT JOIN lecturers l ON sa.lecturer_id=l.id
        LEFT JOIN wps_summative_reports wsr ON wsr.student_id=s.id
        LEFT JOIN academic_summative_reports asr ON asr.student_id=s.id
        LEFT JOIN student_report_grades srg ON srg.student_id=s.id
        LEFT JOIN final_grades fg ON fg.student_id=s.id
        ORDER BY s.last_name, s.first_name
    ')->fetchAll();
}

function statusBadge(string $s): string {
    $m=['pending'=>['#fef3c7','#92400e','Pending'],'partial'=>['#fef9c3','#854d0e','Partial'],
        'submitted'=>['#dbeafe','#1e40af','Submitted'],'flagged'=>['#fee2e2','#991b1b','⚑ Flagged'],
        'approved'=>['#f0fdf4','#166534','Approved'],'published'=>['#dcfce7','#14532d',' Published']];
    [$bg,$c,$l]=$m[$s]??['#f3f4f6','#374151',$s];
    return "<span style=\"background:$bg;color:$c;padding:2px 10px;border-radius:10px;font-size:12px;font-weight:600;\">$l</span>";
}

$rows = getMarksRows($db);
$pageTitle = 'Marks Table';
require_once __DIR__ . '/../includes/header.php';
?>

<style>
.mtcard{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:20px;margin-bottom:14px;}
.sbox{text-align:center;padding:8px 12px;border-radius:6px;border:1px solid #e2e8f0;min-width:78px;background:#f8fafc;}
.sbox .lb{font-size:10px;color:#6b7280;line-height:1.2;margin-bottom:3px;}
.sbox .vl{font-size:19px;font-weight:bold;color:#1e3a5f;}
.sbox .sb{font-size:10px;color:#9ca3af;}
details summary{list-style:none;cursor:pointer;}
details summary::-webkit-details-marker{display:none;}
.pop{position:absolute;z-index:30;background:#fff;border:1px solid #d1d5db;border-radius:8px;padding:18px;min-width:300px;box-shadow:0 4px 16px rgba(0,0,0,.12);margin-top:4px;}
</style>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
    <h1 class="page-title">Marks Table</h1>
    <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-size:13px;color:#6b7280;"><?= count($rows) ?> student(s)</span>
        <a href="marks_table.php?export=csv" class="btn btn-secondary btn-sm">⬇ Export CSV</a>
        <a href="marks_table_pdf.php?download=1" target="_blank" class="btn btn-secondary btn-sm" style="background:#1e3a5f;color:#fff;">⬇ Export PDF</a>
    </div>
</div>

<div class="alert alert-info" style="font-size:13px;margin-bottom:16px;">
    <strong>Formula:</strong> WPS Summative Report (30%) + Academic Supervisor Summative Report (20%) + Student Final Report Grade (50%) = Final Grade / 100
</div>

<?php foreach ($rows as $r):
    $status = $r['status'] ?? 'pending';
    $finalGrade = $r['override_grade'] ?: ($r['letter_grade'] ?? null);
    $wS = $r['wps_score']  !== null ? (float)$r['wps_score']  : null;
    $aS = $r['acad_score'] !== null ? (float)$r['acad_score'] : null;
    $rS = $r['rep_score']  !== null ? (float)$r['rep_score']  : null;
    $wt = ($wS!==null&&$aS!==null&&$rS!==null) ? round(($wS*.3)+($aS*.2)+($rS*.5),2) : null;
    $border = $r['discrepancy_flag']?'#ef4444':($status==='published'?'#10b981':'#94a3b8');
?>
<div class="mtcard" style="border-left:4px solid <?= $border ?>;">
    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:12px;">
        <div>
            <strong style="font-size:16px;"><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?></strong>
            <?= statusBadge($status) ?>
            <?php if ($r['discrepancy_flag']): ?><span style="background:#fee2e2;color:#991b1b;padding:2px 8px;border-radius:10px;font-size:12px;font-weight:bold;margin-left:4px;">⚑ Score Discrepancy</span><?php endif; ?>
            <?php if ($r['override_grade']): ?><span style="background:#f3e8ff;color:#6b21a8;padding:2px 8px;border-radius:10px;font-size:12px;margin-left:4px;">Override: <?= htmlspecialchars($r['override_grade']) ?></span><?php endif; ?>
            <br><span class="text-muted" style="font-size:13px;"><?= htmlspecialchars($r['student_number']) ?> — <?= htmlspecialchars($r['programme']) ?></span>
            <br><small class="text-muted"> <?= htmlspecialchars($r['company_name']??'—') ?><?php if($r['lec_first']): ?> | 📚 <?= htmlspecialchars($r['lec_first'].' '.$r['lec_last']) ?><?php endif; ?></small>
        </div>
        <div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap;">
            <div class="sbox" style="border-color:<?= $r['wps_status']==='submitted'?'#22c55e':'#fbbf24' ?>;">
                <div class="lb">WPS Summative<br><small>(×30%)</small></div>
                <?php if ($wS!==null): ?><div class="vl"><?= number_format($wS,1) ?></div><div class="sb">→ <?= number_format($wS*.3,1) ?></div>
                <?php else: ?><div style="font-size:12px;color:#92400e;"><?= $r['wps_status']==='draft'?'Draft':'Pending' ?></div><?php endif; ?>
            </div>
            <span style="color:#94a3b8;font-size:18px;">+</span>
            <div class="sbox" style="border-color:<?= $r['acad_status']==='submitted'?'#22c55e':'#fbbf24' ?>;">
                <div class="lb">Academic Summative<br><small>(×20%)</small></div>
                <?php if ($aS!==null): ?><div class="vl"><?= number_format($aS,1) ?></div><div class="sb">→ <?= number_format($aS*.2,1) ?></div>
                <?php else: ?><div style="font-size:12px;color:#92400e;"><?= $r['acad_status']==='draft'?'Draft':'Pending' ?></div><?php endif; ?>
            </div>
            <span style="color:#94a3b8;font-size:18px;">+</span>
            <div class="sbox" style="border-color:<?= $r['rep_status']==='submitted'?'#22c55e':'#fbbf24' ?>;">
                <div class="lb">Student Report<br><small>(×50%)</small></div>
                <?php if ($rS!==null): ?><div class="vl"><?= number_format($rS,1) ?></div><div class="sb">→ <?= number_format($rS*.5,1) ?></div>
                <?php else: ?><div style="font-size:12px;color:#92400e;"><?= $r['rep_status']==='draft'?'Draft':'Pending' ?></div><?php endif; ?>
            </div>
            <span style="color:#94a3b8;font-size:18px;">=</span>
            <div class="sbox" style="background:#eff6ff;border-color:#bfdbfe;">
                <div class="lb">Total</div>
                <?php if ($wt!==null): ?><div class="vl"><?= number_format($wt,1) ?></div><div class="sb">/ 100</div>
                <?php else: ?><div style="font-size:13px;color:#94a3b8;">—</div><?php endif; ?>
            </div>
            <?php if ($finalGrade): ?>
            <div class="sbox" style="background:#1e3a5f;border-color:#1e3a5f;">
                <div class="lb" style="color:#93c5fd;">Grade</div>
                <div class="vl" style="color:#fff;font-size:26px;"><?= htmlspecialchars($finalGrade) ?></div>
                <div class="sb">&nbsp;</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($r['coordinator_note']): ?>
    <div style="background:#fef9c3;border:1px solid #fde047;padding:8px 12px;border-radius:4px;margin-bottom:10px;font-size:13px;">
        <strong>Note:</strong> <?= htmlspecialchars($r['coordinator_note']) ?>
    </div>
    <?php endif; ?>

    <?php if ($status !== 'published'): ?>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start;border-top:1px solid #f1f5f9;padding-top:12px;position:relative;">

        <?php if (in_array($status,['submitted','flagged'],true)): ?>
        <form method="POST" onsubmit="return confirm('Approve this grade?')">
            <input type="hidden" name="student_id" value="<?= $r['student_id'] ?>">
            <input type="hidden" name="action" value="approve">
            <button class="btn btn-success btn-sm"> Approve</button>
        </form>
        <?php endif; ?>

        <?php if ($status==='approved'): ?>
        <form method="POST" onsubmit="return confirm('Publish grade? Student will be notified.')">
            <input type="hidden" name="student_id" value="<?= $r['student_id'] ?>">
            <input type="hidden" name="action" value="publish">
            <button class="btn btn-success btn-sm" style="background:#059669;">📢 Publish</button>
        </form>
        <?php endif; ?>

        <details>
            <summary class="btn btn-secondary btn-sm" style="display:inline-block;">✏ Edit Scores</summary>
            <div class="pop">
                <form method="POST">
                    <input type="hidden" name="student_id" value="<?= $r['student_id'] ?>">
                    <input type="hidden" name="action" value="edit_scores">
                    <p style="font-size:12px;color:#6b7280;margin-bottom:10px;">Override component scores to recalculate the weighted total. Leave a field blank to keep its current value.</p>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:12px;">
                        <?php foreach([['wps_score','WPS Summative','×30%',$wS],['acad_score','Academic Summative','×20%',$aS],['rep_score','Student Report','×50%',$rS]] as [$fname,$flabel,$fpct,$fval]): ?>
                        <div>
                            <label style="font-size:11px;font-weight:600;text-transform:uppercase;color:#6b7280;"><?= $flabel ?></label>
                            <input type="number" name="<?= $fname ?>" min="0" max="100" step="0.5"
                                   value="<?= $fval!==null?number_format($fval,1):'' ?>" placeholder="—"
                                   style="width:100%;padding:5px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;text-align:center;">
                            <small style="color:#9ca3af;">/100 <?= $fpct ?></small>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">Recalculate &amp; Save</button>
                </form>
            </div>
        </details>

        <details>
            <summary class="btn btn-secondary btn-sm" style="display:inline-block;">🔀 Override Grade</summary>
            <div class="pop">
                <form method="POST">
                    <input type="hidden" name="student_id" value="<?= $r['student_id'] ?>">
                    <input type="hidden" name="action" value="override">
                    <div style="margin-bottom:8px;">
                        <label style="font-size:13px;font-weight:600;">Letter Grade *</label>
                        <input type="text" name="override_grade" placeholder="e.g. B" maxlength="3" required style="width:100%;padding:6px;border:1px solid #d1d5db;border-radius:4px;font-size:14px;text-transform:uppercase;margin-top:3px;">
                    </div>
                    <div style="margin-bottom:10px;">
                        <label style="font-size:13px;font-weight:600;">Justification *</label>
                        <textarea name="override_justification" rows="3" required style="width:100%;padding:6px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;margin-top:3px;" placeholder="Mandatory justification..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Apply override?')">Apply</button>
                </form>
            </div>
        </details>

        <details>
            <summary class="btn btn-danger btn-sm" style="display:inline-block;">⚑ Flag</summary>
            <div class="pop">
                <form method="POST">
                    <input type="hidden" name="student_id" value="<?= $r['student_id'] ?>">
                    <input type="hidden" name="action" value="flag">
                    <div style="margin-bottom:10px;">
                        <label style="font-size:13px;font-weight:600;">Reason</label>
                        <textarea name="coordinator_note" rows="3" style="width:100%;padding:6px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;margin-top:3px;" placeholder="Explain the issue..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger btn-sm">Flag</button>
                </form>
            </div>
        </details>
    </div>
    <?php else: ?>
    <div style="border-top:1px solid #f1f5f9;padding-top:8px;font-size:13px;color:#059669;">
        ✓ Published <?= date('d M Y',strtotime($r['published_at'])) ?>
        <?php if($r['override_justification']): ?> | <em style="color:#6b7280;"><?= htmlspecialchars($r['override_justification']) ?></em><?php endif; ?>
    </div>
    <?php endif; ?>

</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
