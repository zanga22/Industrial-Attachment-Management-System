<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('coordinator');
requireApproved();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_criterion'])) {
    $graderType  = $_POST['grader_type'] ?? '';
    $criterion   = trim($_POST['criterion'] ?? '');
    $maxScore    = max(1, (int)($_POST['max_score'] ?? 10));
    $description = trim($_POST['description'] ?? '');
    if (!in_array($graderType, ['workplace','lecturer'], true) || $criterion === '') {
        setFlash('error','Invalid input.'); } else {
        $db->prepare('INSERT INTO grading_rubric (grader_type, criterion, max_score, description, created_by) VALUES (?,?,?,?,?)')
           ->execute([$graderType, $criterion, $maxScore, $description ?: null, currentUserId()]);
        setFlash('success','Criterion added.');
    }
    header('Location: rubric.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $db->prepare('UPDATE grading_rubric SET is_active=0 WHERE id=?')->execute([(int)$_POST['delete_id']]);
    setFlash('success','Criterion removed.'); header('Location: rubric.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_scale'])) {
    $letters = $_POST['letter'] ?? [];
    $mins    = $_POST['min']    ?? [];
    $maxs    = $_POST['max']    ?? [];
    $descs   = $_POST['desc']   ?? [];
    $db->exec('DELETE FROM grading_scale');
    foreach ($letters as $i => $letter) {
        if (trim($letter) === '') continue;
        $db->prepare('INSERT INTO grading_scale (letter, min_score, max_score, description) VALUES (?,?,?,?)')
           ->execute([trim($letter), (float)$mins[$i], (float)$maxs[$i], trim($descs[$i] ?? '')]);
    }
    setFlash('success','Grading scale updated.'); header('Location: rubric.php'); exit;
}

$wpRubric  = $db->query('SELECT * FROM grading_rubric WHERE grader_type="workplace" AND is_active=1 ORDER BY sort_order')->fetchAll();
$lecRubric = $db->query('SELECT * FROM grading_rubric WHERE grader_type="lecturer"  AND is_active=1 ORDER BY sort_order')->fetchAll();
$scale     = $db->query('SELECT * FROM grading_scale ORDER BY min_score DESC')->fetchAll();

$pageTitle = 'Manage Rubric & Grading Scale';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
    <h1 class="page-title">Rubric &amp; Grading Scale</h1>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Dashboard</a>
</div>

<div class="two-col">

<!-- Workplace rubric -->
<div class="card">
    <h2>Workplace Supervisor Rubric
        <span style="font-size:13px;font-weight:normal;color:#666;margin-left:8px;">
            Total: <?= array_sum(array_column($wpRubric,'max_score')) ?> pts
        </span>
    </h2>
    <table>
        <thead><tr><th>Criterion</th><th>Max</th><th>Description</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($wpRubric as $r): ?>
            <tr>
                <td><strong><?= htmlspecialchars($r['criterion']) ?></strong></td>
                <td><?= (int)$r['max_score'] ?></td>
                <td><small class="text-muted"><?= htmlspecialchars($r['description'] ?? '') ?></small></td>
                <td>
                    <form method="POST" onsubmit="return confirm('Remove this criterion?')">
                        <input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <form method="POST" style="margin-top:14px;padding-top:14px;border-top:1px solid #e2e8f0;">
        <input type="hidden" name="grader_type" value="workplace">
        <div style="display:grid;grid-template-columns:1fr 60px 1fr;gap:8px;align-items:end;">
            <div class="form-group" style="margin:0;"><label>Criterion *</label><input type="text" name="criterion" required placeholder="e.g. Innovation"></div>
            <div class="form-group" style="margin:0;"><label>Max</label><input type="number" name="max_score" value="10" min="1" max="100"></div>
            <div class="form-group" style="margin:0;"><label>Description</label><input type="text" name="description" placeholder="Optional"></div>
        </div>
        <button type="submit" name="add_criterion" class="btn btn-primary btn-sm" style="margin-top:8px;">+ Add Criterion</button>
    </form>
</div>

<!-- Lecturer rubric -->
<div class="card">
    <h2>Lecturer Rubric
        <span style="font-size:13px;font-weight:normal;color:#666;margin-left:8px;">
            Total: <?= array_sum(array_column($lecRubric,'max_score')) ?> pts
        </span>
    </h2>
    <table>
        <thead><tr><th>Criterion</th><th>Max</th><th>Description</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($lecRubric as $r): ?>
            <tr>
                <td><strong><?= htmlspecialchars($r['criterion']) ?></strong></td>
                <td><?= (int)$r['max_score'] ?></td>
                <td><small class="text-muted"><?= htmlspecialchars($r['description'] ?? '') ?></small></td>
                <td>
                    <form method="POST" onsubmit="return confirm('Remove this criterion?')">
                        <input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <form method="POST" style="margin-top:14px;padding-top:14px;border-top:1px solid #e2e8f0;">
        <input type="hidden" name="grader_type" value="lecturer">
        <div style="display:grid;grid-template-columns:1fr 60px 1fr;gap:8px;align-items:end;">
            <div class="form-group" style="margin:0;"><label>Criterion *</label><input type="text" name="criterion" required placeholder="e.g. Presentation"></div>
            <div class="form-group" style="margin:0;"><label>Max</label><input type="number" name="max_score" value="10" min="1" max="100"></div>
            <div class="form-group" style="margin:0;"><label>Description</label><input type="text" name="description" placeholder="Optional"></div>
        </div>
        <button type="submit" name="add_criterion" class="btn btn-primary btn-sm" style="margin-top:8px;">+ Add Criterion</button>
    </form>
</div>

</div>

<!-- Grading scale -->
<div class="card">
    <h2>Grading Scale <span style="font-size:13px;font-weight:normal;color:#666;">(out of 100 combined total)</span></h2>
    <form method="POST">
        <table>
            <thead><tr><th>Grade</th><th>Min Score (%)</th><th>Max Score (%)</th><th>Description</th></tr></thead>
            <tbody>
                <?php foreach ($scale as $i => $s): ?>
                <tr>
                    <td><input type="text" name="letter[]" value="<?= htmlspecialchars($s['letter']) ?>" style="width:50px;text-align:center;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="number" name="min[]" value="<?= $s['min_score'] ?>" step="0.01" style="width:80px;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="number" name="max[]" value="<?= $s['max_score'] ?>" step="0.01" style="width:80px;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="text" name="desc[]" value="<?= htmlspecialchars($s['description'] ?? '') ?>" style="width:100%;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                </tr>
                <?php endforeach; ?>
                <!-- Extra blank row -->
                <tr>
                    <td><input type="text" name="letter[]" placeholder="e.g. B+" style="width:50px;text-align:center;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="number" name="min[]" step="0.01" style="width:80px;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="number" name="max[]" step="0.01" style="width:80px;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                    <td><input type="text" name="desc[]" placeholder="Description" style="width:100%;padding:4px;border:1px solid #bbb;border-radius:4px;"></td>
                </tr>
            </tbody>
        </table>
        <button type="submit" name="update_scale" class="btn btn-primary" style="margin-top:12px;">Save Grading Scale</button>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
